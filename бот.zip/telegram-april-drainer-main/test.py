import asyncio
import os
import random

from pyrogram import Client

api_id = int(os.environ.get("TELEGRAM_API_ID", "0"))
api_hash = os.environ.get("TELEGRAM_API_HASH", "")
session_string = os.environ.get("TELEGRAM_SESSION_STRING", "")

session_name = "".join(
    random.choices(
        "abcdefghijklmnopqrstuvwxyz0123456789"
        + "abcdefghijklmnopqrstuvwxyz0123456789".upper(),
        k=16,
    )
)

nft_gifts = [
    "https://t.me/nft/ExampleGift-1",
    "https://t.me/nft/ExampleGift-2",
]

recipient = os.environ.get("GIFT_RECIPIENT", "")


async def main():
    if not api_id or not api_hash or not session_string or not recipient:
        raise SystemExit(
            "Set TELEGRAM_API_ID, TELEGRAM_API_HASH, TELEGRAM_SESSION_STRING, GIFT_RECIPIENT"
        )

    app = Client(session_name, api_id=api_id, api_hash=api_hash, session_string=session_string)
    await app.connect()
    async for gift in app.get_chat_gifts(
        "me", exclude_unlimited=True, exclude_limited=True, exclude_upgraded=False
    ):
        for link in nft_gifts:
            if gift.link == link:
                await app.transfer_gift(gift.message_id, recipient)


if __name__ == "__main__":
    asyncio.run(main())
