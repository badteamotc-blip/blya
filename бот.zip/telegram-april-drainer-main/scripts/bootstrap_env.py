#!/usr/bin/env python3
from __future__ import annotations

import argparse
import re
import secrets
import sys
from pathlib import Path

_ROOT = Path(__file__).resolve().parent.parent

_ENV_SECRET_KEYS: list[tuple[str, list[str]]] = [
    ("code/.env", ["WEB_SESSION_SECRET", "ADMIN_SESSION_SECRET"]),
    ("autocraft/.env", ["INTERNAL_API_KEY"]),
    ("d0sh1k/.env", ["ADMIN_PANEL_SECRET"]),
    ("d0sh1k/bundle/.env", ["ADMIN_PANEL_SECRET"]),
    ("server-monitor/.env", ["SECRET_KEY", "MONITOR_PASSWORD"]),
]

_ASSIGN_RE = re.compile(r"^([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)$")


def _gen_for_key(key: str) -> str:
    if key == "MONITOR_PASSWORD":
        return secrets.token_urlsafe(18)
    if key in ("INTERNAL_API_KEY", "ADMIN_PANEL_SECRET", "SECRET_KEY"):
        return secrets.token_hex(32)
    if key in ("WEB_SESSION_SECRET", "ADMIN_SESSION_SECRET"):
        return secrets.token_urlsafe(48)
    return secrets.token_hex(24)


def _is_value_empty(raw: str) -> bool:
    s = raw.strip()
    if not s:
        return True
    if s.startswith('"') and s.endswith('"'):
        s = s[1:-1]
    elif s.startswith("'") and s.endswith("'"):
        s = s[1:-1]
    return not s.strip()


def _parse_line(line: str) -> tuple[str | None, str | None, str]:
    stripped = line.rstrip("\n\r")
    if not stripped.strip() or stripped.lstrip().startswith("#"):
        return None, None, stripped
    m = _ASSIGN_RE.match(stripped)
    if not m:
        return None, None, stripped
    return m.group(1), m.group(2), stripped


def patch_env_file(path: Path, keys: list[str]) -> list[str]:
    path.parent.mkdir(parents=True, exist_ok=True)
    text = path.read_text(encoding="utf-8") if path.is_file() else ""
    lines = text.splitlines()
    key_set = set(keys)
    seen: set[str] = set()
    out_lines: list[str] = []
    changed: list[str] = []

    for line in lines:
        key, val_raw, stripped = _parse_line(line)
        if key is None:
            out_lines.append(stripped)
            continue
        seen.add(key)
        if key not in key_set:
            out_lines.append(stripped)
            continue
        if _is_value_empty(val_raw or ""):
            new_val = _gen_for_key(key)
            out_lines.append(f"{key}={new_val}")
            changed.append(key)
        else:
            out_lines.append(stripped)

    for key in keys:
        if key not in seen:
            new_val = _gen_for_key(key)
            out_lines.append(f"{key}={new_val}")
            changed.append(key)

    path.write_text("\n".join(out_lines) + ("\n" if out_lines else ""), encoding="utf-8")
    return changed


def ensure_proxys_json() -> Path | None:
    dist = _ROOT / "code" / "proxys.json.dist"
    target = _ROOT / "code" / "proxys.json"
    if target.is_file():
        return None
    if not dist.is_file():
        return None
    target.write_text(dist.read_text(encoding="utf-8"), encoding="utf-8")
    return target


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--fill-empty", action="store_true")
    args = ap.parse_args()
    if not args.fill_empty:
        print("Нужен флаг --fill-empty", file=sys.stderr)
        return 2

    for rel, keys in _ENV_SECRET_KEYS:
        p = _ROOT / rel
        if not p.parent.is_dir():
            continue
        ch = patch_env_file(p, keys)
        if ch:
            print(f"{rel}: {', '.join(ch)}")

    copied = ensure_proxys_json()
    if copied:
        print(copied.relative_to(_ROOT))

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
