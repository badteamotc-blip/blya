#!/usr/bin/env python3
import base64
import json
import os
import select
import socket
import sys


def load_proxy(region: str):
    here = os.path.dirname(os.path.abspath(__file__))
    default = os.path.normpath(os.path.join(here, "..", "server-pull", "proxys.json"))
    path = os.environ.get("PROXYS_JSON", default)
    with open(path, encoding="utf-8") as f:
        d = json.load(f)
    return d["proxys"][0][region]


def main():
    if len(sys.argv) < 3:
        sys.exit(2)
    th, tp = sys.argv[1], int(sys.argv[2])
    region = sys.argv[3] if len(sys.argv) > 3 else "ru"
    r = load_proxy(region)
    ph = r["hostname"]
    pp = int(r["port"])
    user = r["username"]
    pw = r["password"]
    s = socket.create_connection((ph, pp), timeout=60)
    s.setblocking(True)
    b64 = base64.b64encode(f"{user}:{pw}".encode()).decode()
    req = (
        f"CONNECT {th}:{tp} HTTP/1.1\r\n"
        f"Host: {th}:{tp}\r\n"
        f"Proxy-Authorization: Basic {b64}\r\n"
        f"\r\n"
    )
    s.sendall(req.encode())
    buf = b""
    while b"\r\n\r\n" not in buf:
        chunk = s.recv(4096)
        if not chunk:
            break
        buf += chunk
    line = buf.split(b"\r\n", 1)[0].decode(errors="replace")
    parts = line.split()
    if len(parts) < 2 or parts[1] != "200":
        sys.stderr.write(line + "\n")
        sys.exit(1)
    sep = buf.find(b"\r\n\r\n")
    if sep != -1:
        extra = buf[sep + 4 :]
        if extra:
            sys.stdout.buffer.write(extra)
            sys.stdout.buffer.flush()
    sin = sys.stdin.buffer
    sout = sys.stdout.buffer
    readfds = [s, sin]
    log = open("/tmp/pcdbg2.log", "a", buffering=1)
    log.write("enter loop\n")
    while True:
        r, _, _ = select.select(readfds, [], [], 3600)
        log.write(f"sel {[(x.fileno(), id(x)) for x in r]}\n")
        if not r:
            break
        if s in r:
            d = s.recv(65536)
            log.write(f"s recv {len(d) if d else 0}\n")
            if not d:
                break
            sout.write(d)
            sout.flush()
        if sin in readfds and sin in r:
            d = sin.read(65536)
            if not d:
                log.write("stdin eof\n")
                try:
                    s.shutdown(socket.SHUT_WR)
                except OSError:
                    pass
                readfds = [s]
                continue
            s.sendall(d)
    log.close()


if __name__ == "__main__":
    main()
