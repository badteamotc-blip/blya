from pathlib import Path

from settings import Settings


def team_location_block(settings: Settings, slug: str, port: int) -> str:
    h = settings.nginx_upstream_host
    return f"""
location /{slug}/ {{
    proxy_pass http://{h}:{port}/;
    proxy_http_version 1.1;
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;
}}
""".strip()


def write_team_nginx(settings: Settings, slug: str, port: int) -> Path:
    d = settings.nginx_teams_include_dir / "fragment"
    d.mkdir(parents=True, exist_ok=True)
    out = d / f"{slug}.conf"
    out.write_text(team_location_block(settings, slug, port) + "\n", encoding="utf-8")
    return out


def referral_location_block(settings: Settings, slug: str, port: int) -> str:
    h = settings.nginx_upstream_host
    return f"""
location /{slug}/ {{
    proxy_pass http://{h}:{port}/;
    proxy_http_version 1.1;
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;
}}
""".strip()


def write_team_referral_nginx(settings: Settings, slug: str, port: int) -> Path:
    d = settings.nginx_teams_include_dir / "referral"
    d.mkdir(parents=True, exist_ok=True)
    out = d / f"{slug}.conf"
    out.write_text(referral_location_block(settings, slug, port) + "\n", encoding="utf-8")
    return out
