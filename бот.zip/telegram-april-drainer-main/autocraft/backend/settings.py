from pathlib import Path
from typing import Any, Optional

from pydantic import AliasChoices, Field, ValidationInfo, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

_AUTOCRAFT_ROOT = Path(__file__).resolve().parent.parent
_OPT_ROOT = _AUTOCRAFT_ROOT.parent


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=str(_AUTOCRAFT_ROOT / ".env"),
        env_file_encoding="utf-8",
        extra="ignore",
        populate_by_name=True,
    )

    autocraft_host: str = "0.0.0.0"
    autocraft_port: int = 38909
    internal_api_key: str = ""
    buy_public_base: str = "https://byy.dra1n.online"
    user_app_base: str = "https://1.fragmentapi.online"
    referral_public_base_default: str = Field(
        default="",
        validation_alias=AliasChoices(
            "referral_public_base_default",
            "REFERRAL_PUBLIC_BASE",
        ),
    )
    teams_root: Path = _OPT_ROOT / "teams"
    code_root: Path = _OPT_ROOT / "code"
    template_team_slug: str = "test"
    port_range_min: int = 37000
    port_range_max: int = 37899
    nginx_upstream_host: str = "127.0.0.1"
    nginx_sites_available: Path = Path("/etc/nginx/sites-available")
    nginx_teams_include_dir: Path = _AUTOCRAFT_ROOT / "nginx-generated"
    nginx_reload_cmd: Optional[str] = None
    sqlite_path: Path = _AUTOCRAFT_ROOT / "data" / "autocraft.sqlite"
    password_min_length: int = 8
    token_ttl_hours: int = 24
    cors_origins: str = ""

    @staticmethod
    def _blank(v: Any) -> bool:
        return v is None or (isinstance(v, str) and not v.strip())

    @field_validator("teams_root", "code_root", mode="before")
    @classmethod
    def _teams_code_paths(cls, v: Any, info: ValidationInfo) -> Path:
        sub = "teams" if info.field_name == "teams_root" else "code"
        if cls._blank(v):
            return _OPT_ROOT / sub
        p = Path(v)
        if not p.is_absolute():
            return (_OPT_ROOT / p).resolve()
        return p.resolve()

    @field_validator("sqlite_path", mode="before")
    @classmethod
    def _sqlite_path(cls, v: Any) -> Path:
        if cls._blank(v):
            return _AUTOCRAFT_ROOT / "data" / "autocraft.sqlite"
        p = Path(v)
        if not p.is_absolute():
            return (_AUTOCRAFT_ROOT / p).resolve()
        return p.resolve()

    @field_validator("nginx_teams_include_dir", mode="before")
    @classmethod
    def _nginx_teams_include(cls, v: Any) -> Path:
        if cls._blank(v):
            return _AUTOCRAFT_ROOT / "nginx-generated"
        p = Path(v)
        if not p.is_absolute():
            return (_AUTOCRAFT_ROOT / p).resolve()
        return p.resolve()

    @field_validator("nginx_sites_available", mode="before")
    @classmethod
    def _nginx_sites(cls, v: Any) -> Path:
        if cls._blank(v):
            return Path("/etc/nginx/sites-available")
        p = Path(v)
        if not p.is_absolute():
            return (_AUTOCRAFT_ROOT / p).resolve()
        return p.resolve()

    @field_validator("nginx_reload_cmd", mode="before")
    @classmethod
    def _empty_reload_to_none(cls, v: Optional[str]) -> Optional[str]:
        if v == "":
            return None
        return v


def get_settings() -> Settings:
    return Settings()
