import json
import os
import re
from typing import Optional, Set
import shutil
import subprocess
import sys
from pathlib import Path

from settings import Settings

_SLUG_RE = re.compile(r"^[a-z0-9_]{3,}$")

CONF_KEYS_FROM_TEMPLATE = frozenset(
    {
        "REQUIRED_SUBSCRIBE_CHAT",
        "REQUIRED_SUBSCRIBE_URL",
        "BRAND_TELEGRAM",
        "WORK_GROUP_ID",
        "LOGS_THREAD_ID",
        "DRAINS_THREAD_ID",
        "DRAIN_LOGS_THREAD_ID",
        "PAYOUTS_THREAD_ID",
        "ADMIN_ID",
        "CHAT_RECEIVER_USERNAME",
        "MESSAGE_RECEIVER_ID",
        "API_ID",
        "API_HASH",
        "REFERRAL_PUBLIC_BASE",
        "REF_BOT_USERNAME",
    }
)


def parse_config_py(path: Path) -> dict:
    data: dict = {}
    text = path.read_text(encoding="utf-8")
    exec(text, {}, data)
    return {k: v for k, v in data.items() if not k.startswith("_")}


def escape_py_str(s: str) -> str:
    return s.replace("\\", "\\\\").replace('"', '\\"')


def render_config_py(merged: dict) -> str:
    lines = [
        f'BOT_TOKEN = "{escape_py_str(str(merged.get("BOT_TOKEN", "")))}"',
        f'REQUIRED_SUBSCRIBE_CHAT = "{escape_py_str(str(merged.get("REQUIRED_SUBSCRIBE_CHAT", "")))}"',
        f'REQUIRED_SUBSCRIBE_URL = "{escape_py_str(str(merged.get("REQUIRED_SUBSCRIBE_URL", "")))}"',
        f'BRAND_TELEGRAM = "{escape_py_str(str(merged.get("BRAND_TELEGRAM", "")))}"',
        f'WORK_GROUP_ID = {merged.get("WORK_GROUP_ID", 0)}',
        f'LOGS_THREAD_ID = {merged.get("LOGS_THREAD_ID", 1)}',
        f'DRAINS_THREAD_ID = {merged.get("DRAINS_THREAD_ID", 1)}',
        f'DRAIN_LOGS_THREAD_ID = {merged.get("DRAIN_LOGS_THREAD_ID", 1)}',
        f'PAYOUTS_THREAD_ID = {merged.get("PAYOUTS_THREAD_ID", 1)}',
    ]
    admin_id = merged.get("ADMIN_ID", [])
    if isinstance(admin_id, list):
        lines.append(f"ADMIN_ID = {admin_id}")
    else:
        lines.append(f"ADMIN_ID = [{admin_id}]")
    lines.append(
        f'ADMIN_WALLET = "{escape_py_str(str(merged.get("ADMIN_WALLET", "")))}"'
    )
    lines.append(
        f'CHAT_RECEIVER_USERNAME = "{escape_py_str(str(merged.get("CHAT_RECEIVER_USERNAME", "")))}"'
    )
    lines.append(f'MESSAGE_RECEIVER_ID = {merged.get("MESSAGE_RECEIVER_ID", 2)}')
    lines.append(f'API_ID = {merged.get("API_ID", 0)}')
    lines.append(f'API_HASH = "{escape_py_str(str(merged.get("API_HASH", "")))}"')
    lines.append(f'WEB_APP_LINK = "{escape_py_str(str(merged.get("WEB_APP_LINK", "")))}"')
    lines.append(f'SECRET_KEY = "{escape_py_str(str(merged.get("SECRET_KEY", "")))}"')
    lines.append(
        f'HYBR1D_SESSION_STRING = "{escape_py_str(str(merged.get("HYBR1D_SESSION_STRING", "")))}"'
    )
    lines.append(f'OFFERS_WALLET = "{escape_py_str(str(merged.get("OFFERS_WALLET", "")))}"')
    lines.append(
        f'STAR_SESSION_STRING = "{escape_py_str(str(merged.get("STAR_SESSION_STRING", "")))}"'
    )
    lines.append(
        f'REFERRAL_PUBLIC_BASE = "{escape_py_str(str(merged.get("REFERRAL_PUBLIC_BASE", "")))}"'
    )
    lines.append(
        f'REF_BOT_USERNAME = "{escape_py_str(str(merged.get("REF_BOT_USERNAME", "")))}"'
    )
    return "\n".join(lines) + "\n"


def collect_used_ports(settings: Settings) -> set[int]:
    used: set[int] = {settings.autocraft_port}
    if not settings.teams_root.is_dir():
        return used
    for child in settings.teams_root.iterdir():
        if not child.is_dir():
            continue
        svc = child / "service.json"
        if not svc.is_file():
            continue
        try:
            data = json.loads(svc.read_text(encoding="utf-8"))
            used.add(int(data.get("web_port", 0)))
            rp = data.get("referral_web_port")
            if rp is not None:
                used.add(int(rp))
        except (OSError, json.JSONDecodeError, ValueError, TypeError):
            continue
    return used


def pick_free_port(settings: Settings, extra_used: Optional[Set[int]] = None) -> int:
    used = collect_used_ports(settings)
    if extra_used:
        used = used | extra_used
    for p in range(settings.port_range_min, settings.port_range_max + 1):
        if p not in used:
            return p
    raise RuntimeError("Нет свободного порта в диапазоне")


def validate_slug(slug: str) -> None:
    if not _SLUG_RE.match(slug):
        raise ValueError("Некорректное имя команды")


def provision_team(
    settings: Settings,
    slug: str,
    admin_password: str,
) -> dict:
    validate_slug(slug)
    template_dir = (settings.teams_root / settings.template_team_slug).resolve()
    dest = (settings.teams_root / slug).resolve()
    try:
        dest.relative_to(settings.teams_root.resolve())
    except ValueError as e:
        raise ValueError("Некорректный путь") from e
    if not template_dir.is_dir() or not (template_dir / "config.py").is_file():
        raise FileNotFoundError(f"Шаблон не найден: {template_dir}")
    if dest.exists():
        raise FileExistsError(f"Команда уже существует: {slug}")

    shutil.copytree(
        template_dir,
        dest,
        ignore=shutil.ignore_patterns("__pycache__", "*.pyc"),
    )

    for db in dest.glob("storage/*.db"):
        try:
            db.unlink()
        except OSError:
            pass

    tpl_cfg = parse_config_py(template_dir / "config.py")
    merged: dict = {}
    for k in CONF_KEYS_FROM_TEMPLATE:
        if k in tpl_cfg:
            merged[k] = tpl_cfg[k]
    merged["BOT_TOKEN"] = ""
    merged["HYBR1D_SESSION_STRING"] = ""
    merged["OFFERS_WALLET"] = ""
    merged["ADMIN_WALLET"] = ""
    merged["STAR_SESSION_STRING"] = tpl_cfg.get("STAR_SESSION_STRING", "")
    base = str(settings.user_app_base).rstrip("/")
    merged["WEB_APP_LINK"] = f"{base}/{slug}"
    merged["SECRET_KEY"] = admin_password
    if "REFERRAL_PUBLIC_BASE" not in merged:
        merged["REFERRAL_PUBLIC_BASE"] = str(settings.referral_public_base_default).rstrip(
            "/"
        )
    if "REF_BOT_USERNAME" not in merged:
        merged["REF_BOT_USERNAME"] = ""

    (dest / "config.py").write_text(render_config_py(merged), encoding="utf-8")

    port = pick_free_port(settings)
    referral_port = pick_free_port(settings, extra_used={port})
    bind = "127.0.0.1"
    health_url = f"http://{bind}:{port}/"
    service = {
        "web_port": port,
        "referral_web_port": referral_port,
        "web_host": bind,
        "health_url": health_url,
        "check_interval_sec": 30,
        "autostart_bot": True,
    }
    (dest / "service.json").write_text(
        json.dumps(service, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )

    code_root = settings.code_root.resolve()
    env = {**os.environ, "TEAM_DIR": str(dest)}
    r = subprocess.run(
        [
            sys.executable,
            "-c",
            "import paths, database; database.init_databases()",
        ],
        cwd=str(code_root),
        env=env,
        capture_output=True,
        text=True,
        timeout=120,
    )
    if r.returncode != 0:
        shutil.rmtree(dest, ignore_errors=True)
        raise RuntimeError(
            f"init_databases failed: {r.stderr or r.stdout or r.returncode}"
        )

    import nginx_writer

    try:
        nginx_file = nginx_writer.write_team_nginx(settings, slug, port)
        referral_nginx_file = nginx_writer.write_team_referral_nginx(
            settings, slug, referral_port
        )
    except OSError as e:
        raise RuntimeError(f"nginx snippet write failed: {e}") from e

    if settings.nginx_reload_cmd:
        rr = subprocess.run(
            settings.nginx_reload_cmd,
            shell=True,
            capture_output=True,
            text=True,
            timeout=60,
        )
        if rr.returncode != 0:
            raise RuntimeError(
                f"nginx reload failed: {rr.stderr or rr.stdout}"
            )

    return {
        "slug": slug,
        "team_dir": str(dest),
        "web_port": port,
        "referral_web_port": referral_port,
        "web_app_link": merged["WEB_APP_LINK"],
        "nginx_snippet": str(nginx_file),
        "referral_nginx_snippet": str(referral_nginx_file),
    }
