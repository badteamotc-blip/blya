import secrets
import string
import time
from pathlib import Path
from typing import Optional, Tuple

import aiosqlite

_ALPHABET = string.ascii_letters + string.digits


def generate_token(length: int = 16) -> str:
    return "".join(secrets.choice(_ALPHABET) for _ in range(length))


async def create_token(
    db_path: Path,
    ttl_seconds: int,
    created_by: Optional[str] = None,
) -> str:
    now = time.time()
    expires = now + ttl_seconds
    for _ in range(32):
        token = generate_token(16)
        try:
            async with aiosqlite.connect(db_path) as db:
                await db.execute(
                    "INSERT INTO tokens (token, created_at, expires_at, created_by) VALUES (?, ?, ?, ?)",
                    (token, now, expires, created_by),
                )
                await db.commit()
            return token
        except aiosqlite.IntegrityError:
            continue
    raise RuntimeError("Не удалось сгенерировать уникальный токен")


async def mark_token_used(db_path: Path, token: str) -> None:
    now = time.time()
    async with aiosqlite.connect(db_path) as db:
        await db.execute(
            "UPDATE tokens SET used_at = ? WHERE token = ?", (now, token)
        )
        await db.commit()


async def validate_token_unused(db_path: Path, token: str) -> Tuple[bool, str]:
    now = time.time()
    async with aiosqlite.connect(db_path) as db:
        cur = await db.execute(
            "SELECT used_at, expires_at FROM tokens WHERE token = ?", (token,)
        )
        row = await cur.fetchone()
        if not row:
            return False, "invalid"
        used_at, expires_at = row[0], row[1]
        if used_at is not None:
            return False, "used"
        if expires_at < now:
            return False, "expired"
        return True, "ok"
