import re
from typing import Optional
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import Depends, FastAPI, Header, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.errors import RateLimitExceeded
from slowapi.middleware import SlowAPIMiddleware
from slowapi.util import get_remote_address

from db import init_db
from provision import provision_team, validate_slug
from settings import Settings, get_settings
import tokens_service

AUTOCRAFT_ROOT = Path(__file__).resolve().parent.parent
FRONTEND_DIST = AUTOCRAFT_ROOT / "frontend" / "dist"

_TOKEN_RE = re.compile(r"^[a-zA-Z0-9]{16}$")
_NAME_RE = re.compile(r"^[a-zA-Z0-9_]{3,}$")

limiter = Limiter(key_func=get_remote_address)


@asynccontextmanager
async def lifespan(app: FastAPI):
    s = get_settings()
    await init_db(s.sqlite_path)
    yield


app = FastAPI(
    title="autocraft",
    openapi_url=None,
    docs_url=None,
    redoc_url=None,
    lifespan=lifespan,
)
app.state.limiter = limiter
app.add_middleware(SlowAPIMiddleware)
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)


def _apply_cors(application: FastAPI, s: Settings) -> None:
    origins = [o.strip() for o in s.cors_origins.split(",") if o.strip()]
    if origins:
        application.add_middleware(
            CORSMiddleware,
            allow_origins=origins,
            allow_credentials=True,
            allow_methods=["*"],
            allow_headers=["*"],
        )


_apply_cors(app, get_settings())


def require_internal(
    x_internal_key: Optional[str] = Header(None, alias="X-Internal-Key"),
) -> None:
    s = get_settings()
    if not s.internal_api_key or x_internal_key != s.internal_api_key:
        raise HTTPException(status_code=401, detail="Unauthorized")


class TokenCreateResponse(BaseModel):
    token: str
    url: str


class RegisterFinishBody(BaseModel):
    token: str = Field(..., min_length=16, max_length=16)
    team_name: str = Field(..., min_length=1, max_length=64)
    password: str = Field(..., min_length=1)


@app.post("/api/internal/tokens", dependencies=[Depends(require_internal)])
async def internal_create_token(
    request: Request,
    created_by: Optional[str] = None,
) -> TokenCreateResponse:
    s = get_settings()
    try:
        body = await request.json()
        if isinstance(body, dict):
            created_by = body.get("created_by") or created_by
    except Exception:
        pass
    ttl = s.token_ttl_hours * 3600
    token = await tokens_service.create_token(
        s.sqlite_path, ttl, created_by=created_by
    )
    base = str(s.buy_public_base).rstrip("/")
    return TokenCreateResponse(token=token, url=f"{base}/r/{token}")


@app.get("/api/register/status/{token}")
async def register_status(token: str) -> dict:
    if not _TOKEN_RE.match(token):
        raise HTTPException(status_code=404, detail="Not found")
    s = get_settings()
    ok, reason = await tokens_service.validate_token_unused(s.sqlite_path, token)
    if not ok:
        code = 410 if reason == "used" else 404
        raise HTTPException(status_code=code, detail=reason)
    return {"ok": True}


@app.post("/api/register/finish")
@limiter.limit("8/minute")
async def register_finish(request: Request, body: RegisterFinishBody) -> dict:
    s = get_settings()
    if not _TOKEN_RE.match(body.token):
        raise HTTPException(status_code=400, detail="invalid_token")
    name = body.team_name.strip()
    if not _NAME_RE.match(name):
        raise HTTPException(
            status_code=400,
            detail="team_name_invalid",
        )
    slug = name.lower()
    try:
        validate_slug(slug)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e)) from e
    if len(body.password) < s.password_min_length:
        raise HTTPException(status_code=400, detail="password_too_short")

    ok, reason = await tokens_service.validate_token_unused(s.sqlite_path, body.token)
    if not ok:
        raise HTTPException(
            status_code=410 if reason == "used" else 404,
            detail=reason,
        )

    try:
        result = provision_team(s, slug, body.password)
    except FileExistsError:
        raise HTTPException(status_code=409, detail="team_exists") from None
    except FileNotFoundError as e:
        raise HTTPException(status_code=500, detail=str(e)) from e
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e)) from e
    except RuntimeError as e:
        raise HTTPException(status_code=500, detail=str(e)) from e

    await tokens_service.mark_token_used(s.sqlite_path, body.token)
    return {"success": True, **result}


@app.get("/api/health")
async def health() -> dict:
    return {"status": "ok"}


def _mount_frontend(application: FastAPI) -> None:
    assets = FRONTEND_DIST / "assets"
    if assets.is_dir():
        application.mount(
            "/assets",
            StaticFiles(directory=assets),
            name="assets",
        )
    index = FRONTEND_DIST / "index.html"
    if not index.is_file():
        return

    @application.get("/r/{token}")
    async def spa_register(token: str):
        if not _TOKEN_RE.match(token):
            return JSONResponse({"detail": "not_found"}, status_code=404)
        return FileResponse(index)

    @application.get("/")
    async def spa_index():
        return FileResponse(index)


_mount_frontend(app)
