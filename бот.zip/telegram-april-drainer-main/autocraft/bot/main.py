import asyncio
import logging
import os
import time
from pathlib import Path

import httpx
from aiogram import Bot, Dispatcher, F, Router
from aiogram.filters import CommandStart
from aiogram.types import (
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    InlineQuery,
    InlineQueryResultArticle,
    InputTextMessageContent,
    Message,
)

_AUTOCRAFT = Path(__file__).resolve().parent.parent

from dotenv import load_dotenv

load_dotenv(_AUTOCRAFT / ".env")

BOT_TOKEN = os.environ.get("BOT_TOKEN", "").strip()
INTERNAL_URL = os.environ.get(
    "AUTOCRAFT_INTERNAL_URL", "http://127.0.0.1:38909"
).rstrip("/")
INTERNAL_KEY = os.environ.get("INTERNAL_API_KEY", "").strip()
ADMIN_IDS = {
    int(x.strip())
    for x in os.environ.get("ADMIN_IDS", "").split(",")
    if x.strip().isdigit()
}

router = Router()

PUBLIC_CHANNEL_URL = "https://t.me/Hybr1dDrainer"

ADMIN_INLINE_COOLDOWN_SEC = 2.5
_admin_inline_last: dict[int, float] = {}


def _public_channel_markup() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="Uretra d0sh1k | Hybr1d", url=PUBLIC_CHANNEL_URL)]
        ]
    )


async def _answer_public_channel(message: Message) -> None:
    await message.answer(
        PUBLIC_CHANNEL_URL,
        reply_markup=_public_channel_markup(),
        disable_web_page_preview=False,
    )


def _is_admin(user_id: int) -> bool:
    return user_id in ADMIN_IDS


@router.inline_query()
async def inline_query_handler(query: InlineQuery) -> None:
    if _is_admin(query.from_user.id):
        uid = query.from_user.id
        now = time.time()
        if now - _admin_inline_last.get(uid, 0) < ADMIN_INLINE_COOLDOWN_SEC:
            await query.answer(
                results=[
                    InlineQueryResultArticle(
                        id=f"cd{int(now * 1000)}",
                        title="Подожди пару секунд",
                        description="Запросы слишком частые",
                        input_message_content=InputTextMessageContent(
                            message_text="Повтори инлайн через пару секунд."
                        ),
                    )
                ],
                cache_time=1,
                is_personal=True,
            )
            return
        if not INTERNAL_KEY:
            await query.answer(
                results=[
                    InlineQueryResultArticle(
                        id="nokey",
                        title="INTERNAL_API_KEY не задан",
                        description="на сервере бота",
                        input_message_content=InputTextMessageContent(
                            message_text="INTERNAL_API_KEY не настроен на сервере бота."
                        ),
                    )
                ],
                cache_time=0,
                is_personal=True,
            )
            return
        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                r = await client.post(
                    f"{INTERNAL_URL}/api/internal/tokens",
                    headers={"X-Internal-Key": INTERNAL_KEY},
                    json={"created_by": f"tg:{uid}"},
                )
                r.raise_for_status()
                data = r.json()
                url = (data.get("url") or "").strip()
                token = (data.get("token") or "").strip()
        except Exception as e:
            await query.answer(
                results=[
                    InlineQueryResultArticle(
                        id=f"err{int(now * 1000)}",
                        title="Ошибка API",
                        description=str(e)[:120],
                        input_message_content=InputTextMessageContent(
                            message_text=f"Ошибка при создании ссылки:\n{e}"
                        ),
                    )
                ],
                cache_time=0,
                is_personal=True,
            )
            return
        if not url or not token:
            await query.answer(
                results=[
                    InlineQueryResultArticle(
                        id="nourl",
                        title="API без ссылки",
                        description="пустой ответ",
                        input_message_content=InputTextMessageContent(
                            message_text="API не вернул ссылку."
                        ),
                    )
                ],
                cache_time=0,
                is_personal=True,
            )
            return
        _admin_inline_last[uid] = now
        await query.answer(
            results=[
                InlineQueryResultArticle(
                    id=token,
                    title="Регистрация команды",
                    description=url if len(url) <= 120 else url[:117] + "...",
                    input_message_content=InputTextMessageContent(
                        message_text=f"Регистрация команды:\n{url}",
                        disable_web_page_preview=False,
                    ),
                )
            ],
            cache_time=0,
            is_personal=True,
        )
        return
    await query.answer(
        results=[
            InlineQueryResultArticle(
                id="buy_only",
                title="Канал Hybr1d Drainer",
                description=PUBLIC_CHANNEL_URL,
                input_message_content=InputTextMessageContent(
                    message_text=PUBLIC_CHANNEL_URL
                ),
            )
        ],
        cache_time=300,
        is_personal=True,
    )


@router.message(CommandStart(), F.chat.type == "private")
async def cmd_start(message: Message, bot: Bot) -> None:
    if _is_admin(message.from_user.id):
        u = (await bot.get_me()).username or "бота"
        await message.answer(
            f"Напиши @{u} в любом чате и выбери «Регнуть команду»."
        )
    else:
        await _answer_public_channel(message)


@router.message(F.text, F.chat.type == "private", ~CommandStart())
async def private_non_admin(message: Message, bot: Bot) -> None:
    if _is_admin(message.from_user.id):
        u = (await bot.get_me()).username or "бота"
        await message.answer(
            f"Напиши @{u} в любом чате и выбери «Регнуть команду»."
        )
        return
    await _answer_public_channel(message)


async def main() -> None:
    logging.basicConfig(
        level=logging.INFO,
        format="%(levelname)s:%(name)s:%(message)s",
    )
    if not BOT_TOKEN:
        raise SystemExit("Задай BOT_TOKEN в .env")
    if not ADMIN_IDS:
        raise SystemExit("Задай ADMIN_IDS в .env")
    dp = Dispatcher()
    dp.include_router(router)
    bot = Bot(BOT_TOKEN)
    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())
