import React from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Register from "./Register.jsx";
import "./index.css";

function BadLink() {
  return (
    <div
      style={{
        minHeight: "100vh",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        color: "#ecfdf5",
        fontFamily: "system-ui",
      }}
    >
      Откройте одноразовую ссылку вида /r/…
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <BrowserRouter>
      <Routes>
        <Route path="/r/:token" element={<Register />} />
        <Route path="*" element={<BadLink />} />
      </Routes>
    </BrowserRouter>
  </React.StrictMode>
);
