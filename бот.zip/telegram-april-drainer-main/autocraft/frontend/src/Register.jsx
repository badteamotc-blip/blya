import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";

const nameRe = /^[a-zA-Z0-9_]{3,}$/;

export default function Register() {
  const { token: paramToken } = useParams();
  const [token, setToken] = useState(paramToken || "");
  const [step, setStep] = useState(1);
  const [teamName, setTeamName] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [done, setDone] = useState(null);

  useEffect(() => {
    const path = window.location.pathname;
    const m = path.match(/\/r\/([a-zA-Z0-9]{16})\/?$/);
    const t = m ? m[1] : paramToken;
    if (t) setToken(t);
    if (!t && !paramToken) {
      setError("Неверная ссылка");
      setLoading(false);
      return;
    }
    const tok = t || paramToken;
    (async () => {
      try {
        const r = await fetch(`/api/register/status/${tok}`);
        if (!r.ok) {
          const d = await r.json().catch(() => ({}));
          setError(
            d.detail === "used"
              ? "Ссылка уже использована"
              : d.detail === "expired"
                ? "Ссылка истекла"
                : "Ссылка недействительна"
          );
          setLoading(false);
          return;
        }
        setLoading(false);
      } catch {
        setError("Сеть недоступна");
        setLoading(false);
      }
    })();
  }, [paramToken]);

  const onNameNext = (e) => {
    e.preventDefault();
    setError("");
    if (!nameRe.test(teamName.trim())) {
      setError(
        "Латиница, цифры и _, минимум 3 символа"
      );
      return;
    }
    setStep(2);
  };

  const onFinish = async (e) => {
    e.preventDefault();
    setError("");
    if (password.length < 8) {
      setError("Пароль не короче 8 символов");
      return;
    }
    setLoading(true);
    try {
      const r = await fetch("/api/register/finish", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          token,
          team_name: teamName.trim(),
          password,
        }),
      });
      const data = await r.json().catch(() => ({}));
      if (!r.ok) {
        const d = data.detail;
        if (d === "team_exists")
          setError("Такая команда уже есть");
        else if (d === "password_too_short")
          setError("Пароль слишком короткий");
        else setError(typeof d === "string" ? d : "Ошибка");
        setLoading(false);
        return;
      }
      setDone(data);
      setLoading(false);
    } catch {
      setError("Сеть недоступна");
      setLoading(false);
    }
  };

  if (loading && !done && !error) {
    return (
      <div className="page">
        <div className="card">
          <p className="muted">Проверка ссылки…</p>
        </div>
      </div>
    );
  }

  if (error && !token) {
    return (
      <div className="page">
        <div className="card">
          <h1 className="title">Ошибка</h1>
          <p className="err">{error}</p>
        </div>
      </div>
    );
  }

  if (error && step === 1 && !loading) {
    return (
      <div className="page">
        <div className="card">
          <h1 className="title">Недоступно</h1>
          <p className="err">{error}</p>
        </div>
      </div>
    );
  }

  if (done) {
    return (
      <div className="page">
        <div className="card success">
          <h1 className="title accent">Команда создана</h1>
          <p className="muted">WEB_APP_LINK</p>
          <code className="code">{done.web_app_link}</code>
          <p className="muted small">Порт веба: {done.web_port}</p>
          <p className="muted small">
            Перезапусти teams_supervisor и проверь nginx (см. docs/NGINX.md).
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="page">
      <div className="card">
        <div className="brand">autocraft</div>
        {step === 1 && (
          <form onSubmit={onNameNext}>
            <h1 className="title">Новая команда</h1>
            <p className="muted">Введите название команды</p>
            <input
              className="input"
              autoFocus
              value={teamName}
              onChange={(e) => setTeamName(e.target.value)}
              placeholder="my_team_01"
              autoComplete="off"
            />
            {error && step === 1 ? <p className="err">{error}</p> : null}
            <button type="submit" className="btn" disabled={loading}>
              Далее
            </button>
          </form>
        )}
        {step === 2 && (
          <form onSubmit={onFinish}>
            <h1 className="title">Пароль админки</h1>
            <p className="muted">
              Будет записан как SECRET_KEY (вход в веб-админку команды)
            </p>
            <input
              className="input"
              type="password"
              autoFocus
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="минимум 8 символов"
              autoComplete="new-password"
            />
            {error ? <p className="err">{error}</p> : null}
            <div className="row">
              <button
                type="button"
                className="btn ghost"
                onClick={() => {
                  setStep(1);
                  setError("");
                }}
              >
                Назад
              </button>
              <button type="submit" className="btn" disabled={loading}>
                {loading ? "…" : "Создать"}
              </button>
            </div>
          </form>
        )}
      </div>
      <style>{`
        .page {
          min-height: 100vh;
          display: flex;
          align-items: center;
          justify-content: center;
          padding: 24px;
        }
        .card {
          width: 100%;
          max-width: 420px;
          background: var(--surface);
          border: 1px solid var(--border);
          border-radius: 16px;
          padding: 32px 28px;
          box-shadow: 0 24px 48px rgba(0, 0, 0, 0.45);
        }
        .card.success .code {
          display: block;
          margin-top: 8px;
          padding: 12px;
          background: #080c0a;
          border-radius: 8px;
          border: 1px solid var(--border);
          word-break: break-all;
          font-family: "JetBrains Mono", monospace;
          font-size: 13px;
          color: var(--accent);
        }
        .brand {
          font-family: "JetBrains Mono", monospace;
          font-size: 11px;
          letter-spacing: 0.2em;
          text-transform: uppercase;
          color: var(--accent);
          margin-bottom: 20px;
        }
        .title {
          font-size: 1.35rem;
          font-weight: 600;
          margin: 0 0 8px;
        }
        .title.accent {
          color: var(--accent);
        }
        .muted {
          color: var(--muted);
          font-size: 0.9rem;
          margin: 0 0 20px;
        }
        .muted.small {
          font-size: 0.8rem;
          margin-top: 12px;
        }
        .input {
          width: 100%;
          padding: 14px 16px;
          border-radius: 10px;
          border: 1px solid var(--border);
          background: #080c0a;
          color: var(--text);
          font-size: 1rem;
          margin-bottom: 16px;
          outline: none;
        }
        .input:focus {
          border-color: var(--accent-dim);
          box-shadow: 0 0 0 3px rgba(34, 197, 94, 0.15);
        }
        .btn {
          width: 100%;
          padding: 14px;
          border: none;
          border-radius: 10px;
          background: linear-gradient(165deg, var(--accent), var(--accent-dim));
          color: #022c14;
          font-weight: 600;
          font-size: 1rem;
          cursor: pointer;
        }
        .btn:disabled {
          opacity: 0.6;
          cursor: not-allowed;
        }
        .btn.ghost {
          background: transparent;
          color: var(--muted);
          border: 1px solid var(--border);
        }
        .row {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 12px;
        }
        .err {
          color: var(--error);
          font-size: 0.88rem;
          margin: 0 0 12px;
        }
      `}</style>
    </div>
  );
}
