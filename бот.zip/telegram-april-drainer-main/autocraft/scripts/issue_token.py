#!/usr/bin/env python3
import argparse
import os
import sys
from pathlib import Path

import httpx

_ROOT = Path(__file__).resolve().parent.parent


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument(
        "--base-url",
        default=os.environ.get("AUTOCRAFT_INTERNAL_URL", "http://127.0.0.1:38909"),
    )
    p.add_argument(
        "--key",
        default=os.environ.get("INTERNAL_API_KEY", ""),
    )
    p.add_argument("--created-by", default="cli")
    args = p.parse_args()
    if not args.key:
        print("Нужен --key или INTERNAL_API_KEY", file=sys.stderr)
        return 1
    base = args.base_url.rstrip("/")
    try:
        r = httpx.post(
            f"{base}/api/internal/tokens",
            headers={"X-Internal-Key": args.key},
            json={"created_by": args.created_by},
            timeout=30.0,
        )
        r.raise_for_status()
        data = r.json()
    except Exception as e:
        print(e, file=sys.stderr)
        return 1
    print(data.get("url", ""))
    return 0


if __name__ == "__main__":
    sys.exit(main())
