#!/bin/sh
set -eu
NGINX_BIN=""
for c in /usr/sbin/nginx /sbin/nginx; do
  if [ -x "$c" ]; then
    NGINX_BIN="$c"
    break
  fi
done
if [ -z "$NGINX_BIN" ]; then
  echo "reload_host_nginx: nginx не найден" >&2
  exit 1
fi
if command -v systemctl >/dev/null 2>&1; then
  if systemctl is-active nginx >/dev/null 2>&1; then
    "$NGINX_BIN" -t && systemctl reload nginx
    exit $?
  fi
fi
"$NGINX_BIN" -t && "$NGINX_BIN" -s reload
exit $?
