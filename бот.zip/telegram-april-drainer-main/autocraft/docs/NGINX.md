# Nginx под авторег (autocraft)

## Порты по умолчанию (нативный стек, systemd)

| Назначение | nginx `proxy_pass` (типично) | Процесс |
|------------|------------------------------|---------|
| API регистрации / buy UI (autocraft) | `127.0.0.1:38909` или порт из `AUTOCRAFT_PORT` в `autocraft/.env` | `opt-autocraft-api.service` (gunicorn) |
| Админка команд (`ADMIN_WEB_PORT`) | `127.0.0.1:38080` | `opt-code-stack.service` → `web_admin_app.py` |
| Веб бота / рефералы | из `teams/*/service.json` (`web_port`, `referral_web_port`), диапазон **37000–37899** | `opt-code-stack.service` → `web.py` / `web_referral.py` |
| d0sh1k | `127.0.0.1:<PORT>` (`PORT` в `d0sh1k/bundle/.env`, по умолчанию `3434`; `BIND_HOST` по умолчанию `127.0.0.1`) | `opt-d0sh1k.service` |
| server-monitor | `127.0.0.1:<MONITOR_UVICORN_PORT>` (по умолчанию `38480`) | `opt-server-monitor.service` |

Порты слушают **loopback**, если так задано в `.env` / unit: с другой машины до процессов не достучаться, публичный вход — через **nginx на том же хосте** с `proxy_pass`.

## Домены и куда ведёт nginx (пример имён)

| Роль | Пример `server_name` | `proxy_pass` на хосте | systemd unit |
|------|----------------------|------------------------|--------------|
| Регистрация / buy UI | `byy.dra1n.online` | `http://127.0.0.1:38909` (или `AUTOCRAFT_PORT`) | `opt-autocraft-api.service` |
| Пользовательский веб (Mini App) | `1.fragmentapi.online` | `127.0.0.1:<web_port>` из сниппетов `fragment/` | `opt-code-stack.service` |
| Реферальный лендинг | (не используется; `REFERRAL_PUBLIC_BASE` пустой) | при необходимости отдельный `server` + `referral/*.conf` | `opt-code-stack.service` |
| Админка команд | `admin.d0sh1k.online` | `http://127.0.0.1:38080` (или `ADMIN_WEB_PORT`) | `opt-code-stack.service` |
| Чат d0sh1k (WebApp) | `d0sh1k.dra1n.online` (пример) | `http://127.0.0.1:<PORT>` из `d0sh1k` | `opt-d0sh1k.service` |
| Мониторинг (опционально) | свой домен | `http://127.0.0.1:<MONITOR_UVICORN_PORT>` | `opt-server-monitor.service` |

## Публичные URL в переменных окружения

| Переменная | Файл | Назначение |
|------------|------|------------|
| `BUY_PUBLIC_BASE` | `autocraft/.env` | Базовый URL формы регистрации / SPA buy |
| `USER_APP_BASE` | `autocraft/.env` | База для `WEB_APP_LINK` новых команд: `{USER_APP_BASE}/{slug}` |
| `REFERRAL_PUBLIC_BASE` | `autocraft/.env` | Дефолт `REFERRAL_PUBLIC_BASE` в `config.py` при provision, если шаблон не задаёт |
| `CORS_ORIGINS` | `autocraft/.env` | Разрешённые origin для API autocraft |
| `TELEGRAM_WEB_APP_URL` | `d0sh1k/.env` | URL Web App чата в Telegram |
| `WEB_APP_LINK` | `teams/*/config.py` | Публичная ссылка Mini App команды |
| `REFERRAL_PUBLIC_BASE` | `teams/*/config.py` | База ссылок реферального лендинга |

С хоста вызовы к API autocraft (бот, `issue_token.py`): **`AUTOCRAFT_INTERNAL_URL`** должен совпадать с реальным `http://127.0.0.1:<AUTOCRAFT_PORT>` (после отказа от Docker нет отдельного «внутреннего» порта контейнера — один порт на хосте).

**Сниппеты:** каталог из `NGINX_TEAMS_INCLUDE_DIR` в `autocraft/.env`. Nginx на хосте должен `include` этот каталог.

## Схема: клиент → nginx → порты → процессы

```mermaid
flowchart LR
  subgraph clients [Clients]
    Browser[Browser_TelegramWebApp]
  end
  subgraph host [Host]
    Nginx[Nginx_TLS]
    subgraph ports [Loopback_ports]
      P38909["127.0.0.1:38909"]
      P38080["127.0.0.1:38080"]
      P37["37000-37899"]
      Pd0sh1k["d0sh1k_PORT"]
      P38480["38480"]
    end
  end
  subgraph units [systemd_units]
    AC[opt_autocraft_api]
    CS[opt_code_stack]
    DR[opt_d0sh1k]
    SM[opt_server_monitor]
  end
  Browser --> Nginx
  Nginx -->|buy_PUBLIC| P38909 --> AC
  Nginx -->|user_app_fragment| P37 --> CS
  Nginx -->|referral_domain| P37 --> CS
  Nginx -->|admin_domain| P38080 --> CS
  Nginx -->|chat_webapp| Pd0sh1k --> DR
  Nginx -->|monitor_optional| P38480 --> SM
```

Сниппеты `fragment/*.conf` и `referral/*.conf` используют **`NGINX_UPSTREAM_HOST`** (по умолчанию `127.0.0.1`). Если nginx и приложения на разных машинах — выставь IP хоста с процессами.

```mermaid
flowchart TB
  AC[autocraft provision]
  AC --> PF[fragment/slug.conf web_port]
  AC --> PR[referral/slug.conf referral_port]
  AC --> RL[NGINX_RELOAD_CMD]
  NGF[server_name user_app домен]
  NGR[server_name referal домен]
  BUY[server_name buy домен]
  ADM[server_name admin домен]
  NGF -.->|include fragment/*.conf| PF
  NGR -.->|include referral/*.conf| PR
  BUY -->|location / proxy| ACAPI[autocraft хост :38909]
  ADM -->|location / proxy| AP[ADMIN_WEB_PORT 38080]
```

Идея: **один раз** настроить `server { }` на каждый домен с **`include` по маске**. Каждая новая команда из формы — autocraft дописывает **отдельный файл** в каталог include и (если задано) делает **reload nginx**. Ручно править `location` под каждый `slug` не нужно.

## Куда пишутся сниппеты

Каталог из `NGINX_TEAMS_INCLUDE_DIR` (по умолчанию `opt/autocraft/nginx-generated/`). Внутри **два подкаталога**, чтобы один `include` не подмешивал чужие `location`:

| Подкаталог | Назначение | Файлы |
|------------|------------|--------|
| `fragment/` | пользовательский веб команд (`web.py`) | `{slug}.conf` → `{NGINX_UPSTREAM_HOST}:{web_port}` |
| `referral/` | реферальный лендинг (`web_referral.py`) | `{slug}.conf` → `{NGINX_UPSTREAM_HOST}:{referral_web_port}` |

Старые файлы в корне `nginx-generated/*.conf` и `referral-*.conf` после обновления можно удалить вручную или оставить неподключёнными.

## 1. Пользовательский домен (пример `1.fragmentapi.online`)

Внутри `server { listen 443 ssl; server_name 1.fragmentapi.online; ... }`:

```nginx
include /opt/autocraft/nginx-generated/fragment/*.conf;
```

Каждая новая команда = новый `fragment/имя_команды.conf` при успешной регистрации.

## 2. Рефералы (опционально)

Отдельный `server { ... }` с `include /opt/autocraft/nginx-generated/referral/*.conf;` — только если нужен публичный домен под рефералку.

## 3. Регистрация и статика autocraft (`byy.dra1n.online`)

Один `location /` на процесс autocraft (порт **38909** или значение **`AUTOCRAFT_PORT`** в `autocraft/.env`):

```nginx
location / {
    proxy_pass http://127.0.0.1:38909;
    proxy_http_version 1.1;
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;
}
```

Если autocraft без Docker и слушает тот же порт, что в `AUTOCRAFT_PORT` — подставь его.

## 4. Админка (`admin.d0sh1k.online`)

Один upstream на **один** порт `teams_supervisor` / `ADMIN_WEB_PORT` (путь `/{slug}/admin/...` уже в приложении):

```nginx
location / {
    proxy_pass http://127.0.0.1:38080;
    proxy_http_version 1.1;
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;
}
```

Подставь свой порт вместо `38080`, если переопределил `ADMIN_WEB_PORT`.

## Адаптация: nginx и приложения на одном хосте

Обычно `proxy_pass http://127.0.0.1:ПОРТ` и сниппеты с **`NGINX_UPSTREAM_HOST=127.0.0.1`**. Если upstream на другой машине — задай **`NGINX_UPSTREAM_HOST`** и пересоздай сниппеты.

## Автоматический reload после новой команды

Сервис **`opt-autocraft-api.service`** обычно запускается от **root** (как в прежнем Docker-стеке), чтобы **`reload_host_nginx.sh`** мог вызвать **`systemctl reload nginx`**.

В `.env` autocraft:

```env
NGINX_RELOAD_CMD=/path/to/opt/autocraft/scripts/reload_host_nginx.sh
```

Скрипт выполняет **`nginx -t`**, затем **`systemctl reload nginx`**, если unit `nginx` активен; иначе **`nginx -s reload`**.

Если **`NGINX_RELOAD_CMD` пустой**, сниппеты всё равно запишутся в каталог include — перезагрузи nginx вручную.

Если API запускается не от root, настрой **`sudoers`** на **`systemctl reload nginx`** без пароля для пользователя сервиса.

## Порядок location (если добавляешь свои)

Более специфичные `location` выше общих `location /`. Сгенерированные куски — префикс `/{slug}/`, обычно не конфликтуют с `/`, если `/` не перехватывает всё раньше.

## Проверка

```bash
sudo nginx -t && sudo systemctl reload nginx
```

После регистрации команды проверь появление файлов в `fragment/` и `referral/` и ответ по URL `https://домен/slug/`.
