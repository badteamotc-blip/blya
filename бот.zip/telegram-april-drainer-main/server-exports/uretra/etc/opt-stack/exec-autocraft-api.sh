#!/usr/bin/env bash
set -euo pipefail
OPT_ROOT="/opt"
mkdir -p "$OPT_ROOT/autocraft/data"
export PYTHONPATH="$OPT_ROOT/autocraft/backend"
cd "$OPT_ROOT/autocraft/backend"
set -a
[ -f "$OPT_ROOT/autocraft/.env" ] && . "$OPT_ROOT/autocraft/.env"
set +a
H="${AUTOCRAFT_HOST:-0.0.0.0}"
P="${AUTOCRAFT_PORT:-9090}"
exec "$OPT_ROOT/autocraft/.venv/bin/gunicorn" main:app \
  -k uvicorn.workers.UvicornWorker -w 2 \
  -b "${H}:${P}" \
  --access-logfile - --error-logfile - \
  --timeout 120 --graceful-timeout 30 --keep-alive 5
