#!/usr/bin/env bash
set -euo pipefail
OPT_ROOT="/opt"
cd "$OPT_ROOT/server-monitor"
set -a
[ -f "$OPT_ROOT/server-monitor/.env" ] && . "$OPT_ROOT/server-monitor/.env"
set +a
P="${MONITOR_UVICORN_PORT:-38480}"
exec "$OPT_ROOT/server-monitor/.venv/bin/uvicorn" main:app --host 127.0.0.1 --port "$P"
