#!/usr/bin/env bash
set -euo pipefail
OPT_ROOT="/opt"
cd "$OPT_ROOT/code"
set -a
[ -f "$OPT_ROOT/code/.env" ] && . "$OPT_ROOT/code/.env"
[ -f "$OPT_ROOT/.env" ] && . "$OPT_ROOT/.env"
set +a
export TEAMS_ROOT="${TEAMS_ROOT:-$OPT_ROOT/teams}"
export STACK_BIND_HOST="${STACK_BIND_HOST:-0.0.0.0}"
export ADMIN_WEB_HOST="${ADMIN_WEB_HOST:-0.0.0.0}"
exec "$OPT_ROOT/code/.venv/bin/python3" teams_supervisor.py
