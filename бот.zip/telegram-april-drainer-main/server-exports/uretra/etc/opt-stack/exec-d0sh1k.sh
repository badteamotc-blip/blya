#!/usr/bin/env bash
set -euo pipefail
OPT_ROOT="/opt"
cd "$OPT_ROOT/d0sh1k/bundle"
set -a
[ -f "$OPT_ROOT/d0sh1k/bundle/.env" ] && . "$OPT_ROOT/d0sh1k/bundle/.env"
[ -f "$OPT_ROOT/d0sh1k/.env" ] && . "$OPT_ROOT/d0sh1k/.env"
set +a
export NODE_ENV="${NODE_ENV:-production}"
export BIND_HOST="${BIND_HOST:-127.0.0.1}"
SQLITE_PATH="${SQLITE_PATH:-$OPT_ROOT/d0sh1k/data/chat.sqlite}"
export SQLITE_PATH
mkdir -p "$(dirname "$SQLITE_PATH")"
exec /usr/bin/env node server/index.js
