#!/usr/bin/env bash
set -euo pipefail
OPT_ROOT="/opt"
cd "$OPT_ROOT/autocraft/bot"
set -a
[ -f "$OPT_ROOT/autocraft/.env" ] && . "$OPT_ROOT/autocraft/.env"
set +a
exec "$OPT_ROOT/autocraft/.venv-bot/bin/python" main.py
