import argparse
import asyncio
import os
import sys

import paths

import config_migration

config_migration.ensure_team_config_migrated(
    os.path.join(paths.get_team_dir(), "config.py")
)

import config

from drainer.core import hybr1d_shared


def _chat_line(d) -> str:
    c = d.chat
    parts = [str(getattr(c, "id", "")), str(getattr(c, "type", ""))]
    title = getattr(c, "title", None)
    if title:
        parts.append(repr(title))
    else:
        fn = getattr(c, "first_name", "") or ""
        ln = getattr(c, "last_name", "") or ""
        name = (fn + " " + ln).strip()
        if name:
            parts.append(repr(name))
    un = getattr(c, "username", None)
    if un:
        parts.append("@" + un)
    parts.append(f"top_message_id={getattr(d, 'top_message', None) and d.top_message.id}")
    return "  ".join(parts)


async def _async_main(limit: int) -> None:
    async with hybr1d_shared.hybr1d_client_context(
        config.API_ID, config.API_HASH, config.HYBR1D_SESSION_STRING
    ) as app:
        n = 0
        async for dialog in app.get_dialogs(limit=limit):
            print(_chat_line(dialog))
            n += 1
        print(f"total={n}", file=sys.stderr)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("-n", "--limit", type=int, default=40)
    args = ap.parse_args()
    try:
        asyncio.run(_async_main(max(1, min(args.limit, 200))))
    except KeyboardInterrupt:
        sys.exit(130)


if __name__ == "__main__":
    main()
