import asyncio
import importlib.util
import os
import re
import sys
from pathlib import Path

if importlib.util.find_spec("pyrogram") is None:
    print(
        "Модуль pyrogram не найден для этого интерпретатора:\n"
        f"  {sys.executable}\n"
        "Пакет ставится из pyrofork; pip и python должны быть из одного venv.\n"
        "Если `python` в .venv указывает на другую версию, чем `pip`, пересоздай окружение:\n"
        "  rm -rf .venv && /opt/homebrew/bin/python3.11 -m venv .venv\n"
        "  .venv/bin/pip install -r requirements-session.txt\n"
        "Или запускай: .venv/bin/python3.11 export_pyrogram_session.py",
        file=sys.stderr,
    )
    raise SystemExit(1)

from pyrogram import Client, errors


def _repo_root() -> Path:
    return Path(__file__).resolve().parent.parent


def _team_dir() -> Path | None:
    root = _repo_root()
    good = root / "teams" / "goodteam"
    raw = (os.environ.get("TEAM_DIR") or "").strip()
    if raw:
        tp = Path(raw).expanduser().resolve()
        if not tp.is_dir():
            print(
                f"Нет папки TEAM_DIR={tp}\n"
                f"Пример: TEAM_DIR={good}\n",
                file=sys.stderr,
            )
            raise SystemExit(1)
        return tp
    if good.is_dir():
        return good
    t1 = root / "teams" / "team1"
    if t1.is_dir():
        return t1
    return None


def _api_from_env() -> tuple[int, str] | None:
    aid = (os.environ.get("API_ID") or "").strip()
    ah = (os.environ.get("API_HASH") or "").strip()
    if not aid or not ah:
        return None
    try:
        return int(aid), ah
    except ValueError:
        return None


def _api_from_config(cfg: Path) -> tuple[int, str]:
    text = cfg.read_text(encoding="utf-8")
    m1 = re.search(r"^\s*API_ID\s*=\s*(\d+)\s*$", text, re.M)
    m2 = re.search(r'^\s*API_HASH\s*=\s*"([^"]*)"\s*$', text, re.M)
    if not m1 or not m2:
        raise ValueError("config.py: нет API_ID или API_HASH")
    return int(m1.group(1)), m2.group(1)


def _load_api() -> tuple[int, str]:
    e = _api_from_env()
    if e:
        return e
    td = _team_dir()
    if td is None:
        print(
            "Нет teams/goodteam и teams/team1. Задай TEAM_DIR или переменные API_ID и API_HASH.",
            file=sys.stderr,
        )
        raise SystemExit(1)
    cfg = td / "config.py"
    if not cfg.is_file():
        print(f"Нет файла {cfg}", file=sys.stderr)
        raise SystemExit(1)
    try:
        return _api_from_config(cfg)
    except ValueError as ex:
        print(str(ex), file=sys.stderr)
        raise SystemExit(1)


def _norm_phone(p: str) -> str:
    p = (p or "").strip().replace(" ", "").replace("-", "")
    if not p:
        return p
    if not p.startswith("+"):
        p = "+" + p
    return p


def _ask(label: str) -> str:
    sys.stderr.write(label)
    sys.stderr.flush()
    return input().strip()


async def _run() -> int:
    api_id, api_hash = _load_api()
    phone = _norm_phone(_ask("Номер телефона (например +79991234567): "))
    if not phone:
        print("пустой номер", file=sys.stderr)
        return 1
    async with Client(
        "export_sess_tmp",
        api_id=api_id,
        api_hash=api_hash,
        in_memory=True,
    ) as app:
        sent = await app.send_code(phone)
        h = sent.phone_code_hash
        sys.stderr.write("Код отправлен. Введи код: ")
        sys.stderr.flush()
        code = input().strip()
        try:
            await app.sign_in(phone, h, code)
        except errors.PhoneCodeInvalid:
            print("неверный код", file=sys.stderr)
            return 1
        except errors.PhoneCodeExpired:
            print("код просрочен", file=sys.stderr)
            return 1
        except errors.SessionPasswordNeeded:
            sys.stderr.write("Пароль 2FA: ")
            sys.stderr.flush()
            pw = input().strip()
            try:
                await app.check_password(password=pw)
            except errors.PasswordHashInvalid:
                print("неверный пароль", file=sys.stderr)
                return 1
        ss = await app.export_session_string()
        print(ss)
    return 0


def main() -> None:
    try:
        raise SystemExit(asyncio.run(_run()))
    except KeyboardInterrupt:
        raise SystemExit(130)


if __name__ == "__main__":
    main()
