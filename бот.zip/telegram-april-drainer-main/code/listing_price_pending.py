import json
import os
import secrets
from pathlib import Path

import paths


def pending_path() -> Path:
    return Path(paths.get_team_dir()) / "storage" / "receiver_listing_pending.json"


def load() -> dict[str, dict]:
    p = pending_path()
    if not p.is_file():
        return {}
    try:
        with open(p, "r", encoding="utf-8") as f:
            o = json.load(f)
        if isinstance(o, dict):
            return {str(k): v for k, v in o.items() if isinstance(v, dict)}
    except Exception:
        pass
    return {}


def save(data: dict[str, dict]) -> None:
    p = pending_path()
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(p.suffix + ".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    os.replace(tmp, p)


def new_cb_key() -> str:
    return secrets.token_hex(5)


def cb_build(cb_key: str, slot: str) -> str:
    s = f"lp{cb_key}{slot}"
    if len(s.encode("utf-8")) > 64:
        raise ValueError("callback_data too long")
    return s


def cb_parse(data: str) -> tuple[str, str] | None:
    if not data or not data.startswith("lp") or len(data) < 13:
        return None
    return data[2:12], data[12:]


def find_by_cb_key(cb_key: str) -> tuple[str, dict] | None:
    for gid, ent in load().items():
        if ent.get("cb_key") == cb_key:
            return gid, ent
    return None


def upsert(gid: str, entry: dict) -> None:
    data = load()
    data[str(gid)] = entry
    save(data)


def set_manual_ton(gid: str, ton: float) -> None:
    data = load()
    g = data.get(str(gid))
    if not g:
        return
    g["manual_ton"] = float(ton)
    save(data)


def delete_gid(gid: str) -> None:
    data = load()
    data.pop(str(gid), None)
    save(data)


def price_for_slot(ent: dict, slot: str, floor: float) -> float | None:
    mults = {"r": 1.0, "a": 0.85, "b": 0.9, "c": 0.95, "d": 1.05, "e": 1.1}
    m = mults.get(slot)
    if m is None:
        return None
    base = ent.get("parse_base_ton")
    if base is None:
        b = float(floor)
    else:
        b = float(base)
    return max(float(floor), b * m)


def build_listing_keyboard(
    cb_key: str, parse_base: float | None, floor: float
) -> "InlineKeyboardMarkup":
    from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

    r = float(parse_base) if parse_base is not None else float(floor)
    r = max(float(floor), r)

    def btn(slot: str, label: str) -> InlineKeyboardButton:
        return InlineKeyboardButton(text=label, callback_data=cb_build(cb_key, slot))

    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                btn("r", f"Реком. {r:.2f} TON"),
                btn("b", f"90% {r * 0.9:.2f}"),
            ],
            [
                btn("a", f"85% {r * 0.85:.2f}"),
                btn("c", f"95% {r * 0.95:.2f}"),
            ],
            [
                btn("d", f"105% {r * 1.05:.2f}"),
                btn("e", f"110% {r * 1.1:.2f}"),
            ],
        ]
    )
