import paths

from aiogram import Bot
from aiogram.fsm.storage.memory import MemoryStorage

from pyrogram import Client

from pathlib import Path

import os

import config

from drainer.core.proxy import aiogram_aiohttp_session, get_active_proxy

_bundle = get_active_proxy()
actual_proxy = _bundle[1]
proxy = _bundle[0]["ru"] if _bundle[0] else None

BASE_DIR = Path(__file__).resolve().parent
CODE_ROOT = paths.CODE_ROOT
absolute_path = paths.TEAM_DIR

version = "4.0.0"

api_id = config.API_ID
api_hash = config.API_HASH

star_session = Client(f"{absolute_path}/star_session", api_id, api_hash, proxy=proxy)

_aiogram_http = aiogram_aiohttp_session()
bot = Bot(token=config.BOT_TOKEN, session=_aiogram_http)
post_bot = Bot(token=config.BOT_TOKEN, session=_aiogram_http)
helper_bot = Bot(
    token=os.environ.get("HELPER_BOT_TOKEN", ""),
    session=_aiogram_http,
)

storage = MemoryStorage()
