"""Корень кода (CODE_ROOT) и каталог команды (TEAM_DIR). Импортируйте первым до `import config`."""

import os
import sys
from contextvars import ContextVar, Token
from pathlib import Path
from typing import Optional

_CODE_ROOT = Path(__file__).resolve().parent

_request_team_dir: ContextVar[Optional[str]] = ContextVar(
    "request_team_dir", default=None
)


def _resolve_team_dir() -> Path:
    raw = os.environ.get("TEAM_DIR")
    if raw:
        return Path(raw).expanduser().resolve()
    return (_CODE_ROOT.parent / "teams" / "goodteam").resolve()


TEAM_DIR_PATH = _resolve_team_dir()
if not TEAM_DIR_PATH.is_dir():
    raise FileNotFoundError(
        f"TEAM_DIR does not exist or is not a directory: {TEAM_DIR_PATH}"
    )

_tds = str(TEAM_DIR_PATH)
if _tds not in sys.path:
    sys.path.insert(0, _tds)

CODE_ROOT = str(_CODE_ROOT)
TEAM_DIR = str(TEAM_DIR_PATH)


def get_team_dir() -> str:
    """Активный каталог команды: из context (админка /{team}/...) или TEAM_DIR из окружения."""
    override = _request_team_dir.get()
    return override if override else TEAM_DIR


def push_team_dir(team_dir: str) -> Token:
    return _request_team_dir.set(team_dir)


def pop_team_dir(token: Token) -> None:
    _request_team_dir.reset(token)
