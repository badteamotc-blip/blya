import asyncio
import io
import random
import string
import threading

from PIL import Image, ImageDraw, ImageFilter, ImageFont

_pending: dict[int, str] = {}
_lock = threading.Lock()
_CAPTCHA_LEN = 7
_FONT_CANDIDATES = (
    "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
    "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
    "/System/Library/Fonts/Supplemental/Arial Bold.ttf",
)


def _norm(s: str) -> str:
    return "".join(c for c in (s or "").upper() if c.isalnum())


def is_pending(uid: int) -> bool:
    with _lock:
        return uid in _pending


def clear_pending(uid: int) -> None:
    with _lock:
        _pending.pop(uid, None)


def _random_answer() -> str:
    alphabet = string.ascii_uppercase + string.digits
    return "".join(random.choices(alphabet, k=_CAPTCHA_LEN))


def _render_png(answer: str) -> bytes:
    w, h = 320, 110
    img = Image.new("RGB", (w, h), (248, 248, 252))
    dr = ImageDraw.Draw(img)
    font = None
    for path in _FONT_CANDIDATES:
        try:
            font = ImageFont.truetype(path, 38)
            break
        except OSError:
            continue
    if font is None:
        font = ImageFont.load_default()
    tw = sum(
        dr.textbbox((0, 0), ch, font=font)[2]
        - dr.textbbox((0, 0), ch, font=font)[0]
        for ch in answer
    )
    x0 = max(12, (w - tw) // 2)
    x = x0
    for ch in answer:
        y = 28 + random.randint(-10, 10)
        col = (
            random.randint(15, 70),
            random.randint(15, 70),
            random.randint(15, 70),
        )
        dr.text((x, y), ch, fill=col, font=font)
        bbox = dr.textbbox((x, y), ch, font=font)
        x = bbox[2] + random.randint(2, 8)
    for _ in range(1200):
        dr.point(
            (random.randint(0, w - 1), random.randint(0, h - 1)),
            fill=(
                random.randint(120, 220),
                random.randint(120, 220),
                random.randint(120, 220),
            ),
        )
    for _ in range(4):
        dr.line(
            [
                (random.randint(0, w), random.randint(0, h)),
                (random.randint(0, w), random.randint(0, h)),
            ],
            fill=(random.randint(80, 160),) * 3,
            width=2,
        )
    img = img.filter(ImageFilter.GaussianBlur(radius=0.35))
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return buf.getvalue()


async def send_captcha_photo(uid: int, strict: bool) -> None:
    from aiogram.types import BufferedInputFile

    from base import bot

    ans = _random_answer()
    with _lock:
        _pending[uid] = ans
    png = await asyncio.to_thread(_render_png, ans)
    cap = (
        "Введите ВЕРНО символы с капчи для продолжения"
        if strict
        else "Введите символы с капчи для продолжения"
    )
    await bot.send_photo(
        uid,
        BufferedInputFile(png, filename="captcha.png"),
        caption=cap,
    )


def check_answer(uid: int, text: str) -> bool:
    with _lock:
        exp = _pending.get(uid)
        if exp is None:
            return False
        if _norm(text) != _norm(exp):
            return False
        del _pending[uid]
        return True


async def kick(uid: int) -> None:
    try:
        await asyncio.sleep(0.2)
        await send_captcha_photo(uid, strict=False)
    except Exception:
        pass
