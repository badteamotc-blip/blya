import base64
import hashlib
import time

from Crypto.Cipher import AES
from Crypto.Random import get_random_bytes
from Crypto.Util.Padding import pad

_PASSWORD = b"yowtfisthispieceofshitiiit"


def _evp(password: bytes, salt: bytes, key_len: int = 32, iv_len: int = 16):
    dtot = b""
    prev = b""
    while len(dtot) < (key_len + iv_len):
        prev = hashlib.md5(prev + password + salt).digest()
        dtot += prev
    return dtot[:key_len], dtot[key_len : key_len + iv_len]


def build_list_for_sale_wtf() -> tuple[int, str]:
    ts = int(time.time())
    timestamp = str(ts)
    salt = get_random_bytes(8)
    key, iv = _evp(_PASSWORD, salt)
    cipher = AES.new(key, AES.MODE_CBC, iv)
    ct = cipher.encrypt(pad(timestamp.encode("utf-8"), AES.block_size))
    wtf = base64.b64encode(b"Salted__" + salt + ct).decode("utf-8")
    return ts, wtf
