import json
import os
import urllib.parse

from paths import CODE_ROOT


def proxys_json_path() -> str:
    return os.path.join(CODE_ROOT, "proxys.json")


def change_proxy(proxy):
    with open(proxys_json_path(), "r") as file:
        proxys_json = json.load(file)

    proxys = proxys_json["proxys"]

    if proxy is None:
        proxys_json["noproxy"]["active"] = True
        for p in proxys:
            p["active"] = False
    else:
        proxys_json["noproxy"]["active"] = False
        for p in proxys:
            p["active"] = False
        proxys[proxy]["active"] = True

    with open(proxys_json_path(), "w") as file:
        json.dump(proxys_json, file, indent=4)

    return proxy


def get_active_proxy():
    with open(proxys_json_path(), "r") as file:
        proxys_json = json.load(file)

    proxys = proxys_json["proxys"]

    if proxys_json["noproxy"]["active"]:
        return [None, "noproxy"]

    for index, p in enumerate(proxys):
        if p["active"]:
            return [p, index]

    return [None, None]


def active_ru_proxy_url() -> str | None:
    row, _ = get_active_proxy()
    if not row:
        return None
    ru = row.get("ru")
    if not isinstance(ru, dict):
        return None
    scheme = str(ru.get("scheme") or "http").strip()
    host = str(ru.get("hostname") or "").strip()
    port = ru.get("port")
    if not host or port is None:
        return None
    try:
        p = int(port)
    except (TypeError, ValueError):
        return None
    user = str(ru.get("username") or "")
    password = str(ru.get("password") or "")
    if user or password:
        au = urllib.parse.quote(user, safe="")
        apw = urllib.parse.quote(password, safe="")
        return f"{scheme}://{au}:{apw}@{host}:{p}"
    return f"{scheme}://{host}:{p}"


def requests_telegram_proxies() -> dict[str, str] | None:
    u = active_ru_proxy_url()
    if not u:
        return None
    return {"http": u, "https": u}


def aiogram_aiohttp_session():
    from aiogram.client.session.aiohttp import AiohttpSession

    u = active_ru_proxy_url()
    if u:
        return AiohttpSession(proxy=u)
    return AiohttpSession()
