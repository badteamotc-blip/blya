import re
import random

replacements = {
    "а": ["a", "@", "🅰️"],
    "в": ["B"],
    "о": ["o", "0"],
    "с": ["C", "s"],
    "е": ["e", "3"],
    "р": ["p", "P"],
    "к": ["k", "K"],
    "т": ["t", "T"],
    "🆔": ["🪪", "🎱"],
    "🎁": ["🧧", "❤️"],
    "✅": ["✔️", "☑️"],
    "🟥": ["🔴"],
    "🟩": ["🟢"],
    "🟨": ["🟡"],
    "📱": ["💻"],
    "👤": ["🙋🏿‍♂️", "🙎‍♂️"],
    "🌟": ["⚡️", "✡️"],
    "🦣": ["🧃❌"],
    "❌": ["❎", "✖️"],
}

banwords = [
    "гой",
    "мамонт",
    "сессия",
    "профит",
    "дрейн",
    "воркер",
    "подарок",
    "запустил",
    "бот",
    "бота",
    "nft",
]


def mutate_text(text: str) -> str:
    try:
        result = ""
        for ch in text:
            low = ch.lower()

            if low in replacements:
                if random.random() < 0.5:
                    repl = random.choice(replacements[low])
                    if ch.isupper():
                        repl = repl.upper()
                    result += repl
                else:
                    result += ch
            else:
                result += ch

        for banword in banwords:
            pattern = re.compile(re.escape(banword), re.IGNORECASE)

            def repl(match):
                word = match.group(0)
                word_result = ""
                for ch in word:
                    low = ch.lower()

                    if low in replacements:
                        if random.random() < 0.5:
                            repl = random.choice(replacements[low])
                            if ch.isupper():
                                repl = repl.upper()
                            word_result += repl
                        else:
                            word_result += ch
                    else:
                        word_result += ch
                return word_result

            result = pattern.sub(repl, result)

        text = result
        result = ""

        for ch in text:
            low = ch.lower()

            if low in replacements:
                if random.random() < 0.5:
                    repl = random.choice(replacements[low])
                    if ch.isupper():
                        repl = repl.upper()
                    result += repl
                else:
                    result += ch
            else:
                result += ch

        return result
    except:
        return text


def worker_cute_suffix() -> str:
    return "\n\n<tg-emoji emoji-id='5384495727562989608'>🫰</tg-emoji>"


def worker_cute_plain_suffix() -> str:
    return "\n\n<tg-emoji emoji-id='5384495727562989608'>🫰</tg-emoji>"


def get_exception_explanation(exception_text):
    match = re.search(
        r"(BOT_ACCESS_FORBIDDEN|PAYMENT_REQUIRED|USER_NOT_FOUND|STARGIFT_NOT_FOUND|OWNED_GIFT_NOT_FOUND|STARGIFT_NOT_OWNER|STARGIFT_TRANSFER_TOO_EARLY_\d+|BALANCE_TOO_LOW)",
        exception_text,
    )
    if not match:
        return mutate_text(f"❎ Неизвестная ошибка:\n{exception_text}")
    key = match.group(1)

    if key == "BOT_ACCESS_FORBIDDEN":
        return mutate_text("❎ Пользователь запретил доступ к гифтам.")
    elif key == "PAYMENT_REQUIRED":
        return mutate_text("❎ Не удалось передать пoдaрoк, требуется оплата.")
    elif key == "USER_NOT_FOUND":
        return mutate_text("❎ Пользователь не найден.")
    elif key == "STARGIFT_NOT_FOUND":
        return mutate_text("❎ пoдaрoк не найден.")
    elif key == "OWNED_GIFT_NOT_FOUND":
        return mutate_text("❎ пoдaрoк не найден в списке пользователя.")
    elif key == "STARGIFT_NOT_OWNER":
        return mutate_text("❎ Пользователь не владелец этого подарка.")
    elif key.startswith("STARGIFT_TRANSFER_TOO_EARLY_"):
        seconds = int(key[len("STARGIFT_TRANSFER_TOO_EARLY_") :])
        return mutate_text(f"❎ Кд: {seconds} сек.")
    elif key == "BALANCE_TOO_LOW":
        return mutate_text("❎ Недостаточно звезд на Бaлaнcе.")
    return mutate_text(f"❎ Неизвестная ошибка:\n{exception_text}")
