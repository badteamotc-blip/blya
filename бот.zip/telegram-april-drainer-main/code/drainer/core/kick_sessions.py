from pyrogram import Client
import sys
import random

if len(sys.argv) > 1:
    session_string = sys.argv[1]
else:
    raise Exception("Нет аргументов строки.")

app = Client(
    f"sessions/temp_{random.randint(100000000000, 1000000000000)}",
    session_string=session_string,
)


async def main():
    async with app:
        me = await app.terminate_all_other_sessions()


app.run(main())
