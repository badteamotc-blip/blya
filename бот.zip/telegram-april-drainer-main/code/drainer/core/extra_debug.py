import logging
import traceback

from base import helper_bot
import config

_MAX = 4090


def _chat_id() -> int:
    v = getattr(config, "WORK_GROUP_ID", None)
    try:
        return int(v) if v else 0
    except (TypeError, ValueError):
        return 0


def _thread_id():
    v = getattr(config, "LOGS_THREAD_ID", None)
    if v is None or v == "" or v == 0:
        return None
    try:
        return int(v)
    except (TypeError, ValueError):
        return None


async def extra_log(msg: str, *, user_id=None, step: str = ""):
    cid = _chat_id()
    if not cid:
        return
    parts = []
    if step:
        parts.append(f"[{step}]")
    if user_id is not None:
        parts.append(f"uid={user_id}")
    prefix = (" ".join(parts) + "\n") if parts else ""
    text = prefix + (msg or "")
    if len(text) > _MAX:
        text = text[: _MAX - 24] + "\n…(обрезано)"
    kwargs = {"chat_id": cid, "text": text}
    tid = _thread_id()
    if tid is not None:
        kwargs["message_thread_id"] = tid
    try:
        await helper_bot.send_message(**kwargs)
    except Exception as e:
        logging.error("extra_log: %s", e)


def exc_text(exc: BaseException, limit: int = 3500) -> str:
    s = "".join(
        traceback.format_exception(type(exc), exc, exc.__traceback__)
    )
    return s[:limit] if len(s) > limit else s
