import asyncio
from xgift import Gift
import json
import os

# fallback для paths
try:
    import paths
    absolute_path = paths.TEAM_DIR
except (ImportError, AttributeError):
    absolute_path = os.path.dirname(os.path.abspath(__file__))

# прокси
PROXY = os.environ.get("XGIFT_PROXY", "")

async def get_gift_prices(nft_links: list) -> float:
    try:
        with open(f"{absolute_path}/storage/procents.json", "r") as f:
            json_coefficient = json.load(f)
        coefficient = float(json_coefficient.get("coefficient", 0.95))
    except Exception:
        coefficient = 0.95

    # передаём прокси в клиент
    client = Gift(proxy=PROXY)

    try:
        slugs = [link.split("/")[-1].lower() for link in nft_links]
        prices = await client.estimatedPrice(slug=slugs, asset="Ton")
    except Exception as e:
        print(f"Ошибка при получении цен: {e}")
        prices = []
    finally:
        await client.close()

    return sum(prices) * coefficient if prices else 0


async def get_gift_prices_detailed(
    nft_links: list, chunk_size: int = 40
) -> list[tuple[str, float]]:
    if not nft_links:
        return []
    try:
        with open(f"{absolute_path}/storage/procents.json", "r") as f:
            json_coefficient = json.load(f)
        coefficient = float(json_coefficient.get("coefficient", 0.95))
    except Exception:
        coefficient = 0.95

    clean_links = [x.strip() for x in nft_links if x and str(x).strip()]
    if not clean_links:
        return []

    client = Gift(proxy=PROXY)
    out: list[tuple[str, float]] = []
    try:
        for i in range(0, len(clean_links), chunk_size):
            chunk = clean_links[i : i + chunk_size]
            slugs = [link.split("/")[-1].lower() for link in chunk]
            try:
                prices = await client.estimatedPrice(slug=slugs, asset="Ton")
            except Exception:
                prices = []
            if not prices:
                prices = [0.0] * len(chunk)
            for j, link in enumerate(chunk):
                pj = prices[j] * coefficient if j < len(prices) else 0.0
                out.append((link, float(pj)))
        return out
    finally:
        await client.close()


async def main():
    urls = [
        "https://t.me/nft/hexPot-25764",
        "https://t.me/nft/hexPot-25767"
    ]
    result = await get_gift_prices(urls)
    print(result)


if __name__ == "__main__":
    asyncio.run(main())
