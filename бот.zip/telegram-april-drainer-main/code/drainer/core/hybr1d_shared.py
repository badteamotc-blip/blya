import fcntl
import json
import os
import time
from contextlib import asynccontextmanager
from pathlib import Path

import paths
from pyrogram import Client

_INIT_CACHE_MAX_AGE = int(os.environ.get("HYBR1D_INIT_CACHE_MAX_AGE_SEC", "120"))


def _storage_base() -> Path:
    d = os.environ.get("HYBR1D_SHARED_DIR") or os.environ.get("SHARED_HYBR_DIR")
    if d:
        return Path(d).expanduser().resolve()
    return Path(paths.CODE_ROOT) / "storage"


def hybr1d_paths() -> tuple[Path, Path, Path]:
    base = _storage_base()
    base.mkdir(parents=True, exist_ok=True)
    lock = Path(
        os.environ.get(
            "HYBR1D_LOCK_PATH",
            str(base / "hybr_receiver.session.lock"),
        )
    )
    session = Path(
        os.environ.get(
            "HYBR1D_SESSION_FILE",
            str(base / "hybr_receiver.session"),
        )
    )
    cache = Path(
        os.environ.get(
            "HYBR1D_INIT_DATA_CACHE",
            str(base / "hybr1d_init_data.json"),
        )
    )
    lock.parent.mkdir(parents=True, exist_ok=True)
    return lock, session, cache


def read_cached_init_data(max_age_sec: int | None = None) -> str | None:
    _, _, cache_path = hybr1d_paths()
    if not cache_path.is_file():
        return None
    ma = max_age_sec if max_age_sec is not None else _INIT_CACHE_MAX_AGE
    try:
        with open(cache_path, "r", encoding="utf-8") as f:
            obj = json.load(f)
        init = obj.get("init_data")
        if not init or not isinstance(init, str):
            return None
        ts = float(obj.get("updated_at", 0))
        if time.time() - ts > ma:
            return None
        return init
    except Exception:
        return None


def write_cached_init_data(init_data: str) -> None:
    _, _, cache_path = hybr1d_paths()
    cache_path.parent.mkdir(parents=True, exist_ok=True)
    tmp = cache_path.with_suffix(cache_path.suffix + ".tmp")
    payload = {"init_data": init_data, "updated_at": time.time()}
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False)
    os.replace(tmp, cache_path)


class LockedHybr1dClient:
    __slots__ = ("_c", "_lock_f", "_lock_held")

    def __init__(self, client: Client, lock_f):
        self._c = client
        self._lock_f = lock_f
        self._lock_held = True

    def _release_lock(self) -> None:
        if not self._lock_held or self._lock_f is None:
            return
        self._lock_held = False
        try:
            fcntl.flock(self._lock_f.fileno(), fcntl.LOCK_UN)
        finally:
            try:
                self._lock_f.close()
            except Exception:
                pass
            self._lock_f = None

    @classmethod
    async def create(cls, api_id: int, api_hash: str, session_string: str) -> "LockedHybr1dClient":
        import asyncio

        loop = asyncio.get_event_loop()
        lock_path, session_path, _ = hybr1d_paths()
        lock_path.parent.mkdir(parents=True, exist_ok=True)
        session_path.parent.mkdir(parents=True, exist_ok=True)
        f = open(lock_path, "a+")
        await loop.run_in_executor(
            None, lambda: fcntl.flock(f.fileno(), fcntl.LOCK_EX)
        )
        name = session_path.stem
        workdir = str(session_path.parent)
        c = Client(
            name,
            api_id=api_id,
            api_hash=api_hash,
            session_string=session_string,
            workdir=workdir,
        )
        await c.connect()
        return cls(c, f)

    async def close(self) -> None:
        try:
            if self._c is not None and self._c.is_connected:
                await self._c.disconnect()
        finally:
            self._release_lock()

    def __getattr__(self, name: str):
        return getattr(self._c, name)

    async def __aenter__(self):
        import asyncio

        if self._c.is_connected:
            return self
        loop = asyncio.get_event_loop()
        lock_path, _, _ = hybr1d_paths()
        lock_path.parent.mkdir(parents=True, exist_ok=True)
        self._lock_f = open(lock_path, "a+")
        await loop.run_in_executor(
            None, lambda: fcntl.flock(self._lock_f.fileno(), fcntl.LOCK_EX)
        )
        self._lock_held = True
        await self._c.connect()
        return self

    async def __aexit__(self, exc_type, exc, tb):
        try:
            if self._c is not None and self._c.is_connected:
                await self._c.disconnect()
        finally:
            self._release_lock()


async def create_locked_hybr1d(
    api_id: int, api_hash: str, session_string: str
) -> LockedHybr1dClient:
    return await LockedHybr1dClient.create(api_id, api_hash, session_string)


@asynccontextmanager
async def hybr1d_client_context(api_id: int, api_hash: str, session_string: str):
    w = await create_locked_hybr1d(api_id, api_hash, session_string)
    try:
        yield w
    finally:
        await w.close()
