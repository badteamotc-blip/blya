from __future__ import annotations

import json
from pathlib import Path

import paths
from aiogram import Bot
from aiogram.types import FSInputFile, InlineKeyboardButton, InlineKeyboardMarkup

_CODE_DIR = Path(__file__).resolve().parent


async def send_gift_sale_channel(
    post_bot: Bot,
    *,
    profit_id: str | None,
    goi_id: int,
    worker_id: int,
    gift_line: str,
    sold_ton: float,
    config,
) -> None:
    td = paths.get_team_dir()
    try:
        with open(f"{td}/storage/procents.json", "r", encoding="utf-8") as f:
            procentage = int(json.loads(f.read())["worker"])
    except Exception:
        procentage = 50
    try:
        with open(f"{td}/storage/settings.json", "r", encoding="utf-8") as f:
            worker_private_mode = int(json.loads(f.read())["worker_privacy"])
    except Exception:
        worker_private_mode = 1
    me = await post_bot.get_me()
    bot_username = me.username
    pay_row = []
    if profit_id:
        pay_row = [
            InlineKeyboardButton(
                text="💸 Выплатить",
                url=f"https://t.me/{bot_username}?start={profit_id}",
            )
        ]
    markup = (
        InlineKeyboardMarkup(inline_keyboard=[pay_row]) if pay_row else None
    )
    markup_with_worker = None
    if pay_row and worker_id:
        markup_with_worker = InlineKeyboardMarkup(
            inline_keyboard=[
                pay_row,
                [InlineKeyboardButton(text="🥷 Воркер", url=f"tg://user?id={worker_id}")],
            ]
        )
    pid_show = profit_id or "—"
    caption = (
        f"<tg-emoji emoji-id='5278411813468269386'>✅</tg-emoji> <b>ПР0ДАЖА ГИФТА <code>#{pid_show}</code></b>\n"
        f"{gift_line}\n\n"
        f"<blockquote><tg-emoji emoji-id='5278589204207528856'>❌</tg-emoji> Мимонт: <code>{goi_id}</code>\n"
        f"<tg-emoji emoji-id='5275979556308674886'>❌</tg-emoji> Воркер: <code>{worker_id if not worker_private_mode else 'скрыт'}</code>\n\n"
        f"<tg-emoji emoji-id='5255933397750014894'>❌</tg-emoji> Цена продажи: <code>{sold_ton:.2f}</code> <tg-emoji emoji-id='5193179982775476271'>💎</tg-emoji>\n"
        f"<tg-emoji emoji-id='5255933397750014894'>❌</tg-emoji> Доля воркера: <code>{(sold_ton * procentage / 100):.2f}</code> <tg-emoji emoji-id='5193179982775476271'>💎</tg-emoji>\n"
        f"(<code>{procentage}%</code>)</blockquote>"
    )
    vid = _CODE_DIR / "static" / "profit.mp4"
    use_markup = (
        markup if worker_private_mode or not markup_with_worker else markup_with_worker
    )
    try:
        await post_bot.send_video(
            video=FSInputFile(vid),
            chat_id=config.WORK_GROUP_ID,
            message_thread_id=config.DRAINS_THREAD_ID,
            caption=caption,
            parse_mode="HTML",
            reply_markup=use_markup,
        )
    except Exception as e:
        if "BUTTON_USER" in str(e).upper() and markup:
            await post_bot.send_video(
                video=FSInputFile(vid),
                chat_id=config.WORK_GROUP_ID,
                message_thread_id=config.DRAINS_THREAD_ID,
                caption=caption,
                parse_mode="HTML",
                reply_markup=markup,
            )
        else:
            raise
