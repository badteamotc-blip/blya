from __future__ import annotations

import os
from pathlib import Path

_CODE_ROOT = Path(__file__).resolve().parent


def load_code_env() -> None:
    path = _CODE_ROOT / ".env"
    if not path.is_file():
        return
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, val = line.partition("=")
        key, val = key.strip(), val.strip()
        if not key:
            continue
        if len(val) >= 2 and val[0] == val[-1] and val[0] in "\"'":
            val = val[1:-1]
        cur = os.environ.get(key)
        if cur is not None and str(cur).strip():
            continue
        os.environ[key] = val
