import json
import os
import subprocess
import sys
import time
from pathlib import Path

import psutil

CODE_ROOT = Path(__file__).resolve().parent


def _load_service(team_dir: Path) -> dict:
    path = team_dir / "service.json"
    if not path.is_file():
        return {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except (OSError, json.JSONDecodeError):
        return {}


def _team_dir_match(proc_env_team: str, target: str) -> bool:
    if not proc_env_team:
        return False
    a = os.path.abspath(proc_env_team).rstrip("/")
    b = os.path.abspath(target).rstrip("/")
    return a == b


def _argv_targets_script(cmd: list, script: str) -> bool:
    for arg in cmd:
        if arg == script or arg.endswith("/" + script):
            return True
    return False


def _kill_team_script(team_dir: str, script: str) -> list:
    waited = []
    for proc in psutil.process_iter(["pid", "cmdline"]):
        try:
            cmd = proc.info.get("cmdline") or []
            if not cmd:
                continue
            cmd_s = " ".join(cmd)
            if "web_admin_app" in cmd_s or "teams_supervisor" in cmd_s:
                continue
            if not _argv_targets_script(cmd, script):
                continue
            env = proc.environ()
            if not _team_dir_match(env.get("TEAM_DIR", ""), team_dir):
                continue
            proc.terminate()
            waited.append(proc)
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue
    if waited:
        try:
            psutil.wait_procs(waited, timeout=8)
        except Exception:
            pass
        for p in waited:
            try:
                if p.is_running():
                    p.kill()
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                pass
    return waited


def restart_team_scripts(scripts: list[str], team_dir: str) -> None:
    team_path = Path(team_dir).resolve()
    team_s = str(team_path)
    svc = _load_service(team_path)
    stack_host = os.environ.get("STACK_BIND_HOST", "").strip()
    web_port = int(svc.get("web_port", 8000))
    web_host = stack_host or str(svc.get("web_host", "127.0.0.1"))
    py = sys.executable

    for script in scripts:
        _kill_team_script(team_s, script)
        time.sleep(0.5)
        if script == "web.py":
            env = {
                **os.environ,
                "TEAM_DIR": team_s,
                "WEB_HOST": web_host,
                "WEB_PORT": str(web_port),
                "WEB_RELOAD": "0",
            }
        else:
            env = {**os.environ, "TEAM_DIR": team_s}
        subprocess.Popen(
            [py, script],
            cwd=str(CODE_ROOT),
            env=env,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
