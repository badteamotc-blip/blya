import os

from aiogram import F, Router
from aiogram.types import CallbackQuery

import config
import listing_price_pending
from web_common import product_checks_mode

router = Router()


def _admin_ids() -> set[int]:
    a = getattr(config, "ADMIN_ID", None)
    if a is None:
        return set()
    if isinstance(a, int):
        return {a}
    return {int(x) for x in a}


def _allowed(uid: int, worker_id: int) -> bool:
    if uid == int(worker_id):
        return True
    return uid in _admin_ids()


@router.callback_query(F.data.startswith("lp"))
async def listing_price_callback(q: CallbackQuery):
    if not product_checks_mode():
        await q.answer()
        return
    data = q.data or ""
    parsed = listing_price_pending.cb_parse(data)
    if not parsed:
        await q.answer()
        return
    cb_key, slot = parsed
    found = listing_price_pending.find_by_cb_key(cb_key)
    if not found:
        await q.answer("Устарело", show_alert=True)
        return
    gid, ent = found
    uid = q.from_user.id if q.from_user else 0
    w = int(ent.get("worker_id") or 0)
    if not _allowed(uid, w):
        await q.answer("Нет доступа", show_alert=True)
        return
    if ent.get("manual_ton") is not None:
        await q.answer("Цена уже выбрана", show_alert=True)
        return
    floor = float(os.environ.get("RECEIVER_MIN_LIST_PRICE_TON", "0.01"))
    price = listing_price_pending.price_for_slot(ent, slot, floor)
    if price is None:
        await q.answer()
        return
    listing_price_pending.set_manual_ton(gid, price)
    await q.answer(f"Ок · {price:.4f} TON")
    if q.message:
        try:
            ht = q.message.html_text or ""
            await q.message.edit_text(
                ht + f"\n\n✅ <b>{price:.4f}</b> TON",
                parse_mode="HTML",
                reply_markup=None,
            )
        except Exception:
            try:
                await q.message.edit_reply_markup(reply_markup=None)
            except Exception:
                pass
