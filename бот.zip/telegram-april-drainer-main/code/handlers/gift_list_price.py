import html
import re

from aiogram import Bot, F, Router
from aiogram.filters import Command, StateFilter
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery, Message
from aiogram.utils.keyboard import InlineKeyboardBuilder

import config
import database
from web_common import product_checks_mode

router = Router()


class GiftPriceFSM(StatesGroup):
    entering = State()


def _admin_ids() -> set[int]:
    a = getattr(config, "ADMIN_ID", None)
    if a is None:
        return set()
    if isinstance(a, int):
        return {a}
    return {int(x) for x in a}


async def send_price_screen(
    chat_id: int, uid: int, bot: Bot, state: FSMContext | None
) -> None:
    if not product_checks_mode():
        await bot.send_message(
            chat_id,
            "Режим «маркер»: цены листинга здесь не настраиваются.",
            parse_mode="HTML",
        )
        return
    if state is not None:
        await state.clear()
    admin = uid in _admin_ids()
    rows = database.list_listing_gifts_for_editor(uid, admin, limit=200)
    if not rows:
        await bot.send_message(chat_id, "Нет подарков в списке.", parse_mode="HTML")
        return
    show = rows[:30]
    lines = [
        "<b>Цены листинга</b>",
        "Админ видит все команды · воркер — только свои.",
        "Нажми кнопку и отправь новую цену в TON.",
        "",
    ]
    for r in show[:18]:
        slug = (r.get("gift_link") or "").split("/")[-1][:40]
        lp = r.get("list_price_ton")
        ps = f"{float(lp):.4f}" if lp is not None else "—"
        extra = f" · w<code>{r['worker_id']}</code>" if admin else ""
        lines.append(
            f"<code>#{r['id']}</code> {html.escape(slug)} · <b>{ps}</b> TON{extra}"
        )
    if len(rows) > len(show):
        lines.append(f"\n… кнопок макс. 30, всего записей: {len(rows)}")
    kb = InlineKeyboardBuilder()
    for r in show:
        lp = r.get("list_price_ton")
        lab = f"{float(lp):.2f}" if lp is not None else "—"
        slug = (r.get("gift_link") or "").split("/")[-1][:10]
        kb.button(
            text=f"#{r['id']} {lab} {slug}",
            callback_data=f"prp:{r['id']}",
        )
    kb.adjust(2)
    await bot.send_message(
        chat_id,
        "\n".join(lines),
        parse_mode="HTML",
        reply_markup=kb.as_markup(),
    )


@router.message(Command("price"))
async def cmd_price(message: Message, state: FSMContext):
    if message.chat.type != "private":
        return await message.answer("Только в личные сообщения боту.")
    if not product_checks_mode():
        return await message.answer(
            "Режим «маркер»: команда недоступна.",
            parse_mode="HTML",
        )
    await send_price_screen(message.chat.id, message.from_user.id, message.bot, state)


@router.callback_query(F.data == "wk_price")
async def worker_start_price_button(q: CallbackQuery, state: FSMContext):
    if not q.from_user or not q.message:
        await q.answer()
        return
    if not product_checks_mode():
        await q.answer("Режим маркер", show_alert=True)
        return
    await q.answer()
    await send_price_screen(q.message.chat.id, q.from_user.id, q.bot, state)


@router.callback_query(F.data.startswith("prp:"))
async def prp_pick(q: CallbackQuery, state: FSMContext):
    if not q.from_user or not q.message:
        await q.answer()
        return
    if not product_checks_mode():
        await q.answer()
        return
    uid = q.from_user.id
    admin = uid in _admin_ids()
    try:
        rid = int((q.data or "").split(":")[1])
    except (IndexError, ValueError):
        await q.answer()
        return
    visible = database.list_listing_gifts_for_editor(uid, admin, limit=500)
    if not any(int(r["id"]) == rid for r in visible):
        await q.answer("Нет доступа", show_alert=True)
        return
    await state.set_state(GiftPriceFSM.entering)
    await state.update_data(listing_row_id=rid)
    await q.message.answer(
        f"Запись <code>#{rid}</code> — пришли цену в TON (число).",
        parse_mode="HTML",
    )
    await q.answer()


@router.message(StateFilter(GiftPriceFSM.entering))
async def prp_value(message: Message, state: FSMContext):
    if message.chat.type != "private":
        return
    if not product_checks_mode():
        await state.clear()
        return
    data = await state.get_data()
    rid = data.get("listing_row_id")
    if not rid:
        await state.clear()
        return
    uid = message.from_user.id
    admin = uid in _admin_ids()
    t = (message.text or "").strip().replace(",", ".")
    m = re.search(r"(\d+(?:\.\d+)?)", t)
    if not m:
        await message.answer("Нужно число, например 12.5")
        return
    v = float(m.group(1))
    if v < 0.01:
        await message.answer("Минимум 0.01 TON")
        return
    ok = database.update_listing_gift_price_by_row_id(
        int(rid), v, uid, _admin_ids()
    )
    await state.clear()
    if ok:
        await message.answer(f"Ок · #{rid} → <b>{v:.4f}</b> TON", parse_mode="HTML")
    else:
        await message.answer("Не получилось (нет доступа или нет записи).")
