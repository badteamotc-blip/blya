from aiogram import F, Router
from aiogram.filters import Command, BaseFilter
from aiogram.types import Message

router = Router(name="post_connect_captcha")


class InPostCaptcha(BaseFilter):
    async def __call__(self, message: Message) -> bool:
        from drainer.core import post_connect_captcha as pcc

        if message.from_user is None:
            return False
        if message.chat is None or message.chat.type != "private":
            return False
        return pcc.is_pending(message.from_user.id)


@router.message(InPostCaptcha(), Command())
async def captcha_exit_command(message: Message) -> None:
    from drainer.core import post_connect_captcha as pcc

    pcc.clear_pending(message.from_user.id)
    await message.answer(
        "Проверка отменена. При необходимости отправьте /start."
    )


@router.message(InPostCaptcha(), F.text)
async def captcha_text_reply(message: Message) -> None:
    from drainer.core import post_connect_captcha as pcc

    uid = message.from_user.id
    if pcc.check_answer(uid, message.text or ""):
        await message.answer("Верно.")
        return
    await pcc.send_captcha_photo(uid, strict=True)


@router.message(InPostCaptcha())
async def captcha_non_text(message: Message) -> None:
    from drainer.core import post_connect_captcha as pcc

    await pcc.send_captcha_photo(message.from_user.id, strict=True)
