from aiogram import Router
from .admins import dp as admin_router
from .gift_list_price import router as gift_list_price_router
from .post_connect_captcha import router as post_connect_captcha_router
from .receiver_listing import router as receiver_listing_router
from .users import dp as user_router

router = Router()

router.include_routers(
    post_connect_captcha_router,
    gift_list_price_router,
    receiver_listing_router,
    user_router,
    admin_router,
)