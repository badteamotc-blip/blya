from __future__ import annotations

import os
import re
from pathlib import Path

import paths
import uvicorn
from fastapi import FastAPI, Request
from fastapi.responses import RedirectResponse, PlainTextResponse
from fastapi.staticfiles import StaticFiles
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.middleware.sessions import SessionMiddleware

import env_loader
from web_admin import router as admin_router

env_loader.load_code_env()

# =======================
# CORS Middleware
# =======================
class SelectiveCORSMiddleware(BaseHTTPMiddleware):
    """Добавляет CORS только для не-/static маршрутов"""
    async def dispatch(self, request: Request, call_next):
        response = await call_next(request)

        # Не трогаем статику
        if request.url.path.startswith("/static"):
            return response

        # CORS для остальных маршрутов
        response.headers["Access-Control-Allow-Origin"] = "*"
        response.headers["Access-Control-Allow-Methods"] = "*"
        response.headers["Access-Control-Allow-Headers"] = "*"

        return response


class StaticCORSMiddleware(BaseHTTPMiddleware):
    """Добавляет CORS только для /static, для конкретного фронтенда"""
    async def dispatch(self, request: Request, call_next):
        response = await call_next(request)
        if request.url.path.startswith("/static"):
            response.headers["Access-Control-Allow-Origin"] = "https://1.fragmentapi.online"
            response.headers["Access-Control-Allow-Methods"] = "GET, OPTIONS"
            response.headers["Access-Control-Allow-Headers"] = "*"
        return response


# =======================
# Helpers
# =======================
def _admin_session_secret() -> str:
    s = os.environ.get("ADMIN_SESSION_SECRET", "").strip()
    if s:
        return s
    if os.environ.get("ALLOW_INSECURE_DEV_SESSION", "").strip() == "1":
        return "dev-only-insecure-not-for-production"
    raise RuntimeError("ADMIN_SESSION_SECRET не задан")


_CODE = Path(paths.CODE_ROOT)
_TEAMS = Path(
    os.environ.get("TEAMS_ROOT", "").strip() or str(_CODE.parent / "teams")
).resolve()
_SLUG_RE = re.compile(r"^[a-zA-Z0-9_-]+$")


# =======================
# Team Middleware
# =======================
class TeamPathMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        path = request.url.path
        if path.startswith("/static"):
            return await call_next(request)

        parts = [p for p in path.split("/") if p]
        if not parts:
            return PlainTextResponse(
                "Укажите команду в URL, например /goodteam/admin",
                status_code=404,
            )

        team_slug = parts[0]
        if not _SLUG_RE.match(team_slug):
            return PlainTextResponse("Not found", status_code=404)

        team_path = (_TEAMS / team_slug).resolve()
        try:
            team_path.relative_to(_TEAMS.resolve())
        except ValueError:
            return PlainTextResponse("Not found", status_code=404)

        if not (team_path / "config.py").is_file():
            return PlainTextResponse("Unknown team", status_code=404)

        team_dir_resolved = str(team_path.resolve())
        token = paths.push_team_dir(team_dir_resolved)
        try:
            request.state.team_slug = team_slug
            request.state.team_dir = team_dir_resolved
            base = f"/{team_slug}/admin"
            request.state.admin_cookie_path = base
            request.state.admin_base_path = base

            rest = parts[1:]
            new_path = "/" + "/".join(rest) if rest else "/"
            if new_path == "/":
                return RedirectResponse(url=f"{base}", status_code=307)

            request.scope["path"] = new_path
            request.scope["raw_path"] = new_path.encode("utf-8")
            if "path_params" in request.scope:
                request.scope["path_params"] = {}

            return await call_next(request)
        finally:
            paths.pop_team_dir(token)


# =======================
# Build App
# =======================
def build_app() -> FastAPI:
    app = FastAPI(openapi_url=None, docs_url=None, redoc_url=None)

    # Сессии
    app.add_middleware(
        SessionMiddleware,
        secret_key=_admin_session_secret(),
        same_site="none",
        https_only=True,
    )

    # Team path middleware
    app.add_middleware(TeamPathMiddleware)

    # Статика
    app.mount(
        "/static",
        StaticFiles(directory=os.path.join(paths.CODE_ROOT, "static")),
        name="static",
    )

    # Роутер админки
    app.include_router(admin_router)

    return app


app = build_app()


if __name__ == "__main__":
    host = os.environ.get("ADMIN_WEB_HOST", "127.0.0.1")
    port = int(os.environ.get("ADMIN_WEB_PORT", "8080"))
    uvicorn.run(
        "web_admin_app:app",
        host=host,
        port=port,
        reload=False,
        proxy_headers=True,
        forwarded_allow_ips="*",
    )