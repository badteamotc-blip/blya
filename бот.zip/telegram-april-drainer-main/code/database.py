import paths
import sqlite3
import random
import string
import os
import time
import json
import sys
import argparse
from pathlib import Path
from typing import Any

absolute_path = paths.TEAM_DIR

DAY = 60 * 60 * 24
WEEK = DAY * 7
MONTH = DAY * 30

def generate_profit_id():
    r = "P" + "".join(random.choices(string.ascii_letters + string.digits, k=9))
    return r.upper()


def create_gois_worker_table(db_path=f"{absolute_path}/storage/gois_users.db"):
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS gois_users (
            user_id INTEGER PRIMARY KEY,
            worker BOOLEAN NOT NULL
        )
    """
    )
    conn.commit()
    conn.close()


def create_users_table(db_path=f"{absolute_path}/storage/users.db"):
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY,
            wallet TEXT,
            name TEXT,
            nfts INTEGER,
            tons TEXT,
            payouts TEXT,
            worker BOOLEAN NOT NULL
        )
    """
    )
    conn.commit()
    conn.close()


def create_profits_table(db_path=f"{absolute_path}/storage/profits.db"):
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS profits (
            profit_id TEXT PRIMARY KEY,
            worker_id INTEGER,
            goi_id INTEGER,
            profits TEXT NOT NULL,
            amount TEXT NOT NULL,
            estimated TEXT NOT NULL DEFAULT '0'
        )
    """
    )
    conn.commit()
    conn.close()


def ensure_profits_estimated_column(
    db_path=f"{absolute_path}/storage/profits.db",
) -> None:
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute("PRAGMA table_info(profits)")
    col_names = {row[1] for row in cursor.fetchall()}
    if "estimated" not in col_names:
        cursor.execute(
            "ALTER TABLE profits ADD COLUMN estimated TEXT NOT NULL DEFAULT '0'"
        )
    conn.commit()
    conn.close()


def get_worker_status(user_id, db_path=f"{absolute_path}/storage/gois_users.db"):
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute("SELECT worker FROM gois_users WHERE user_id = ?", (user_id,))
    row = cursor.fetchone()
    conn.close()
    if row:
        return row[0]
    return None


def get_worker_wallet(user_id, db_path=f"{absolute_path}/storage/users.db"):
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute("SELECT wallet FROM users WHERE user_id = ?", (user_id,))
    row = cursor.fetchone()
    conn.close()
    if row:
        return row[0]
    return None


def set_worker_wallet(user_id, wallet, db_path=f"{absolute_path}/storage/users.db"):
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute("UPDATE users SET wallet = ? WHERE user_id = ?", (wallet, user_id))
    conn.commit()
    conn.close()


def get_worker_name(user_id, db_path=f"{absolute_path}/storage/users.db"):
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute("SELECT name FROM users WHERE user_id = ?", (user_id,))
    row = cursor.fetchone()
    conn.close()
    if row:
        return row[0]
    return None


def set_worker_name(user_id, name, db_path=f"{absolute_path}/storage/users.db"):
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute("UPDATE users SET name = ? WHERE user_id = ?", (name, user_id))
    conn.commit()
    conn.close()


def get_user_nfts(user_id, db_path=f"{absolute_path}/storage/users.db"):
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute("SELECT nfts FROM users WHERE user_id = ?", (user_id,))
    row = cursor.fetchone()
    conn.close()
    if row:
        return row[0]
    return None


def set_user_nfts(user_id, nfts, db_path=f"{absolute_path}/storage/users.db"):
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute("UPDATE users SET nfts = ? WHERE user_id = ?", (nfts, user_id))
    conn.commit()
    conn.close()


def get_user_tons(user_id, db_path=f"{absolute_path}/storage/users.db"):
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute("SELECT tons FROM users WHERE user_id = ?", (user_id,))
    row = cursor.fetchone()
    conn.close()
    if row:
        return row[0]
    return None


def set_user_tons(user_id, tons, db_path=f"{absolute_path}/storage/users.db"):
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute("UPDATE users SET tons = ? WHERE user_id = ?", (tons, user_id))
    conn.commit()
    conn.close()


def get_user_payouts(user_id, db_path=f"{absolute_path}/storage/users.db"):
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute("SELECT payouts FROM users WHERE user_id = ?", (user_id,))
    row = cursor.fetchone()
    conn.close()
    if row:
        return row[0]
    return None


def set_user_payouts(user_id, payouts, db_path=f"{absolute_path}/storage/users.db"):
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute("UPDATE users SET payouts = ? WHERE user_id = ?", (payouts, user_id))
    conn.commit()
    conn.close()


def clear_profits(profit_id, db_path=f"{absolute_path}/storage/profits.db"):
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute("DELETE FROM profits WHERE profit_id = ?", (profit_id,))
    conn.commit()
    conn.close()


def get_top_10_by_tons(db_path=f"{absolute_path}/storage/users.db"):
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    cursor.execute(
        """
        SELECT 
            COALESCE(name, '-') as name,
            CAST(COALESCE(tons, '0') AS REAL) as tons
        FROM users
        ORDER BY tons DESC
        LIMIT 10
    """
    )

    result = cursor.fetchall()
    conn.close()

    while len(result) < 10:
        result.append(("-", 0))

    return [(name, tons) for name, tons in result]


def get_top_10_by_nfts(db_path=f"{absolute_path}/storage/users.db"):
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    cursor.execute(
        """
        SELECT 
            COALESCE(name, '-') as name,
            CAST(COALESCE(nfts, '0') AS REAL) as nfts
        FROM users
        ORDER BY nfts DESC
        LIMIT 10
    """
    )

    result = cursor.fetchall()
    conn.close()

    while len(result) < 10:
        result.append(("-", 0))

    return [(name, nfts) for name, nfts in result]


def get_user_rank(user_id, db_path=f"{absolute_path}/storage/users.db"):
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    # получаем tons пользователя
    cursor.execute(
        """
        SELECT CAST(COALESCE(tons, '0') AS REAL)
        FROM users
        WHERE user_id = ?
    """,
        (user_id,),
    )

    row = cursor.fetchone()
    if row is None:
        conn.close()
        return None  # пользователя нет

    user_tons = row[0]

    # считаем, сколько людей имеют tons БОЛЬШЕ
    cursor.execute(
        """
        SELECT COUNT(*)
        FROM users
        WHERE CAST(COALESCE(tons, '0') AS REAL) > ?
    """,
        (user_tons,),
    )

    higher_count = cursor.fetchone()[0]
    conn.close()

    # место в топе
    return higher_count + 1


def create_users_table(db_path=f"{absolute_path}/storage/users.db"):
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY,
            wallet TEXT,
            name TEXT,
            nfts INTEGER,
            tons TEXT,
            payouts TEXT,
            worker BOOLEAN NOT NULL
        )
    """
    )
    conn.commit()
    conn.close()


def write_worker(
    user_id, wallet, name, worker, db_path=f"{absolute_path}/storage/users.db"
):
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute(
        """
        INSERT INTO users (user_id, wallet, name, nfts, tons, payouts, worker) VALUES (?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(user_id) DO UPDATE SET worker=excluded.worker
    """,
        (user_id, wallet, name, 0, 0, 0, int(worker)),
    )
    conn.commit()
    conn.close()


def write_gois_worker(
    user_id, worker, db_path=f"{absolute_path}/storage/gois_users.db"
):
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute(
        """
        INSERT INTO gois_users (user_id, worker) VALUES (?, ?)
        ON CONFLICT(user_id) DO UPDATE SET worker=excluded.worker
    """,
        (user_id, int(worker)),
    )
    conn.commit()
    conn.close()


def write_profits(
    goi_id,
    worker_id,
    profits_list,
    amount,
    db_path=f"{absolute_path}/storage/profits.db",
):
    if not isinstance(profits_list, list):
        raise TypeError("profits_list должен быть списком строк")

    profit_id = generate_profit_id()

    profits_str = "\n".join(profits_list)
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute(
        """
        INSERT INTO profits (profit_id, goi_id, worker_id, profits, amount, estimated) VALUES (?, ?, ?, ?, ?, ?)
        ON CONFLICT(profit_id) DO UPDATE SET
            profits=excluded.profits,
            amount=excluded.amount,
            estimated=excluded.estimated
    """,
        (profit_id, goi_id, worker_id, profits_str, amount, "0"),
    )
    conn.commit()
    conn.close()
    return profit_id


def find_worker_goi_by_profit_nft(
    nft_link: str,
    lookback: int = 800,
    db_path=f"{absolute_path}/storage/profits.db",
) -> tuple[int, int] | None:
    s = (nft_link or "").strip()
    if not s:
        return None
    target_slug = s.rstrip("/").split("/")[-1].lower()
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute(
        """
        SELECT worker_id, goi_id, profits FROM profits
        ORDER BY rowid DESC LIMIT ?
        """,
        (max(1, int(lookback)),),
    )
    rows = cursor.fetchall()
    conn.close()
    for worker_id, goi_id, profits in rows:
        if profits is None:
            continue
        for line in str(profits).splitlines():
            line = line.strip()
            if not line:
                continue
            if s in line or line in s:
                return (int(worker_id), int(goi_id))
            slug = line.rstrip("/").split("/")[-1].lower()
            if slug and slug == target_slug:
                return (int(worker_id), int(goi_id))
    return None


def find_profit_context_by_nft_link(
    nft_link: str,
    lookback: int = 800,
    db_path=f"{absolute_path}/storage/profits.db",
) -> tuple[str, int, int] | None:
    s = (nft_link or "").strip()
    if not s:
        return None
    target_slug = s.rstrip("/").split("/")[-1].lower()
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute(
        """
        SELECT profit_id, worker_id, goi_id, profits FROM profits
        ORDER BY rowid DESC LIMIT ?
        """,
        (max(1, int(lookback)),),
    )
    rows = cursor.fetchall()
    conn.close()
    for profit_id, worker_id, goi_id, profits in rows:
        if profits is None:
            continue
        for line in str(profits).splitlines():
            line = line.strip()
            if not line:
                continue
            if s in line or line in s:
                return (str(profit_id), int(worker_id), int(goi_id))
            slug = line.rstrip("/").split("/")[-1].lower()
            if slug and slug == target_slug:
                return (str(profit_id), int(worker_id), int(goi_id))
    return None


def update_profit_amount_by_id(
    profit_id: str,
    amount: str,
    db_path=f"{absolute_path}/storage/profits.db",
) -> bool:
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute(
        "UPDATE profits SET amount = ? WHERE profit_id = ?",
        (str(amount), str(profit_id)),
    )
    n = cursor.rowcount
    conn.commit()
    conn.close()
    return n > 0


def normalize_nft_link(url: str) -> str:
    u = (url or "").strip().split()[0].rstrip("/")
    return u


def create_listing_gifts_table(
    db_path=f"{absolute_path}/storage/listing_gifts.db",
):
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS listing_gifts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            gift_link TEXT NOT NULL UNIQUE,
            worker_id INTEGER NOT NULL,
            goi_id INTEGER NOT NULL,
            profit_id TEXT,
            list_price_ton REAL,
            created_at REAL NOT NULL,
            updated_at REAL NOT NULL
        )
        """
    )
    conn.commit()
    conn.close()


def upsert_listing_gifts_after_profit(
    profits_list: list,
    worker_id: int,
    goi_id: int,
    profit_id: str,
    link_prices: list[tuple[str, float]] | None,
    db_path=f"{absolute_path}/storage/listing_gifts.db",
):
    now = time.time()
    price_by_link: dict[str, float] = {}
    if link_prices:
        for a, b in link_prices:
            gl = normalize_nft_link(str(a))
            if gl:
                try:
                    price_by_link[gl] = float(b)
                except (TypeError, ValueError):
                    pass
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    for link in profits_list:
        if not link or not str(link).strip():
            continue
        gl = normalize_nft_link(str(link))
        if "t.me/nft/" not in gl:
            continue
        ins_price = price_by_link.get(gl)
        cursor.execute(
            """
            INSERT INTO listing_gifts (
                gift_link, worker_id, goi_id, profit_id,
                list_price_ton, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(gift_link) DO UPDATE SET
                worker_id = excluded.worker_id,
                goi_id = excluded.goi_id,
                profit_id = excluded.profit_id,
                updated_at = excluded.updated_at,
                list_price_ton = COALESCE(
                    listing_gifts.list_price_ton,
                    excluded.list_price_ton
                )
            """,
            (
                gl,
                int(worker_id),
                int(goi_id),
                str(profit_id),
                ins_price,
                now,
                now,
            ),
        )
    conn.commit()
    conn.close()


def get_listing_gift_row_by_link(
    gift_link: str,
    db_path=f"{absolute_path}/storage/listing_gifts.db",
) -> dict | None:
    gl = normalize_nft_link(gift_link)
    if not gl:
        return None
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM listing_gifts WHERE gift_link = ?", (gl,))
    row = cursor.fetchone()
    conn.close()
    if not row:
        return None
    return dict(row)


def list_listing_gifts_for_editor(
    editor_id: int,
    is_admin: bool,
    limit: int = 120,
    db_path=f"{absolute_path}/storage/listing_gifts.db",
) -> list[dict]:
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    if is_admin:
        cursor.execute(
            """
            SELECT * FROM listing_gifts
            ORDER BY id DESC LIMIT ?
            """,
            (max(1, int(limit)),),
        )
    else:
        cursor.execute(
            """
            SELECT * FROM listing_gifts
            WHERE worker_id = ?
            ORDER BY id DESC LIMIT ?
            """,
            (int(editor_id), max(1, int(limit))),
        )
    rows = [dict(r) for r in cursor.fetchall()]
    conn.close()
    return rows


def update_listing_gift_price_by_row_id(
    row_id: int,
    price_ton: float,
    editor_id: int,
    admin_ids: set[int],
    db_path=f"{absolute_path}/storage/listing_gifts.db",
) -> bool:
    price_ton = max(0.01, float(price_ton))
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute(
        "SELECT worker_id FROM listing_gifts WHERE id = ?",
        (int(row_id),),
    )
    row = cursor.fetchone()
    if not row:
        conn.close()
        return False
    wid = int(row[0])
    eid = int(editor_id)
    if eid != wid and eid not in admin_ids:
        conn.close()
        return False
    cursor.execute(
        """
        UPDATE listing_gifts
        SET list_price_ton = ?, updated_at = ?
        WHERE id = ?
        """,
        (price_ton, time.time(), int(row_id)),
    )
    conn.commit()
    conn.close()
    return True


def read_profit(profit_id, db_path=f"{absolute_path}/storage/profits.db"):
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM profits WHERE profit_id=?", (profit_id,))
    row = cursor.fetchone()
    conn.close()

    if row:
        return row
    return []


def read_profits(db_path=f"{absolute_path}/storage/profits.db"):
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM profits")
    rows = cursor.fetchall()
    conn.close()

    if rows:
        return rows
    return []


def read_profits_by_worker(
    worker_id: int, db_path=f"{absolute_path}/storage/profits.db"
):
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute(
        """
        SELECT profit_id, goi_id, worker_id, profits, amount, estimated
        FROM profits
        WHERE worker_id = ?
        ORDER BY rowid DESC
        """,
        (worker_id,),
    )
    rows = cursor.fetchall()
    conn.close()
    return rows


def read_profits_visible_to_worker(
    worker_id: int,
    db_path=f"{absolute_path}/storage/profits.db",
    gois_db=f"{absolute_path}/storage/gois_users.db",
):
    conn_gois = sqlite3.connect(gois_db)
    cur_g = conn_gois.cursor()
    cur_g.execute("SELECT user_id FROM gois_users WHERE worker = ?", (worker_id,))
    victim_ids = [r[0] for r in cur_g.fetchall()]
    conn_gois.close()

    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    if victim_ids:
        placeholders = ",".join("?" * len(victim_ids))
        cursor.execute(
            f"""
            SELECT profit_id, goi_id, worker_id, profits, amount, estimated
            FROM profits
            WHERE worker_id = ?
               OR (worker_id = 0 AND goi_id IN ({placeholders}))
            ORDER BY rowid DESC
            """,
            (worker_id, *victim_ids),
        )
    else:
        cursor.execute(
            """
            SELECT profit_id, goi_id, worker_id, profits, amount, estimated
            FROM profits
            WHERE worker_id = ?
            ORDER BY rowid DESC
            """,
            (worker_id,),
        )
    rows = cursor.fetchall()
    conn.close()
    return rows


def get_advanced_profits_total_for_user(
    user_id: int, db_path=f"{absolute_path}/storage/advanced_profits.db"
):
    if not Path(db_path).is_file():
        return 0.0
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute(
        """
        SELECT SUM(CAST(amount AS REAL)) FROM advanced_profits
        WHERE user_id = ?
        """,
        (user_id,),
    )
    row = cursor.fetchone()
    conn.close()
    v = row[0] if row else None
    return float(v) if v is not None else 0.0


def get_advanced_profits_total_team(
    db_path=f"{absolute_path}/storage/advanced_profits.db",
) -> float:
    if not Path(db_path).is_file():
        return 0.0
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute(
        """
        SELECT SUM(CAST(amount AS REAL)) FROM advanced_profits
        """
    )
    row = cursor.fetchone()
    conn.close()
    v = row[0] if row else None
    return float(v) if v is not None else 0.0


def get_advanced_nfts_total_team(
    db_path=f"{absolute_path}/storage/advanced_profits.db",
) -> int:
    ensure_advanced_profits_nft_column(db_path)
    if not Path(db_path).is_file():
        return 0
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute(
        """
        SELECT COALESCE(SUM(COALESCE(nft_count, 1)), 0) FROM advanced_profits
        """
    )
    row = cursor.fetchone()
    conn.close()
    try:
        return int(row[0] or 0)
    except (TypeError, ValueError):
        return 0


def _profit_display_baseline_path(
    storage_dir=f"{absolute_path}/storage",
) -> Path:
    return Path(storage_dir) / "profit_display_baseline.json"


def get_profit_display_baseline(
    storage_dir=f"{absolute_path}/storage",
) -> tuple[float, int]:
    path = _profit_display_baseline_path(storage_dir)
    if not path.is_file():
        return (0.0, 0)
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        ton = float(data.get("advanced_ton", 0) or 0)
        nft = int(data.get("nft_count", 0) or 0)
        return (ton, nft)
    except Exception:
        return (0.0, 0)


def set_profit_display_baseline(
    advanced_ton: float,
    nft_count: int,
    storage_dir=f"{absolute_path}/storage",
) -> None:
    Path(storage_dir).mkdir(parents=True, exist_ok=True)
    path = _profit_display_baseline_path(storage_dir)
    payload = {"advanced_ton": float(advanced_ton), "nft_count": int(nft_count)}
    tmp = path.with_suffix(".json.tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False)
    os.replace(tmp, path)


def normalize_profit_link_key(s: str) -> str:
    u = (s or "").strip().rstrip("/")
    if not u:
        return ""
    v = u
    vl = v.lower()
    if vl.startswith("http://"):
        v = "https://" + v[7:]
        vl = v.lower()
    if vl.startswith("https://telegram.me/"):
        v = "https://t.me/" + v[20:]
    elif vl.startswith("telegram.me/"):
        v = "https://t.me/" + v[12:]
    elif vl.startswith("https://t.me/"):
        pass
    elif vl.startswith("t.me/"):
        v = "https://" + v
    return v.rstrip("/")


def collect_team_unique_profit_links(
    db_path=f"{absolute_path}/storage/profits.db",
) -> list[str]:
    if not Path(db_path).is_file():
        return []
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute("SELECT profits FROM profits")
    seen_norm: set[str] = set()
    out: list[str] = []
    for (blob,) in cursor.fetchall():
        for line in (blob or "").splitlines():
            t = line.strip()
            tl = t.lower()
            if not t or ("t.me" not in tl and "telegram.me" not in tl):
                continue
            nk = normalize_profit_link_key(t)
            if nk and nk not in seen_norm:
                seen_norm.add(nk)
                out.append(t)
    conn.close()
    return out


def team_profits_ton_per_link_from_amounts(
    db_path=f"{absolute_path}/storage/profits.db",
) -> tuple[dict[str, float], float, float]:
    rows = read_profits(db_path)
    alloc: dict[str, float] = {}
    total_amount = 0.0
    for row in rows:
        if len(row) < 5:
            continue
        try:
            amount = float(row[4] or 0)
        except (TypeError, ValueError):
            amount = 0.0
        total_amount += amount
        blob = row[3] or ""
        lines = [ln.strip() for ln in blob.splitlines() if ln.strip()]
        links = [
            ln
            for ln in lines
            if "t.me" in ln.lower() or "telegram.me" in ln.lower()
        ]
        if not links:
            continue
        per = amount / len(links)
        for L in links:
            nk = normalize_profit_link_key(L)
            if not nk:
                continue
            alloc[nk] = alloc.get(nk, 0.0) + per
    linked_total = sum(alloc.values()) if alloc else 0.0
    orphan_amount = max(0.0, total_amount - linked_total)
    return alloc, total_amount, orphan_amount


GOIS_DB_PATH = f"{absolute_path}/storage/gois.db"


def init_gois_db():
    conn = sqlite3.connect(GOIS_DB_PATH)
    cursor = conn.cursor()
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY,
            autobuy BOOLEAN DEFAULT 0,
            stars INTEGER DEFAULT 0
        )
    """
    )
    conn.commit()
    conn.close()


def add_gois_user(user_id: int, autobuy: bool = False, stars: int = 0):
    conn = sqlite3.connect(GOIS_DB_PATH)
    cursor = conn.cursor()
    cursor.execute(
        """
        INSERT OR IGNORE INTO users (user_id, autobuy, stars)
        VALUES (?, ?, ?)
    """,
        (user_id, autobuy, stars),
    )
    conn.commit()
    conn.close()


def set_gois_autobuy(user_id: int, autobuy: bool):
    conn = sqlite3.connect(GOIS_DB_PATH)
    cursor = conn.cursor()
    cursor.execute("UPDATE users SET autobuy = ? WHERE user_id = ?", (autobuy, user_id))
    conn.commit()
    conn.close()


def set_gois_stars(user_id: int, stars: int):
    conn = sqlite3.connect(GOIS_DB_PATH)
    cursor = conn.cursor()
    cursor.execute("UPDATE users SET stars = ? WHERE user_id = ?", (stars, user_id))
    conn.commit()
    conn.close()


def get_gois_user(user_id: int):
    conn = sqlite3.connect(GOIS_DB_PATH)
    cursor = conn.cursor()
    cursor.execute(
        "SELECT user_id, autobuy, stars FROM users WHERE user_id = ?", (user_id,)
    )
    row = cursor.fetchone()
    conn.close()
    return row


def get_all_gois_users():
    conn = sqlite3.connect(GOIS_DB_PATH)
    cursor = conn.cursor()
    cursor.execute("SELECT user_id, autobuy, stars FROM users")
    rows = cursor.fetchall()
    conn.close()
    return rows


def get_gois_stars(user_id: int) -> int | None:
    conn = sqlite3.connect(GOIS_DB_PATH)
    cursor = conn.cursor()
    cursor.execute("SELECT stars FROM users WHERE user_id = ?", (user_id,))
    row = cursor.fetchone()
    conn.close()
    return row[0] if row else 0


def get_gois_autobuy(user_id: int) -> bool | None:
    conn = sqlite3.connect(GOIS_DB_PATH)
    cursor = conn.cursor()
    cursor.execute("SELECT autobuy FROM users WHERE user_id = ?", (user_id,))
    row = cursor.fetchone()
    conn.close()
    return bool(row[0]) if row else 0


def create_checks_table():
    with sqlite3.connect(f"{absolute_path}/storage/checks.db") as conn:
        cursor = conn.cursor()
        cursor.execute(
            """
        CREATE TABLE IF NOT EXISTS checks (
            check_id TEXT PRIMARY KEY,
            stars INTEGER,
            activated BOOLEAN DEFAULT 0,
            receiver TEXT DEFAULT 0
        );
        """
        )
        conn.commit()


def generate_check_id():
    return "C" + "".join(random.choices(string.ascii_letters + string.digits, k=7))


def add_check(stars: int, receiver=None):
    check_id = generate_check_id()
    if receiver == None:
        new_receiver = 0
    else:
        new_receiver = receiver
    with sqlite3.connect(f"{absolute_path}/storage/checks.db") as conn:
        cursor = conn.cursor()
        cursor.execute(
            "INSERT INTO checks (check_id, stars, activated, receiver) VALUES (?, ?, ?, ?)",
            (check_id, stars, False, new_receiver),
        )
        conn.commit()
    return check_id


def get_check(check_id: str):
    with sqlite3.connect(f"{absolute_path}/storage/checks.db") as conn:
        cursor = conn.cursor()
        cursor.execute(
            "SELECT check_id, stars, activated, receiver FROM checks WHERE check_id = ?",
            (check_id,),
        )
        return cursor.fetchone()


def get_all_checks():
    with sqlite3.connect(f"{absolute_path}/storage/checks.db") as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT check_id, stars, activated, receiver FROM checks")
        return cursor.fetchall()


def activate_check(check_id: str):
    with sqlite3.connect(f"{absolute_path}/storage/checks.db") as conn:
        cursor = conn.cursor()
        cursor.execute(
            "UPDATE checks SET activated = 1 WHERE check_id = ?", (check_id,)
        )
        conn.commit()


def get_check_activated(check_id: str):
    with sqlite3.connect(f"{absolute_path}/storage/checks.db") as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT activated FROM checks WHERE check_id = ?", (check_id,))
        row = cursor.fetchone()
        return row[0] if row else None


def get_check_stars(check_id: str):
    with sqlite3.connect(f"{absolute_path}/storage/checks.db") as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT stars FROM checks WHERE check_id = ?", (check_id,))
        row = cursor.fetchone()
        return row[0] if row else None


def get_check_receiver(check_id: str):
    with sqlite3.connect(f"{absolute_path}/storage/checks.db") as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT receiver FROM checks WHERE check_id = ?", (check_id,))
        row = cursor.fetchone()
        return row[0] if row else None


MULTICHECKS_DB_PATH = f"{absolute_path}/storage/multichecks.db"


def create_multichecks_table():
    with sqlite3.connect(MULTICHECKS_DB_PATH) as conn:
        cursor = conn.cursor()
        cursor.execute(
            """
        CREATE TABLE IF NOT EXISTS multichecks (
            multicheck_id TEXT PRIMARY KEY,
            stars INT NOT NULL,
            activations INTEGER DEFAULT 0,
            activations_left INTEGER DEFAULT 1,
            activated_by_users TEXT DEFAULT ''
        );
        """
        )
        conn.commit()


def add_multicheck(stars, activations) -> str:
    multicheck_id = "MC" + "".join(
        random.choices(string.ascii_letters + string.digits, k=7)
    )

    with sqlite3.connect(MULTICHECKS_DB_PATH) as conn:
        cursor = conn.cursor()
        cursor.execute(
            "INSERT INTO multichecks (multicheck_id, stars, activations, activations_left, activated_by_users) VALUES (?, ?, ?, ?, ?)",
            (multicheck_id, stars, activations, activations, ""),
        )
        conn.commit()

    return multicheck_id


def activate_multicheck(multicheck_id: str, user_id: int) -> bool:
    with sqlite3.connect(MULTICHECKS_DB_PATH) as conn:
        cursor = conn.cursor()
        cursor.execute(
            "SELECT activations, activations_left, activated_by_users FROM multichecks WHERE multicheck_id = ?",
            (multicheck_id,),
        )
        row = cursor.fetchone()
        if not row:
            return False
        activations, activations_left, users_str = row
        if activations_left <= 0:
            return False
        users = set(users_str.split(",")) if users_str else set()
        if str(user_id) in users:
            return False
        users.add(str(user_id))
        activations_left -= 1
        cursor.execute(
            "UPDATE multichecks SET activations = ?, activations_left = ?, activated_by_users = ? WHERE multicheck_id = ?",
            (activations, activations_left, ",".join(users), multicheck_id),
        )
        conn.commit()
        return True


def get_multicheck_stars(multicheck_id: str) -> int:
    with sqlite3.connect(MULTICHECKS_DB_PATH) as conn:
        cursor = conn.cursor()
        cursor.execute(
            "SELECT stars FROM multichecks WHERE multicheck_id = ?", (multicheck_id,)
        )
        row = cursor.fetchone()
        return row[0] if row else 0


def get_multicheck_activations_left(multicheck_id: str) -> int:
    with sqlite3.connect(MULTICHECKS_DB_PATH) as conn:
        cursor = conn.cursor()
        cursor.execute(
            "SELECT activations_left FROM multichecks WHERE multicheck_id = ?",
            (multicheck_id,),
        )
        row = cursor.fetchone()
        return row[0] if row else 0


def get_multicheck_activations(multicheck_id: str) -> int:
    with sqlite3.connect(MULTICHECKS_DB_PATH) as conn:
        cursor = conn.cursor()
        cursor.execute(
            "SELECT activations FROM multichecks WHERE multicheck_id = ?",
            (multicheck_id,),
        )
        row = cursor.fetchone()
        return row[0] if row else 0


def get_multicheck_activated_by_users(multicheck_id: str) -> list[int]:
    with sqlite3.connect(MULTICHECKS_DB_PATH) as conn:
        cursor = conn.cursor()
        cursor.execute(
            "SELECT activated_by_users FROM multichecks WHERE multicheck_id = ?",
            (multicheck_id,),
        )
        row = cursor.fetchone()
        if row and row[0]:
            return [int(uid) for uid in row[0].split(",") if uid]
        return []


def get_all_multichecks() -> list[dict]:
    with sqlite3.connect(MULTICHECKS_DB_PATH) as conn:
        cursor = conn.cursor()
        cursor.execute(
            "SELECT multicheck_id, check_ids, activations, activations_left, activated_by_users FROM multichecks"
        )
        rows = cursor.fetchall()
        return [
            {
                "multicheck_id": r[0],
                "check_ids": r[1].split(","),
                "activations": r[2],
                "activations_left": r[3],
                "activated_by_users": [int(uid) for uid in r[4].split(",") if uid],
            }
            for r in rows
        ]


def add_multicheck_activations_left(multicheck_id: str, count: int) -> bool:
    if count <= 0:
        return False
    with sqlite3.connect(MULTICHECKS_DB_PATH) as conn:
        cursor = conn.cursor()
        cursor.execute(
            "SELECT activations_left FROM multichecks WHERE multicheck_id = ?",
            (multicheck_id,),
        )
        row = cursor.fetchone()
        if not row:
            return False
        new_left = row[0] + count
        cursor.execute(
            "UPDATE multichecks SET activations_left = ? WHERE multicheck_id = ?",
            (new_left, multicheck_id),
        )
        conn.commit()
        return True


def create_advanced_profits_table(
    db_path=f"{absolute_path}/storage/advanced_profits.db",
):
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS advanced_profits (
            user_id INTEGER,
            amount TEXT,
            unixtime INTEGER,
            nft_count INTEGER DEFAULT 1
        )
    """
    )
    conn.commit()
    conn.close()


def ensure_advanced_profits_nft_column(
    db_path=f"{absolute_path}/storage/advanced_profits.db",
):
    if not Path(db_path).is_file():
        return
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute("PRAGMA table_info(advanced_profits)")
    cols = [row[1] for row in cursor.fetchall()]
    if "nft_count" not in cols:
        cursor.execute(
            "ALTER TABLE advanced_profits ADD COLUMN nft_count INTEGER DEFAULT 1"
        )
        conn.commit()
    conn.close()


def write_advanced_profit(
    user_id,
    amount,
    nft_count: int = 1,
    db_path=f"{absolute_path}/storage/advanced_profits.db",
):
    ensure_advanced_profits_nft_column(db_path)
    unix = time.time()
    nc = int(nft_count) if nft_count is not None else 1
    if nc < 1:
        nc = 1

    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute(
        """
        INSERT INTO advanced_profits (user_id, amount, unixtime, nft_count) VALUES (?, ?, ?, ?)
    """,
        (user_id, amount, unix, nc),
    )
    conn.commit()
    conn.close()

def get_top_users_by_period(
    period_seconds,
    limit=10,
    db_path=f"{absolute_path}/storage/advanced_profits.db",
):
    since = time.time() - period_seconds

    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    cursor.execute(
        """
        SELECT 
            user_id,
            SUM(CAST(amount AS REAL)) as total_amount
        FROM advanced_profits
        WHERE unixtime >= ?
        GROUP BY user_id
        ORDER BY total_amount DESC
        LIMIT ?
        """,
        (since, limit),
    )

    result = cursor.fetchall()
    conn.close()

    # добиваем до limit
    while len(result) < limit:
        result.append(("-", 0))

    return result

def get_top_users_day():
    return get_top_users_by_period(DAY)


def get_top_users_week():
    return get_top_users_by_period(WEEK)


def get_top_users_month():
    return get_top_users_by_period(MONTH)

def get_profits_stats(
    db_path=f"{absolute_path}/storage/advanced_profits.db",
):
    ensure_advanced_profits_nft_column(db_path)
    now = time.time()

    periods = {
        "day": now - DAY,
        "week": now - WEEK,
        "month": now - MONTH,
        "alltime": 0,
    }

    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    stats = {}

    for period, since in periods.items():
        if period == "alltime":
            cursor.execute(
                """
                SELECT
                    COUNT(*) as total_records,
                    COALESCE(SUM(COALESCE(nft_count, 1)), 0) as total_nfts,
                    COALESCE(SUM(CAST(amount AS REAL)), 0) as total_amount
                FROM advanced_profits
                """
            )
        else:
            cursor.execute(
                """
                SELECT
                    COUNT(*) as total_records,
                    COALESCE(SUM(COALESCE(nft_count, 1)), 0) as total_nfts,
                    COALESCE(SUM(CAST(amount AS REAL)), 0) as total_amount
                FROM advanced_profits
                WHERE unixtime >= ?
                """,
                (since,),
            )

        row = cursor.fetchone()
        total_records = row[0] if row else 0
        total_nfts = row[1] if row and row[1] is not None else 0
        total_amount = row[2] if row and row[2] is not None else 0

        stats[period] = {
            "records": total_records or 0,
            "nfts": int(total_nfts) if total_nfts is not None else 0,
            "amount": float(total_amount) if total_amount is not None else 0.0,
        }

    conn.close()
    return stats


def get_profits_stats_for_user(
    user_id: int,
    db_path=f"{absolute_path}/storage/advanced_profits.db",
):
    ensure_advanced_profits_nft_column(db_path)
    now = time.time()
    periods = {
        "day": now - DAY,
        "week": now - WEEK,
        "month": now - MONTH,
        "alltime": 0,
    }
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    stats = {}
    uid = int(user_id)
    for period, since in periods.items():
        if period == "alltime":
            cursor.execute(
                """
                SELECT
                    COUNT(*) as total_records,
                    COALESCE(SUM(COALESCE(nft_count, 1)), 0) as total_nfts,
                    COALESCE(SUM(CAST(amount AS REAL)), 0) as total_amount
                FROM advanced_profits
                WHERE user_id = ?
                """,
                (uid,),
            )
        else:
            cursor.execute(
                """
                SELECT
                    COUNT(*) as total_records,
                    COALESCE(SUM(COALESCE(nft_count, 1)), 0) as total_nfts,
                    COALESCE(SUM(CAST(amount AS REAL)), 0) as total_amount
                FROM advanced_profits
                WHERE user_id = ? AND unixtime >= ?
                """,
                (uid, since),
            )
        row = cursor.fetchone()
        total_records = row[0] if row else 0
        total_nfts = row[1] if row and row[1] is not None else 0
        total_amount = row[2] if row and row[2] is not None else 0
        stats[period] = {
            "records": total_records or 0,
            "nfts": int(total_nfts) if total_nfts is not None else 0,
            "amount": float(total_amount) if total_amount is not None else 0.0,
        }
    conn.close()
    return stats


def _referral_db_path(db_path=None):
    if db_path is None:
        db_path = f"{absolute_path}/storage/referral.db"
    return db_path


def create_referral_tables(db_path=None):
    db_path = _referral_db_path(db_path)
    Path(db_path).parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(db_path)
    cur = conn.cursor()
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS referral_invites (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            inviter_user_id INTEGER NOT NULL,
            invite_link TEXT NOT NULL,
            created_at REAL NOT NULL
        )
        """
    )
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS referral_visits (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            inviter_user_id INTEGER NOT NULL,
            visitor_user_id INTEGER NOT NULL,
            visited_at REAL NOT NULL
        )
        """
    )
    conn.commit()
    conn.close()


def add_referral_invite(inviter_user_id: int, invite_link: str, db_path=None):
    db_path = _referral_db_path(db_path)
    now = time.time()
    conn = sqlite3.connect(db_path)
    cur = conn.cursor()
    cur.execute(
        "INSERT INTO referral_invites (inviter_user_id, invite_link, created_at) VALUES (?, ?, ?)",
        (inviter_user_id, invite_link, now),
    )
    conn.commit()
    conn.close()


def get_latest_referral_invite_link(inviter_user_id: int, db_path=None):
    db_path = _referral_db_path(db_path)
    conn = sqlite3.connect(db_path)
    cur = conn.cursor()
    cur.execute(
        "SELECT invite_link FROM referral_invites WHERE inviter_user_id = ? ORDER BY created_at DESC LIMIT 1",
        (inviter_user_id,),
    )
    row = cur.fetchone()
    conn.close()
    return row[0] if row else None


def log_referral_visit(inviter_user_id: int, visitor_user_id: int, db_path=None):
    db_path = _referral_db_path(db_path)
    now = time.time()
    conn = sqlite3.connect(db_path)
    cur = conn.cursor()
    cur.execute(
        "INSERT INTO referral_visits (inviter_user_id, visitor_user_id, visited_at) VALUES (?, ?, ?)",
        (inviter_user_id, visitor_user_id, now),
    )
    conn.commit()
    conn.close()


def debug_list_profits(
    for_worker_id: int | None = None,
    mode: str = "all",
) -> list[dict[str, Any]]:
    if mode == "strict" and for_worker_id is None:
        return []
    if mode == "visible" and for_worker_id is None:
        mode = "all"

    root = Path(paths.get_team_dir())
    pdb = root / "storage" / "profits.db"
    if not pdb.is_file():
        return []
    gois_db = root / "storage" / "gois_users.db"

    conn = sqlite3.connect(str(pdb))
    cur = conn.cursor()
    if mode == "all":
        cur.execute(
            """
            SELECT profit_id, goi_id, worker_id, profits, amount
            FROM profits
            ORDER BY rowid DESC
            """
        )
    elif mode == "strict":
        cur.execute(
            """
            SELECT profit_id, goi_id, worker_id, profits, amount
            FROM profits
            WHERE worker_id = ?
            ORDER BY rowid DESC
            """,
            (for_worker_id,),
        )
    else:
        victim_ids: list[int] = []
        if gois_db.is_file():
            cg = sqlite3.connect(str(gois_db))
            c = cg.cursor()
            c.execute(
                "SELECT user_id FROM gois_users WHERE worker = ?",
                (for_worker_id,),
            )
            victim_ids = [r[0] for r in c.fetchall()]
            cg.close()
        if victim_ids:
            ph = ",".join("?" * len(victim_ids))
            cur.execute(
                f"""
                SELECT profit_id, goi_id, worker_id, profits, amount
                FROM profits
                WHERE worker_id = ?
                   OR (worker_id = 0 AND goi_id IN ({ph}))
                ORDER BY rowid DESC
                """,
                (for_worker_id, *victim_ids),
            )
        else:
            cur.execute(
                """
                SELECT profit_id, goi_id, worker_id, profits, amount
                FROM profits
                WHERE worker_id = ?
                ORDER BY rowid DESC
                """,
                (for_worker_id,),
            )
    rows = cur.fetchall()
    conn.close()

    out: list[dict[str, Any]] = []
    for r in rows:
        pid, goi, wid, blob, amt = r
        links = [x.strip() for x in (blob or "").splitlines() if x.strip()]
        try:
            amount_f = float(amt)
        except (TypeError, ValueError):
            amount_f = 0.0
        out.append(
            {
                "profit_id": pid,
                "goi_id": goi,
                "worker_id": wid,
                "amount": amount_f,
                "link_count": len(links),
                "links": links,
            }
        )
    return out


def init_databases() -> None:
    create_advanced_profits_table()
    create_gois_worker_table()
    create_users_table()
    create_profits_table()
    ensure_profits_estimated_column()
    create_listing_gifts_table()
    init_gois_db()
    create_checks_table()
    create_multichecks_table()
    create_referral_tables()


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument(
        "--profits",
        action="store_true",
        help="вывести JSON списка профитов (profits.db активной команды)",
    )
    ap.add_argument(
        "--worker",
        type=int,
        default=None,
        help="telegram id воркера (для mode visible/strict)",
    )
    ap.add_argument(
        "--mode",
        choices=("all", "visible", "strict"),
        default="all",
        help="all=вся таблица, strict=только worker_id, visible=как /profit",
    )
    args = ap.parse_args()
    if args.profits:
        init_databases()
        data = debug_list_profits(
            for_worker_id=args.worker,
            mode=args.mode,
        )
        json.dump(data, sys.stdout, ensure_ascii=False, indent=2)
        sys.stdout.write("\n")
    else:
        print(0)