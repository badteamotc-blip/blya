from PIL import Image, ImageDraw, ImageFont
from datetime import datetime
from zoneinfo import ZoneInfo

import random
from base import CODE_ROOT, absolute_path

import os

BG_PATH = f"{CODE_ROOT}/static/background.png"

COLOR_WHITE = (245, 245, 247)
COLOR_BLUE = (78, 119, 174)
COLOR_GRAY = (176, 176, 176)
COLOR_DARK = (28, 28, 28)
COLOR_BLACK = (0, 0, 0)


def generate_image(BOT_NAME, STARS_AMOUNT, absolute_path):
    try:
        AVATAR_PATH = f"{absolute_path}/avatar.png"
        font_time = ImageFont.truetype(f"{CODE_ROOT}/static/Inter-Semibold.ttf", 26)
        font_stars = ImageFont.truetype(
            f"{CODE_ROOT}/static/Inter-Semibold.ttf", 27
        )
        font_bot = ImageFont.truetype(f"{CODE_ROOT}/static/Inter-Regular.ttf", 24)
        font_tx = ImageFont.truetype(f"{CODE_ROOT}/static/Inter-Regular.ttf", 24)

        OUTPUT_PATH = f"{absolute_path}/rFile{random.randint(100000000000, 1000000000000)}.png"
        BOT_NAME = BOT_NAME.replace(" ", "\u2009")
        if len(BOT_NAME) > 19:
            BOT_NAME = BOT_NAME[:19] + "..."
        DEVICE_TIME = datetime.now(ZoneInfo("Europe/Moscow"))

        img = Image.open(BG_PATH).convert("RGBA")
        draw = ImageDraw.Draw(img)

        device_time_str = DEVICE_TIME.strftime("%H:%M")

        time_x, time_y = 55, 20

        bbox = draw.textbbox((0, 0), device_time_str, font=font_time)
        text_w = bbox[2]
        text_h = bbox[3]

        PADDING_X = 10
        PADDING_Y = 6

        draw.rectangle(
            (
                time_x - PADDING_X,
                time_y - PADDING_Y,
                time_x + text_w + PADDING_X,
                time_y + text_h + PADDING_Y,
            ),
            fill=COLOR_BLACK,
        )

        draw.text((time_x, time_y), device_time_str, fill=COLOR_WHITE, font=font_time)

        bot_x, bot_y = 269, 855

        bbox = draw.textbbox((bot_x, bot_y), BOT_NAME, font=font_bot)
        text_w = bbox[2] - bbox[0]
        text_h = bbox[3] - bbox[1]

        PADDING_X = 12
        PADDING_Y = 6

        draw.rectangle(
            (
                bot_x - PADDING_X,
                bot_y - PADDING_Y,
                bot_x + text_w + PADDING_X,
                bot_y + text_h + PADDING_Y,
            ),
            fill=COLOR_DARK,
        )

        draw.text((bot_x, bot_y), BOT_NAME, fill=COLOR_BLUE, font=font_bot, spacing=2)

        tx_time_str = DEVICE_TIME.strftime("%d.%m.%y в %H:%M")

        tx_x, tx_y = 220, 975

        TX_BG_COLOR = COLOR_DARK
        TX_TEXT_COLOR = COLOR_WHITE

        bbox = draw.textbbox((0, 0), tx_time_str, font=font_tx)
        text_w = bbox[2]
        text_h = bbox[3]

        PADDING_X = 10
        PADDING_Y = 6

        draw.rectangle(
            (
                tx_x - PADDING_X,
                tx_y - PADDING_Y,
                tx_x + text_w + PADDING_X,
                tx_y + text_h + PADDING_Y,
            ),
            fill=TX_BG_COLOR,
        )

        draw.text((tx_x, tx_y), tx_time_str, fill=TX_TEXT_COLOR, font=font_tx)

        STARS_COUNT = f"+ {STARS_AMOUNT}"

        text = str(STARS_AMOUNT)

        bbox = draw.textbbox((0, 0), text, font=font_stars)
        text_width = bbox[2] - bbox[0]

        stars_x = 280 - text_width
        stars_y = 657

        draw.text((stars_x, stars_y), text, font=font_stars, fill=(255, 255, 255))

        STARS_BG_COLOR = COLOR_DARK
        STARS_TEXT_COLOR = (25, 137, 19)

        bbox = draw.textbbox((0, 0), STARS_COUNT, font=font_tx)
        text_w = bbox[2]
        text_h = bbox[3]

        PADDING_X = 10
        PADDING_Y = 6

        draw.rectangle(
            (
                stars_x - PADDING_X,
                stars_y - PADDING_Y,
                stars_x + text_w + PADDING_X,
                stars_y + text_h + PADDING_Y,
            ),
            fill=STARS_BG_COLOR,
        )

        draw.text(
            (stars_x, stars_y), STARS_COUNT, fill=STARS_TEXT_COLOR, font=font_stars
        )

        avatar = Image.open(AVATAR_PATH).convert("RGBA").resize((40, 40))

        mask = Image.new("L", avatar.size, 0)
        mask_draw = ImageDraw.Draw(mask)
        mask_draw.ellipse((0, 0, 40, 40), fill=255)

        img.paste(avatar, (220, 850), mask)

        img.save(OUTPUT_PATH)

        return OUTPUT_PATH
    except Exception as e:
        return f"{CODE_ROOT}/static/background.png"
