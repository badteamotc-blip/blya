from __future__ import annotations

import json
import os
import re
from pathlib import Path


def _extract_rhs_string(line: str) -> str:
    m = re.search(r"=\s*(.*)$", line)
    if not m:
        return ""
    rest = m.group(1).strip()
    if not rest:
        return ""
    if len(rest) >= 2 and rest[0] == rest[-1] and rest[0] in "\"'":
        return rest[1:-1]
    return rest.split("#", 1)[0].strip().strip(",").strip("\"'")


def ensure_team_config_migrated(config_path: str | os.PathLike[str]) -> None:
    p = Path(config_path)
    if not p.is_file():
        return
    try:
        text = p.read_text(encoding="utf-8")
    except OSError:
        return
    if "RECEIVER_ID" not in text:
        return
    lines = text.splitlines()
    receiver_val = ""
    for ln in lines:
        if re.match(r"^\s*RECEIVER_ID\s*=", ln):
            receiver_val = _extract_rhs_string(ln)
            break
    out: list[str] = []
    has_admin_wallet = False
    for ln in lines:
        if re.match(r"^\s*RECEIVER_ID\s*=", ln):
            continue
        if re.match(r"^\s*ADMIN_WALLET\s*=", ln):
            has_admin_wallet = True
        out.append(ln)
    if not has_admin_wallet:
        ins = receiver_val.strip()
        if ins.startswith("UQ") and len(ins) >= 40:
            aw = ins
        else:
            aw = ""
        insert_line = f"ADMIN_WALLET = {json.dumps(aw, ensure_ascii=False)}"
        insert_at = 0
        for j, ln in enumerate(out):
            if re.match(r"^\s*ADMIN_ID\s*=", ln):
                insert_at = j + 1
                break
        out.insert(insert_at, insert_line)
    rv = receiver_val.strip()
    if rv and not rv.startswith("UQ") and len(rv) >= 2 and not rv.startswith("http"):
        for j, ln in enumerate(out):
            if not re.match(r"^\s*CHAT_RECEIVER_USERNAME\s*=", ln):
                continue
            cur = _extract_rhs_string(ln)
            if (cur or "").strip():
                break
            out[j] = f"CHAT_RECEIVER_USERNAME = {json.dumps(rv.lstrip('@'), ensure_ascii=False)}"
            break
    new_text = "\n".join(out)
    if new_text == text:
        return
    try:
        suf = "\n" if not new_text.endswith("\n") else ""
        p.write_text(new_text + suf, encoding="utf-8")
    except OSError:
        return
