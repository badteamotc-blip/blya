import hashlib
import hmac
import os
import re
import time
from pathlib import Path
import paths
import uvicorn
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates

import config
import database

app = FastAPI(openapi_url=None, docs_url=None, redoc_url=None)

templates = Jinja2Templates(directory=os.path.join(paths.CODE_ROOT, "templates"))

_ID_PAGE = re.compile(r"^id(\d+)$")


def _team_slug() -> str:
    return Path(paths.TEAM_DIR).name


def _public_base() -> str:
    return str(getattr(config, "REFERRAL_PUBLIC_BASE", "") or "").rstrip("/")


def _verify_widget(params: dict, bot_token: str) -> tuple[bool, int]:
    check_hash = params.get("hash")
    if not check_hash:
        return False, 0
    auth_date = params.get("auth_date")
    if auth_date is None:
        return False, 0
    try:
        ad = int(auth_date)
    except (TypeError, ValueError):
        return False, 0
    if abs(time.time() - ad) > 86400:
        return False, 0
    pairs = []
    for k, v in sorted(params.items()):
        if k == "hash" or v is None:
            continue
        pairs.append(f"{k}={v}")
    data_check_string = "\n".join(pairs)
    secret_key = hashlib.sha256(bot_token.encode()).digest()
    sig = hmac.new(
        secret_key,
        msg=data_check_string.encode(),
        digestmod=hashlib.sha256,
    ).hexdigest()
    if sig != check_hash:
        return False, 0
    try:
        uid = int(params["id"])
    except (KeyError, TypeError, ValueError):
        return False, 0
    return True, uid


_REFERRAL_FON = Path(paths.CODE_ROOT) / "static" / "fon.png"


@app.get("/fon.png", include_in_schema=False)
async def fon_png():
    if not _REFERRAL_FON.is_file():
        raise HTTPException(status_code=404)
    return FileResponse(_REFERRAL_FON, media_type="image/png")


@app.get("/tg-auth", response_class=HTMLResponse)
async def tg_auth(request: Request):
    inviter_raw = request.cookies.get("ref_inviter")
    try:
        inviter_id = int(inviter_raw) if inviter_raw else 0
    except ValueError:
        inviter_id = 0
    q = dict(request.query_params)
    ok, visitor_id = _verify_widget(q, config.BOT_TOKEN)
    slug = _team_slug()
    base = _public_base()
    back = f"/id{inviter_id}" if inviter_id else "/"
    if not ok or not inviter_id:
        ctx = {
            "request": request,
            "hero_url": "/fon.png",
            "invite_link": database.get_latest_referral_invite_link(inviter_id)
            if inviter_id
            else None,
            "subscribe_url": getattr(config, "REQUIRED_SUBSCRIBE_URL", "#"),
            "bot_username": getattr(config, "REF_BOT_USERNAME", "") or "",
            "auth_url": f"{base}/{slug}/tg-auth",
            "ok": False,
            "auth_fail": True,
        }
        return templates.TemplateResponse("referral_landing.html", ctx, status_code=400)
    database.log_referral_visit(inviter_id, visitor_id)
    redir = f"{back}?ok=1"
    resp = RedirectResponse(url=redir, status_code=303)
    resp.delete_cookie("ref_inviter", path="/")
    return resp


@app.get("/{page}", response_class=HTMLResponse)
async def referral_page(page: str, request: Request):
    m = _ID_PAGE.match(page)
    if not m:
        raise HTTPException(status_code=404)
    inviter_id = int(m.group(1))
    invite_link = database.get_latest_referral_invite_link(inviter_id)
    slug = _team_slug()
    base = _public_base()
    auth_url = f"{base}/{slug}/tg-auth"
    bot_username = (getattr(config, "REF_BOT_USERNAME", "") or "").strip()
    ctx = {
        "request": request,
        "hero_url": "/fon.png",
        "invite_link": invite_link,
        "subscribe_url": getattr(config, "REQUIRED_SUBSCRIBE_URL", "#"),
        "bot_username": bot_username,
        "auth_url": auth_url,
        "ok": request.query_params.get("ok") == "1",
        "auth_fail": False,
    }
    resp = templates.TemplateResponse("referral_landing.html", ctx)
    resp.set_cookie(
        "ref_inviter",
        str(inviter_id),
        max_age=3600,
        path="/",
        httponly=True,
        samesite="lax",
        secure=request.url.scheme == "https",
    )
    return resp


if __name__ == "__main__":
    _host = os.environ.get("WEB_HOST", "127.0.0.1")
    _port = int(os.environ.get("REFERRAL_WEB_PORT", "9199"))
    uvicorn.run("web_referral:app", host=_host, port=_port, reload=False)
