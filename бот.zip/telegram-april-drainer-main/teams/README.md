# Team config

Скопируй `config.example.py` → `config.py` и заполни значения.

`storage/2fa.json` создаётся в рантайме и не должен попадать в git.
