#!/usr/bin/env bash
set -euo pipefail
OPT_ROOT="${1:?usage: sudo ./install-ubuntu22.sh /path/to/opt [ --now ]}"
NOW=0
shift || true
if [ "${1:-}" = "--now" ]; then
  NOW=1
fi
OPT_ROOT="$(cd "$OPT_ROOT" && pwd)"
DEPLOY="$(cd "$(dirname "$0")" && pwd)"
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq
apt-get install -y -qq python3 python3-venv python3-pip ca-certificates curl gnupg \
  build-essential libjpeg-turbo8-dev zlib1g-dev >/dev/null
if ! command -v node >/dev/null 2>&1 || [ "$(node -p "parseInt(process.versions.node,10)")" -lt 20 ]; then
  curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
  apt-get remove -y libnode-dev >/dev/null 2>&1 || true
  apt-get install -y -qq nodejs >/dev/null
fi

PY="${PYTHON_BIN:-python3}"
"$PY" -m venv "$OPT_ROOT/code/.venv"
"$OPT_ROOT/code/.venv/bin/pip" install -q -U pip
"$OPT_ROOT/code/.venv/bin/pip" install -q -r "$OPT_ROOT/code/requirements.txt"

"$PY" -m venv "$OPT_ROOT/autocraft/.venv"
"$OPT_ROOT/autocraft/.venv/bin/pip" install -q -U pip
"$OPT_ROOT/autocraft/.venv/bin/pip" install -q -r "$OPT_ROOT/autocraft/backend/requirements.txt"

"$PY" -m venv "$OPT_ROOT/autocraft/.venv-bot"
"$OPT_ROOT/autocraft/.venv-bot/bin/pip" install -q -U pip
"$OPT_ROOT/autocraft/.venv-bot/bin/pip" install -q -r "$OPT_ROOT/autocraft/bot/requirements.txt"

"$PY" -m venv "$OPT_ROOT/server-monitor/.venv"
"$OPT_ROOT/server-monitor/.venv/bin/pip" install -q -U pip
"$OPT_ROOT/server-monitor/.venv/bin/pip" install -q -r "$OPT_ROOT/server-monitor/requirements.txt"

(cd "$OPT_ROOT/d0sh1k/bundle" && npm ci --omit=dev)

bash "$DEPLOY/install-render-exec.sh" "$OPT_ROOT"
cp -f "$DEPLOY/systemd/"*.service /etc/systemd/system/
systemctl daemon-reload
if [ "$NOW" = 1 ]; then
  systemctl enable --now opt-code-stack.service opt-autocraft-api.service \
    opt-autocraft-bot.service opt-d0sh1k.service opt-server-monitor.service
else
  systemctl enable opt-code-stack.service opt-autocraft-api.service \
    opt-autocraft-bot.service opt-d0sh1k.service opt-server-monitor.service
fi
