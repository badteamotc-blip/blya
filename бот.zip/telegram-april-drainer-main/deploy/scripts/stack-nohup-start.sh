#!/usr/bin/env bash
set -euo pipefail
OPT_ROOT="${1:?usage: stack-nohup-start.sh OPT_ROOT}"
if [ ! -x /etc/opt-stack/exec-code-stack.sh ]; then
  echo "Сначала: sudo $OPT_ROOT/deploy/install-render-exec.sh $OPT_ROOT" >&2
  exit 1
fi
LOG_DIR="${NOHUP_LOG_DIR:-/var/log/opt-stack-nohup}"
PID_DIR="${NOHUP_PID_DIR:-$OPT_ROOT/var/nohup-pids}"
mkdir -p "$LOG_DIR" "$PID_DIR"
start_one() {
  local name="$1"
  if [ -f "$PID_DIR/${name}.pid" ]; then
    local old
    old="$(cat "$PID_DIR/${name}.pid")"
    if kill -0 "$old" 2>/dev/null; then
      echo "уже запущен: $name pid=$old" >&2
      return 0
    fi
  fi
  nohup "/etc/opt-stack/exec-${name}.sh" >>"$LOG_DIR/${name}.log" 2>&1 &
  echo $! >"$PID_DIR/${name}.pid"
  echo "started $name pid=$(cat "$PID_DIR/${name}.pid")"
}
start_one code-stack
start_one autocraft-api
sleep 2
start_one autocraft-bot
start_one d0sh1k
start_one server-monitor
