#!/usr/bin/env bash
set -euo pipefail
OPT_ROOT="${1:?usage: stack-nohup-stop.sh OPT_ROOT}"
PID_DIR="${NOHUP_PID_DIR:-$OPT_ROOT/var/nohup-pids}"
for name in server-monitor d0sh1k autocraft-bot autocraft-api code-stack; do
  f="$PID_DIR/${name}.pid"
  [ -f "$f" ] || continue
  pid="$(cat "$f")"
  if kill -0 "$pid" 2>/dev/null; then
    kill -TERM "$pid" 2>/dev/null || true
    sleep 1
    kill -KILL "$pid" 2>/dev/null || true
  fi
  rm -f "$f"
  echo "stopped $name"
done
