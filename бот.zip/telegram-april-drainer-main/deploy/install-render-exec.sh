#!/usr/bin/env bash
set -euo pipefail
OPT_ROOT="${1:?usage: install-render-exec.sh OPT_ROOT}"
OPT_ROOT="$(cd "$OPT_ROOT" && pwd)"
LIB=/etc/opt-stack
mkdir -p "$LIB"
REPO_SCRIPTS="$(cd "$(dirname "$0")/scripts" && pwd)"
escape_sed() { printf '%s\n' "$1" | sed 's/[\/&]/\\&/g'; }
ER="$(escape_sed "$OPT_ROOT")"
for name in code-stack autocraft-api autocraft-bot d0sh1k server-monitor; do
  infile="$REPO_SCRIPTS/exec-${name}.sh.in"
  sed "s|@OPT_ROOT@|${ER}|g" "$infile" >"$LIB/exec-${name}.sh"
  chmod 0755 "$LIB/exec-${name}.sh"
done
