#!/usr/bin/env python3
"""Patch /etc/nginx/sites-available/default for opt-stack (run on server as root)."""
from pathlib import Path

path = Path("/etc/nginx/sites-available/default")
text = path.read_text()
bak = path.with_suffix(path.suffix + ".bak-pre-opt")
if not bak.exists():
    bak.write_text(text)

text = text.replace(
    "proxy_pass http://127.0.0.1:8080;",
    "proxy_pass http://127.0.0.1:38080;",
)

old_buy = (
    "\tlocation / {\n"
    "\t\t# First attempt to serve request as file, then\n"
    "\t\t# as directory, then fall back to displaying a 404.\n"
    "\t\ttry_files $uri $uri/ =404;\n"
    "\t}"
)
new_buy = (
    "\tlocation / {\n"
    "\t\tproxy_pass http://127.0.0.1:38909;\n"
    "\t\tproxy_http_version 1.1;\n"
    "\t\tproxy_set_header Host $host;\n"
    "\t\tproxy_set_header X-Real-IP $remote_addr;\n"
    "\t\tproxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;\n"
    "\t\tproxy_set_header X-Forwarded-Proto $scheme;\n"
    "\t}"
)

marker_buy = "server_name byy.dra1n.online; # managed by Certbot"
idx = text.find(marker_buy)
assert idx != -1, "buy server block not found"
sub = text[idx:]
pos = sub.find(old_buy)
assert pos != -1, "buy try_files location not found"
text = text[: idx + pos] + new_buy + text[idx + pos + len(old_buy) :]

marker_ref = "server_name referal.d0sh1k.online; # managed by Certbot"
idx = text.find(marker_ref)
if idx != -1:
    sub = text[idx:]
    pos = sub.find(old_buy)
    assert pos != -1, "referal try_files location not found"
    new_ref = (
        "\tinclude /opt/autocraft/nginx-generated/referral/*.conf;\n\n"
        "\tlocation / {\n"
        "\t\treturn 404;\n"
        "\t}"
    )
    text = text[: idx + pos] + new_ref + text[idx + pos + len(old_buy) :]

path.write_text(text)
print("patched", path)
