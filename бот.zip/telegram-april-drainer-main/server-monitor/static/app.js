const HISTORY_LEN = 36;

function formatUptime(sec) {
  const s = Math.floor(sec % 60);
  const m = Math.floor((sec / 60) % 60);
  const h = Math.floor((sec / 3600) % 24);
  const d = Math.floor(sec / 86400);
  const parts = [];
  if (d) parts.push(`${d}д`);
  if (h || d) parts.push(`${h}ч`);
  parts.push(`${m}м`);
  parts.push(`${s}с`);
  return parts.join(" ");
}

function formatBytes(n) {
  if (n >= 1e12) return `${(n / 1e12).toFixed(2)} TB`;
  if (n >= 1e9) return `${(n / 1e9).toFixed(2)} GB`;
  if (n >= 1e6) return `${(n / 1e6).toFixed(2)} MB`;
  if (n >= 1e3) return `${(n / 1e3).toFixed(2)} KB`;
  return `${n} B`;
}

function drawSpark(canvas, values, color) {
  if (!canvas) return;
  const ctx = canvas.getContext("2d");
  const w = canvas.width;
  const h = canvas.height;
  ctx.clearRect(0, 0, w, h);
  if (!values.length) return;
  const min = 0;
  const max = 100;
  ctx.strokeStyle = color;
  ctx.lineWidth = 2;
  ctx.lineJoin = "round";
  ctx.lineCap = "round";
  ctx.beginPath();
  values.forEach((v, i) => {
    const x = (i / Math.max(values.length - 1, 1)) * (w - 4) + 2;
    const t = (v - min) / (max - min || 1);
    const y = h - 4 - t * (h - 8);
    if (i === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  });
  ctx.stroke();
  ctx.strokeStyle = "rgba(139,147,168,0.25)";
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(2, h / 2);
  ctx.lineTo(w - 2, h / 2);
  ctx.stroke();
}

const cpuHist = [];
const memHist = [];

async function tick() {
  const elStatus = document.getElementById("poll-status");
  try {
    const res = await fetch("/api/metrics", { credentials: "same-origin" });
    if (res.status === 401) {
      window.location.href = "/login";
      return;
    }
    const json = await res.json();
    if (!json.success) throw new Error(json.error || "error");
    const d = json.data;

    document.getElementById("host-label").textContent = d.host.hostname || "";
    document.getElementById("cpu-pct").textContent = `${d.cpu.percent}%`;
    const la = d.cpu.load_avg;
    document.getElementById("cpu-meta").textContent = la
      ? `${d.cpu.count} потоков · load ${la.map((x) => x.toFixed(2)).join(" / ")}`
      : `${d.cpu.count} потоков`;

    document.getElementById("mem-pct").textContent = `${Math.round(d.memory.percent)}%`;
    document.getElementById("mem-bar").style.width = `${d.memory.percent}%`;
    document.getElementById("mem-meta").textContent = `исп. ${d.memory.used_gb} GB из ${d.memory.total_gb} GB · доступно ${d.memory.available_gb} GB`;

    document.getElementById("swap-pct").textContent = d.swap.total_gb
      ? `${Math.round(d.swap.percent)}%`
      : "—";
    document.getElementById("swap-bar").style.width = d.swap.total_gb
      ? `${d.swap.percent}%`
      : "0%";
    document.getElementById("swap-meta").textContent = d.swap.total_gb
      ? `swap ${d.swap.used_gb} / ${d.swap.total_gb} GB`
      : "swap не используется";

    document.getElementById("disk-pct").textContent = `${Math.round(d.disk_root.percent)}%`;
    document.getElementById("disk-bar").style.width = `${d.disk_root.percent}%`;
    document.getElementById("disk-meta").textContent = `исп. ${d.disk_root.used_gb} GB · своб. ${d.disk_root.free_gb} GB · всего ${d.disk_root.total_gb} GB`;

    document.getElementById("uptime").textContent = formatUptime(d.uptime_s);
    document.getElementById("uname-meta").textContent = `${d.host.system} ${d.host.release} · ${d.host.machine}`;

    const net = d.network;
    document.getElementById("net-meta").textContent = net
      ? `↓ ${formatBytes(net.bytes_recv)} · ↑ ${formatBytes(net.bytes_sent)} · пакеты ↓${net.packets_recv} ↑${net.packets_sent}`
      : "сеть недоступна";

    cpuHist.push(d.cpu.percent);
    if (cpuHist.length > HISTORY_LEN) cpuHist.shift();
    memHist.push(d.memory.percent);
    if (memHist.length > HISTORY_LEN) memHist.shift();
    drawSpark(document.getElementById("spark-cpu"), cpuHist, "#5b8cff");
    drawSpark(document.getElementById("spark-mem"), memHist, "#3dd6c6");

    const diskBody = document.querySelector("#tbl-disks tbody");
    diskBody.replaceChildren();
    (d.disks || []).forEach((row) => {
      const tr = document.createElement("tr");
      [
        row.mount,
        row.fstype || "—",
        `${row.used_gb} GB`,
        `${row.free_gb} GB`,
        `${row.total_gb} GB`,
        `${Math.round(row.percent)}%`,
      ].forEach((text) => {
        const td = document.createElement("td");
        td.textContent = text;
        tr.appendChild(td);
      });
      diskBody.appendChild(tr);
    });

    const procBody = document.querySelector("#tbl-proc tbody");
    procBody.replaceChildren();
    (d.processes || []).forEach((p) => {
      const tr = document.createElement("tr");
      [p.pid, p.username || "", p.name || "", p.cpu, p.mem_pct, p.rss_mb].forEach(
        (val) => {
          const td = document.createElement("td");
          td.textContent = val === undefined || val === null ? "" : String(val);
          tr.appendChild(td);
        }
      );
      const tdCmd = document.createElement("td");
      const cmd = p.cmdline || "";
      tdCmd.textContent = cmd;
      tdCmd.title = cmd;
      tr.appendChild(tdCmd);
      procBody.appendChild(tr);
    });

    elStatus.textContent = "онлайн";
    elStatus.classList.add("ok");
  } catch (e) {
    elStatus.textContent = "ошибка обновления";
    elStatus.classList.remove("ok");
  }
}

function init() {
  tick();
  setInterval(tick, 2500);
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", init);
} else {
  init();
}
