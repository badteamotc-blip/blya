import os
import platform
import socket
import time
from typing import Any

import psutil

_CMDLINE_MAX = 200
_TOP_N = 60
_SKIP_FSTYPES = frozenset({"", "squashfs", "tmpfs", "devtmpfs", "overlay"})


def _load_avg() -> list[float] | None:
    try:
        return list(os.getloadavg())
    except (OSError, AttributeError):
        return None


def _truncate_cmdline(parts: list[str] | None) -> str:
    if not parts:
        return ""
    s = " ".join(parts)
    if len(s) <= _CMDLINE_MAX:
        return s
    return s[: _CMDLINE_MAX - 1] + "…"


def _disk_partitions() -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    for p in psutil.disk_partitions(all=False):
        if p.fstype in _SKIP_FSTYPES and p.mountpoint not in ("/", "/boot", "/boot/efi"):
            continue
        try:
            u = psutil.disk_usage(p.mountpoint)
        except (PermissionError, OSError):
            continue
        out.append(
            {
                "mount": p.mountpoint,
                "fstype": p.fstype or "",
                "total_gb": round(u.total / (1024**3), 2),
                "used_gb": round(u.used / (1024**3), 2),
                "free_gb": round(u.free / (1024**3), 2),
                "percent": u.percent,
            }
        )
    out.sort(key=lambda x: x["mount"])
    return out


def collect_metrics() -> dict[str, Any]:
    now = time.time()
    cpu_pct = psutil.cpu_percent(interval=0.1)
    cpu_count = psutil.cpu_count(logical=True) or 1
    vm = psutil.virtual_memory()
    swap = psutil.swap_memory()
    disk = psutil.disk_usage("/")
    boot = psutil.boot_time()
    try:
        io = psutil.net_io_counters()
        net = {
            "bytes_sent": io.bytes_sent,
            "bytes_recv": io.bytes_recv,
            "packets_sent": io.packets_sent,
            "packets_recv": io.packets_recv,
        }
    except RuntimeError:
        net = None
    processes: list[dict[str, Any]] = []
    for proc in psutil.process_iter(
        ["pid", "name", "username", "memory_percent", "cpu_percent", "memory_info"]
    ):
        try:
            info = proc.info
            pid = info.get("pid")
            if pid is None:
                continue
            mi = info.get("memory_info")
            rss_bytes = mi.rss if mi else 0
            rss_mb = round(rss_bytes / (1024 * 1024), 2)
            uname = info.get("username")
            if callable(uname):
                uname = uname()
            processes.append(
                {
                    "pid": pid,
                    "name": info.get("name") or "",
                    "username": uname or "",
                    "cpu": round(info.get("cpu_percent") or 0.0, 1),
                    "mem_pct": round(info.get("memory_percent") or 0.0, 1),
                    "rss_mb": rss_mb,
                    "cmdline": _truncate_cmdline(proc.cmdline()),
                }
            )
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            continue
    processes.sort(key=lambda x: x["rss_mb"], reverse=True)
    processes = processes[:_TOP_N]
    un = platform.uname()
    return {
        "ts": now,
        "host": {
            "hostname": socket.gethostname(),
            "system": un.system,
            "node": un.node,
            "release": un.release,
            "machine": un.machine,
        },
        "cpu": {
            "percent": round(cpu_pct, 1),
            "count": cpu_count,
            "load_avg": _load_avg(),
        },
        "memory": {
            "total_gb": round(vm.total / (1024**3), 2),
            "available_gb": round(vm.available / (1024**3), 2),
            "used_gb": round(vm.used / (1024**3), 2),
            "percent": vm.percent,
        },
        "swap": {
            "total_gb": round(swap.total / (1024**3), 2) if swap.total else 0.0,
            "used_gb": round(swap.used / (1024**3), 2) if swap.total else 0.0,
            "percent": swap.percent,
        },
        "disk_root": {
            "total_gb": round(disk.total / (1024**3), 2),
            "used_gb": round(disk.used / (1024**3), 2),
            "free_gb": round(disk.free / (1024**3), 2),
            "percent": disk.percent,
        },
        "disks": _disk_partitions(),
        "boot_time": boot,
        "uptime_s": int(now - boot),
        "network": net,
        "processes": processes,
    }
