import os
import sys
from pathlib import Path

from fastapi import FastAPI, Form, Request
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from starlette.middleware.sessions import SessionMiddleware

from metrics import collect_metrics

BASE_DIR = Path(__file__).resolve().parent

_secret = os.environ.get("SECRET_KEY", "").strip()
_password = os.environ.get("MONITOR_PASSWORD", "").strip()
if not _secret or len(_secret) < 16:
    print("SECRET_KEY must be set and at least 16 characters", file=sys.stderr)
    sys.exit(1)
if not _password:
    print("MONITOR_PASSWORD must be set", file=sys.stderr)
    sys.exit(1)

app = FastAPI(title="Server monitor")
app.add_middleware(SessionMiddleware, secret_key=_secret, max_age=60 * 60 * 24 * 7)
app.mount("/static", StaticFiles(directory=str(BASE_DIR / "static")), name="static")
templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))

_MONITOR_USER = os.environ.get("MONITOR_USER", "admin").strip() or "admin"


def _authed(request: Request) -> bool:
    return bool(request.session.get("auth"))


@app.get("/login", response_class=HTMLResponse)
async def login_get(request: Request):
    if _authed(request):
        return RedirectResponse("/", status_code=302)
    return templates.TemplateResponse(
        "login.html", {"request": request, "error": None}, status_code=200
    )


@app.post("/login", response_class=HTMLResponse)
async def login_post(
    request: Request, username: str = Form(...), password: str = Form(...)
):
    if username == _MONITOR_USER and password == _password:
        request.session["auth"] = True
        return RedirectResponse("/", status_code=303)
    return templates.TemplateResponse(
        "login.html",
        {"request": request, "error": "Неверный логин или пароль"},
        status_code=401,
    )


@app.get("/logout")
async def logout(request: Request):
    request.session.clear()
    return RedirectResponse("/login", status_code=302)


@app.get("/", response_class=HTMLResponse)
async def dashboard(request: Request):
    if not _authed(request):
        return RedirectResponse("/login", status_code=302)
    return templates.TemplateResponse("dashboard.html", {"request": request})


@app.get("/api/metrics")
async def api_metrics(request: Request):
    if not _authed(request):
        return JSONResponse({"success": False, "error": "Unauthorized"}, status_code=401)
    try:
        data = collect_metrics()
        return JSONResponse({"success": True, "data": data})
    except Exception as e:
        return JSONResponse({"success": False, "error": str(e)}, status_code=500)
