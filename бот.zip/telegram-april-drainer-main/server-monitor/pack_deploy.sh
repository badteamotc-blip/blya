#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
TS="$(date +%Y%m%d-%H%M%S)"
NAME="deploy-${TS}"
OUT="${ROOT}/${NAME}"
mkdir -p "${OUT}/templates" "${OUT}/static"
for f in main.py metrics.py requirements.txt env.sample; do
  cp "${ROOT}/${f}" "${OUT}/${f}"
done
cp -r "${ROOT}/templates/." "${OUT}/templates/"
cp -r "${ROOT}/static/." "${OUT}/static/"
ARCHIVE="${ROOT}/${NAME}.tar.gz"
tar -czf "${ARCHIVE}" -C "${ROOT}" "${NAME}"
echo "${OUT}"
echo "${ARCHIVE}"
