#!/usr/bin/env python3

from __future__ import annotations

import json
import logging
import os
import re
import signal
import subprocess
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Optional, TextIO

import requests

_BOT_TOKEN_RE = re.compile(r'BOT_TOKEN\s*=\s*["\']([^"\']+)["\']')


def _read_bot_token(team_dir: Path) -> Optional[str]:
    path = team_dir / "config.py"
    try:
        text = path.read_text(encoding="utf-8")
    except OSError:
        return None
    m = _BOT_TOKEN_RE.search(text)
    if not m:
        return None
    t = m.group(1).strip()
    return t or None


def _telegram_get_me_ok(token: Optional[str]) -> bool:
    if not token:
        return False
    timeout = float(os.environ.get("SUPERVISOR_BOT_TOKEN_CHECK_TIMEOUT_SEC", "10"))
    try:
        r = requests.get(
            f"https://api.telegram.org/bot{token}/getMe",
            timeout=timeout,
        )
        if r.status_code != 200:
            return False
        data = r.json()
        return bool(data.get("ok"))
    except requests.RequestException:
        return False

import env_loader

log = logging.getLogger("teams_supervisor")

CODE_ROOT = Path(__file__).resolve().parent
TEAMS_ROOT = Path(
    os.environ.get("TEAMS_ROOT", str(CODE_ROOT.parent / "teams"))
).resolve()
_STACK_BIND_HOST = os.environ.get("STACK_BIND_HOST", "").strip()


def _load_service(team_dir: Path) -> dict[str, Any]:
    path = team_dir / "service.json"
    if not path.is_file():
        return {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except (OSError, json.JSONDecodeError) as e:
        log.warning("%s: не удалось прочитать service.json: %s", team_dir.name, e)
        return {}


@dataclass
class TeamRuntime:
    name: str
    team_dir: Path
    web_port: int
    web_host: str
    health_url: str
    check_interval_sec: int
    autostart_bot: bool
    web_proc: Optional[subprocess.Popen] = None
    bot_proc: Optional[subprocess.Popen] = None
    last_health_check: float = 0.0
    web_start_time: float = 0.0
    bot_log_file: Optional[TextIO] = None
    web_log_file: Optional[TextIO] = None
    last_bot_token_check: float = 0.0
    last_bot_token_warn_time: float = 0.0
    prev_bot_alive: bool = False

    def _close_bot_log(self) -> None:
        if self.bot_log_file:
            try:
                self.bot_log_file.close()
            except OSError:
                pass
            self.bot_log_file = None

    def _close_web_log(self) -> None:
        if self.web_log_file:
            try:
                self.web_log_file.close()
            except OSError:
                pass
            self.web_log_file = None

    def _web_env(self) -> dict[str, str]:
        return {
            **os.environ,
            "TEAM_DIR": str(self.team_dir),
            "WEB_HOST": self.web_host,
            "WEB_PORT": str(self.web_port),
            "WEB_RELOAD": "0",
            "WEB_PATH_PREFIX": f"/{self.name}",
        }

    def _bot_env(self) -> dict[str, str]:
        return {**os.environ, "TEAM_DIR": str(self.team_dir)}

    def start_web(self) -> None:
        if self.web_proc and self.web_proc.poll() is None:
            return
        self._close_web_log()
        py = os.environ.get("PYTHON", sys.executable)
        log_dir = self.team_dir / "logs"
        out_dest: Any = subprocess.DEVNULL
        err_dest: Any = subprocess.DEVNULL
        try:
            log_dir.mkdir(parents=True, exist_ok=True)
            self.web_log_file = open(
                log_dir / "web.log", "a", encoding="utf-8", buffering=1
            )
            ts = time.strftime("%Y-%m-%d %H:%M:%S")
            self.web_log_file.write(
                f"\n{'=' * 72}\n[{ts}] web.py host={self.web_host} port={self.web_port}\n{'=' * 72}\n"
            )
            self.web_log_file.flush()
            out_dest = self.web_log_file
            err_dest = subprocess.STDOUT
        except OSError as e:
            log.warning("[%s] web.log: %s", self.name, e)
            self.web_log_file = None
        self.web_proc = subprocess.Popen(
            [py, "web.py"],
            cwd=str(CODE_ROOT),
            env=self._web_env(),
            stdout=out_dest,
            stderr=err_dest,
        )
        if self.web_log_file:
            self.web_log_file.write(f"pid={self.web_proc.pid}\n")
            self.web_log_file.flush()
        now = time.time()
        self.last_health_check = now
        self.web_start_time = now
        log.info("[%s] web.py запущен (pid=%s) host=%s port=%s", self.name, self.web_proc.pid, self.web_host, self.web_port)

    def start_bot(self) -> None:
        if not self.autostart_bot:
            return
        if self.bot_proc and self.bot_proc.poll() is None:
            return
        self._close_bot_log()
        py = os.environ.get("PYTHON", sys.executable)
        log_dir = self.team_dir / "logs"
        out_dest: Any = subprocess.DEVNULL
        err_dest: Any = subprocess.DEVNULL
        try:
            log_dir.mkdir(parents=True, exist_ok=True)
            self.bot_log_file = open(
                log_dir / "bot.log", "a", encoding="utf-8", buffering=1
            )
            ts = time.strftime("%Y-%m-%d %H:%M:%S")
            self.bot_log_file.write(
                f"\n{'=' * 72}\n[{ts}] bot.py\n{'=' * 72}\n"
            )
            self.bot_log_file.flush()
            out_dest = self.bot_log_file
            err_dest = subprocess.STDOUT
        except OSError as e:
            log.warning("[%s] bot.log: %s", self.name, e)
            self.bot_log_file = None
        self.bot_proc = subprocess.Popen(
            [py, "bot.py"],
            cwd=str(CODE_ROOT),
            env=self._bot_env(),
            stdout=out_dest,
            stderr=err_dest,
        )
        if self.bot_log_file:
            self.bot_log_file.write(f"pid={self.bot_proc.pid}\n")
            self.bot_log_file.flush()
        log.info("[%s] bot.py запущен (pid=%s)", self.name, self.bot_proc.pid)

    def stop_web(self) -> None:
        if not self.web_proc:
            self._close_web_log()
            return
        if self.web_proc.poll() is not None:
            self.web_proc = None
            self._close_web_log()
            return
        try:
            self.web_proc.terminate()
            try:
                self.web_proc.wait(timeout=10)
            except subprocess.TimeoutExpired:
                self.web_proc.kill()
        except OSError as e:
            log.warning("[%s] stop web: %s", self.name, e)
        self.web_proc = None
        self._close_web_log()

    def restart_web(self, reason: str) -> None:
        log.warning("[%s] перезапуск web: %s", self.name, reason)
        self.stop_web()
        time.sleep(1)
        self.start_web()

    def health_ok(self) -> bool:
        timeout = float(os.environ.get("SUPERVISOR_HEALTH_TIMEOUT_SEC", "18"))
        attempts = max(1, int(os.environ.get("SUPERVISOR_HEALTH_ATTEMPTS", "3")))
        for attempt in range(attempts):
            try:
                r = requests.get(
                    self.health_url, timeout=timeout, allow_redirects=True
                )
            except requests.RequestException as e:
                if attempt + 1 < attempts:
                    time.sleep(1.0)
                    continue
                log.warning("[%s] health fail (сеть): %s", self.name, e)
                return False
            if r.status_code >= 500:
                log.warning("[%s] health fail: HTTP %s", self.name, r.status_code)
                return False
            if r.status_code != 200:
                log.warning(
                    "[%s] health fail: HTTP %s (ожидали 200)",
                    self.name,
                    r.status_code,
                )
                return False
            return True
        return False

    def ensure_processes(self) -> None:
        if self.web_proc is None or self.web_proc.poll() is not None:
            log.info("[%s] web не работает — запуск", self.name)
            self.start_web()
        if self.autostart_bot:
            bot_alive = (
                self.bot_proc is not None and self.bot_proc.poll() is None
            )
            if bot_alive:
                self.prev_bot_alive = True
            else:
                if self.prev_bot_alive:
                    self.last_bot_token_check = 0.0
                self.prev_bot_alive = False
                now = time.time()
                recheck = float(
                    os.environ.get("SUPERVISOR_BOT_TOKEN_RECHECK_SEC", "30")
                )
                if now - self.last_bot_token_check < recheck:
                    return
                self.last_bot_token_check = now
                tok = _read_bot_token(self.team_dir)
                if not _telegram_get_me_ok(tok):
                    if now - self.last_bot_token_warn_time >= 120:
                        self.last_bot_token_warn_time = now
                        log.warning(
                            "[%s] bot: getMe не ок — запуск отложен",
                            self.name,
                        )
                    return
                log.info("[%s] bot не работает — запуск", self.name)
                self.start_bot()
                self.prev_bot_alive = True

    def tick(self, now: float) -> None:
        self.ensure_processes()
        if now - self.last_health_check < self.check_interval_sec:
            return
        grace = float(os.environ.get("SUPERVISOR_WEB_HEALTH_GRACE_SEC", "45"))
        if (
            self.web_proc
            and self.web_proc.poll() is None
            and self.web_start_time > 0
            and (now - self.web_start_time) < grace
        ):
            self.last_health_check = now
            return
        self.last_health_check = now
        if not self.health_ok():
            self.restart_web("health-check")


def discover_teams() -> list[TeamRuntime]:
    if not TEAMS_ROOT.is_dir():
        log.error("Каталог команд не найден: %s", TEAMS_ROOT)
        return []

    used_ports: dict[int, str] = {}
    teams: list[TeamRuntime] = []

    for entry in sorted(TEAMS_ROOT.iterdir()):
        if not entry.is_dir():
            continue
        if not (entry / "config.py").is_file():
            continue

        if entry.name == "test":
            log.info("Команда test не запускается супервизором")
            continue

        svc = _load_service(entry)
        if svc.get("supervisor_enabled") is False:
            log.info("Команда %s: supervisor_enabled=false — пропуск", entry.name)
            continue
        web_port = int(svc.get("web_port", 8000))
        web_host = _STACK_BIND_HOST or str(svc.get("web_host", "127.0.0.1"))
        check_interval_sec = int(svc.get("check_interval_sec", 30))
        autostart_bot = bool(svc.get("autostart_bot", True))

        bind_for_health = web_host
        if bind_for_health in ("0.0.0.0", "::"):
            bind_for_health = "127.0.0.1"
        default_health = f"http://{bind_for_health}:{web_port}/"
        health_url = str(svc.get("health_url", default_health))

        name = entry.name
        if web_port in used_ports:
            log.error(
                "Порт %s занят и у %s, и у %s — пропускаю %s",
                web_port,
                used_ports[web_port],
                name,
                name,
            )
            continue
        used_ports[web_port] = name

        teams.append(
            TeamRuntime(
                name=name,
                team_dir=entry.resolve(),
                web_port=web_port,
                web_host=web_host,
                health_url=health_url,
                check_interval_sec=max(5, check_interval_sec),
                autostart_bot=autostart_bot,
            )
        )
        log.info(
            "Команда %s: TEAM_DIR=%s port=%s health=%s",
            name,
            entry,
            web_port,
            health_url,
        )

    return teams


def main() -> None:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    env_loader.load_code_env()

    teams = discover_teams()
    if not teams:
        log.error("Нет команд для запуска (нужны папки с config.py в %s)", TEAMS_ROOT)
        sys.exit(1)

    stop_requested = False
    admin_proc: Optional[subprocess.Popen] = None

    def _shutdown(signum: int, _frame: Any) -> None:
        nonlocal stop_requested, admin_proc
        log.info("Сигнал %s — останавливаю дочерние процессы…", signum)
        stop_requested = True
        for t in teams:
            t.stop_web()
            if t.bot_proc and t.bot_proc.poll() is None:
                try:
                    t.bot_proc.terminate()
                except OSError:
                    pass
        if admin_proc and admin_proc.poll() is None:
            try:
                admin_proc.terminate()
            except OSError:
                pass

    signal.signal(signal.SIGINT, _shutdown)
    signal.signal(signal.SIGTERM, _shutdown)

    admin_port = os.environ.get("ADMIN_WEB_PORT", "").strip()
    if admin_port:
        py = os.environ.get("PYTHON", sys.executable)
        admin_env = {
            **os.environ,
            "ADMIN_WEB_PORT": admin_port,
            "ADMIN_WEB_HOST": os.environ.get("ADMIN_WEB_HOST", "127.0.0.1").strip()
            or "127.0.0.1",
            "TEAMS_ROOT": str(TEAMS_ROOT),
        }
        admin_proc = subprocess.Popen(
            [py, "web_admin_app.py"],
            cwd=str(CODE_ROOT),
            env=admin_env,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        log.info(
            "Админка: web_admin_app.py pid=%s (ADMIN_WEB_PORT=%s)",
            admin_proc.pid,
            admin_port,
        )

    for t in teams:
        t.start_web()
        if t.autostart_bot:
            tok = _read_bot_token(t.team_dir)
            if _telegram_get_me_ok(tok):
                t.start_bot()
                t.prev_bot_alive = True
            else:
                log.warning(
                    "[%s] bot: при старте getMe не ок — процесс не поднимаем",
                    t.name,
                )
            t.last_bot_token_check = time.time()

    try:
        while not stop_requested:
            now = time.time()
            for t in teams:
                t.tick(now)
            time.sleep(1)
    finally:
        for t in teams:
            t.stop_web()
            if t.bot_proc and t.bot_proc.poll() is None:
                try:
                    t.bot_proc.terminate()
                    t.bot_proc.wait(timeout=10)
                except (OSError, subprocess.TimeoutExpired):
                    try:
                        t.bot_proc.kill()
                    except OSError:
                        pass
            t._close_bot_log()
        if admin_proc and admin_proc.poll() is None:
            try:
                admin_proc.terminate()
                admin_proc.wait(timeout=10)
            except (OSError, subprocess.TimeoutExpired):
                try:
                    admin_proc.kill()
                except OSError:
                    pass


if __name__ == "__main__":
    main()
