import json
import os

from paths import CODE_ROOT


def proxys_json_path() -> str:
    return os.path.join(CODE_ROOT, "proxys.json")


def change_proxy(proxy):
    with open(proxys_json_path(), "r") as file:
        proxys_json = json.load(file)

    proxys = proxys_json["proxys"]

    if proxy is None:
        proxys_json["noproxy"]["active"] = True
        for p in proxys:
            p["active"] = False
    else:
        proxys_json["noproxy"]["active"] = False
        for p in proxys:
            p["active"] = False
        proxys[proxy]["active"] = True

    with open(proxys_json_path(), "w") as file:
        json.dump(proxys_json, file, indent=4)

    return proxy


def get_active_proxy():
    with open(proxys_json_path(), "r") as file:
        proxys_json = json.load(file)

    proxys = proxys_json["proxys"]

    if proxys_json["noproxy"]["active"]:
        return [None, "noproxy"]

    for index, p in enumerate(proxys):
        if p["active"]:
            return [p, index]

    return [None, None]
