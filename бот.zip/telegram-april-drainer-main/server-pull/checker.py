import subprocess
import requests
import time
import datetime
import asyncio
import os
import json
import re

from zoneinfo import ZoneInfo

try:
    import env_loader

    env_loader.load_code_env()
except Exception:
    pass

import paths
import config
import sqlite3

CONFIG_PATH = os.path.join(paths.TEAM_DIR, "config.py")
RESERVE_PATH = os.path.join(paths.TEAM_DIR, "storage", "reserve.json")
DAILY_STAT_STATE_PATH = os.path.join(
    paths.TEAM_DIR, "storage", "checker_daily_stat_date.txt"
)

URL = os.environ.get("CHECKER_WEB_BASE", "http://127.0.0.1:37020").rstrip("/")
WEB_COMMAND = ["python3", "web.py"]
BOT_COMMAND = ["python3", "bot.py"]

def get_day_profit_sum(
    db_path=None,
):
    if db_path is None:
        db_path = os.path.join(paths.TEAM_DIR, "storage", "advanced_profits.db")
    since = time.time() - 60 * 60 * 24

    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    cursor.execute(
        """
        SELECT SUM(CAST(amount AS REAL))
        FROM advanced_profits
        WHERE unixtime >= ?
        """,
        (since,),
    )

    result = cursor.fetchone()[0]
    conn.close()

    return result or 0


def _load_last_daily_stat_date():
    try:
        with open(DAILY_STAT_STATE_PATH, "r", encoding="utf-8") as f:
            s = f.read().strip()
        if not s:
            return None
        return datetime.date.fromisoformat(s)
    except Exception:
        return None


def _save_last_daily_stat_date(d: datetime.date):
    os.makedirs(os.path.dirname(DAILY_STAT_STATE_PATH), exist_ok=True)
    with open(DAILY_STAT_STATE_PATH, "w", encoding="utf-8") as f:
        f.write(d.isoformat())


def is_time_to_send(last_sent_date: datetime.date | None):
    now = datetime.datetime.now(ZoneInfo("Europe/Moscow"))
    if now.hour != 22:
        return False, last_sent_date
    today = now.date()
    if last_sent_date == today:
        return False, last_sent_date
    return True, today


def _admin_recipient_chat_ids():
    raw = getattr(config, "ADMIN_ID", None)
    out = []
    if isinstance(raw, int):
        out = [raw]
    elif isinstance(raw, (list, tuple)):
        for x in raw:
            if x is None:
                continue
            try:
                out.append(int(x))
            except (TypeError, ValueError):
                continue
    if out:
        return out
    chat_raw = os.environ.get("CHECKER_NOTIFY_CHAT_ID", "").strip()
    if not chat_raw:
        return []
    try:
        return [int(chat_raw)]
    except ValueError:
        print("[!] CHECKER_NOTIFY_CHAT_ID должен быть числом")
        return []


def send_daily_stat() -> bool:
    token = os.environ.get("CHECKER_NOTIFY_BOT_TOKEN", "").strip()
    if not token:
        return False
    chat_ids = _admin_recipient_chat_ids()
    if not chat_ids:
        print("[!] Нет получателей: ADMIN_ID пуст и CHECKER_NOTIFY_CHAT_ID не задан")
        return False

    profit = get_day_profit_sum()

    text = (
        "📊 <b>Ежедневная статистика</b>\n\n"
        f"🔗 WEB APP: <code>{config.WEB_APP_LINK}</code>\n"
        f"👤 RECEIVER ID: <code>{config.RECEIVER_ID}</code>\n"
        f"💎 Профит за день: <b>{profit:.2f}</b>"
    )

    url = f"https://api.telegram.org/bot{token}/sendMessage"
    ok_all = True
    for chat_id in chat_ids:
        payload = {
            "chat_id": chat_id,
            "text": text,
            "parse_mode": "HTML",
        }
        try:
            r = requests.post(url, json=payload, timeout=5)
            data = r.json() if r.content else {}
            if r.ok and data.get("ok"):
                print(
                    f"[+] [{datetime.datetime.now()}] Daily stat → chat_id={chat_id}"
                )
            else:
                ok_all = False
                print(
                    f"[!] Daily stat chat_id={chat_id}: HTTP {r.status_code} {data}"
                )
        except Exception as e:
            ok_all = False
            print(f"[!] Daily stat chat_id={chat_id}: {e}")
    return ok_all


def get_current_token():
    try:
        with open(CONFIG_PATH, "r", encoding="utf-8") as f:
            content = f.read()
            match = re.search(r'BOT_TOKEN\s*=\s*["\'](.*?)["\']', content)
            return match.group(1) if match else None
    except Exception:
        return None

def update_config_token(new_token):
    try:
        with open(CONFIG_PATH, "r", encoding="utf-8") as f:
            content = f.read()

        content = re.sub(
            r'BOT_TOKEN\s*=\s*["\'].*?["\']', f'BOT_TOKEN = "{new_token}"', content
        )

        with open(CONFIG_PATH, "w", encoding="utf-8") as f:
            f.write(content)
        print(f"[+] config.py успешно обновлен (BOT token)")
    except Exception as e:
        print(f"[!] Ошибка при записи в config.py: {e}")

async def restart_bot():
    print(f"[*] [{datetime.datetime.now()}] Перезапуск бота с новым токеном...")
    subprocess.run(["pkill", "-f", "bot.py"], stderr=subprocess.DEVNULL)
    await asyncio.sleep(1)
    subprocess.Popen(BOT_COMMAND, cwd=paths.CODE_ROOT, env={**os.environ, "TEAM_DIR": paths.TEAM_DIR})


async def check_bot():
    current_token = get_current_token()
    if not current_token:
        print("[!] Не удалось найти токен в config.py")
        return

    try:
        response = requests.get(
            f"https://api.telegram.org/bot{current_token}/getMe", timeout=5
        )
        try:
            data = response.json()
        except Exception:
            data = {}
        if response.status_code == 200 and data.get("ok"):
            print(f"[+] [{datetime.datetime.now()}] Токен {current_token[:10]} живой.")
            return
        if response.status_code == 200:
            print(
                f"[-] [{datetime.datetime.now()}] Токен {current_token[:10]}... getMe ok=false: {data}"
            )
        else:
            print(
                f"[-] [{datetime.datetime.now()}] Токен {current_token[:10]}... HTTP {response.status_code}"
            )
    except Exception as e:
        print(f"[!] Ошибка проверки API: {e}")
        return

    if os.path.exists(RESERVE_PATH):
        with open(RESERVE_PATH, "r+", encoding="utf-8") as f:
            data = json.load(f)
            tokens = data.get("reserve", [])

            if tokens:
                new_token = tokens.pop(0)

                f.seek(0)
                json.dump({"reserve": tokens}, f, indent=4)
                f.truncate()

                update_config_token(new_token)
                print(f"[+] Установлен новый токен из резерва: {new_token[:10]}...")
                await restart_bot()
            else:
                print("[!!!] ТОКЕН СДОХ, А В RESERVE.JSON ПУСТО!")
    else:
        print(f"[!] Файл {RESERVE_PATH} не найден")


if __name__ == "__main__":
    last_sent_date = _load_last_daily_stat_date()
    while True:
        asyncio.run(check_bot())

        should_send, pending_date = is_time_to_send(last_sent_date)
        if should_send and send_daily_stat():
            last_sent_date = pending_date
            _save_last_daily_stat_date(pending_date)

        time.sleep(30)
