import paths

from aiogram import Bot
from aiogram.fsm.storage.memory import MemoryStorage

from pyrogram import Client

from pathlib import Path

import os

import config

from drainer.core.proxy import get_active_proxy

proxy = get_active_proxy()
actual_proxy = proxy[1]
proxy = proxy[0]

BASE_DIR = Path(__file__).resolve().parent
CODE_ROOT = paths.CODE_ROOT
absolute_path = paths.TEAM_DIR

version = "4.0.0"

api_id = config.API_ID
api_hash = config.API_HASH

star_session = Client(f"{absolute_path}/star_session", api_id, api_hash)

bot = Bot(token=config.BOT_TOKEN)
post_bot = Bot(token=config.BOT_TOKEN)
helper_bot = Bot(token=os.environ.get("HELPER_BOT_TOKEN", ""))

storage = MemoryStorage()
