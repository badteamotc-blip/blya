const defaultWebApp =
  process.env.TELEGRAM_WEB_APP_URL || 'https://example.com/chat'

export const runtime = {
  botToken: process.env.BOT_TOKEN || '',
  webAppUrl: defaultWebApp,
}

export function setRuntimeBotToken(token) {
  runtime.botToken = token
  process.env.BOT_TOKEN = token
}
