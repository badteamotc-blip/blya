import { createHash, randomInt, timingSafeEqual } from 'node:crypto'

const BOT_TOKEN_RE = /^\d{6,}:[A-Za-z0-9_-]{20,}$/

export function isBotTokenShape(s) {
  return typeof s === 'string' && BOT_TOKEN_RE.test(s.trim())
}

export async function verifyBotTokenWithTelegram(token) {
  const t = encodeURIComponent(token.trim())
  const ac = new AbortController()
  const to = setTimeout(() => ac.abort(), 12000)
  let res
  try {
    res = await fetch(`https://api.telegram.org/bot${t}/getMe`, {
      method: 'GET',
      signal: ac.signal,
    })
  } catch {
    return false
  } finally {
    clearTimeout(to)
  }
  let data
  try {
    data = await res.json()
  } catch {
    return false
  }
  return Boolean(data && data.ok === true)
}

function panelSecretOk(provided, expected) {
  if (typeof provided !== 'string' || typeof expected !== 'string') return false
  if (expected.length < 32) return false
  try {
    const a = Buffer.from(provided, 'utf8')
    const b = Buffer.from(expected, 'utf8')
    if (a.length !== b.length) return false
    return timingSafeEqual(a, b)
  } catch {
    return false
  }
}

export async function denyReply(reply) {
  await new Promise((r) => setTimeout(r, 120 + randomInt(180)))
  return reply.code(403).send({ error: 'forbidden' })
}

export function assertAdminPanelAccess({ adminSecret, panelSecret }) {
  if (!panelSecret || panelSecret.length < 32) return false
  if (!panelSecretOk(adminSecret, panelSecret)) return false
  return true
}

export function hashForAudit(s) {
  return createHash('sha256').update(String(s), 'utf8').digest('hex').slice(0, 16)
}
