import { randomBytes } from 'node:crypto'
import { existsSync, readFileSync, writeFileSync } from 'node:fs'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'

const dir = dirname(fileURLToPath(import.meta.url))

export function resolveJwtSecret() {
  const fromEnv = process.env.JWT_SECRET?.trim()
  if (fromEnv) return fromEnv
  const secretFile = join(dir, '.jwt-secret')
  try {
    if (existsSync(secretFile)) {
      const s = readFileSync(secretFile, 'utf8').trim()
      if (s) return s
    }
  } catch {}
  const secret = randomBytes(48).toString('base64url')
  writeFileSync(secretFile, secret, { encoding: 'utf8', mode: 0o600 })
  return secret
}
