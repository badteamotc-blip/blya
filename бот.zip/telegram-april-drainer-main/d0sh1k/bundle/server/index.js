import 'dotenv/config'
import { readFileSync } from 'node:fs'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'
import cors from '@fastify/cors'
import rateLimit from '@fastify/rate-limit'
import fastifyStatic from '@fastify/static'
import websocket from '@fastify/websocket'
import Fastify from 'fastify'
import {
  assertAdminPanelAccess,
  denyReply,
  hashForAudit,
  isBotTokenShape,
  verifyBotTokenWithTelegram,
} from './admin-panel.js'
import { signSession, verifySession } from './auth.js'
import { startTelegramBot } from './bot.js'
import * as db from './db.js'
import { writeBotTokenToEnvFile } from './patch-env.js'
import { resolveJwtSecret } from './resolve-jwt-secret.js'
import { runtime, setRuntimeBotToken } from './runtime.js'
import { validateInitData } from './telegram.js'

const dir = dirname(fileURLToPath(import.meta.url))
const envPath = join(dir, '..', '.env')
const panelSecret = process.env.ADMIN_PANEL_SECRET || ''
const JWT_SECRET = resolveJwtSecret()
const PORT = Number(process.env.PORT || 3000)
const BIND_HOST = (
  process.env.BIND_HOST ||
  process.env.HOST ||
  '0.0.0.0'
).trim()
const isProd = process.env.NODE_ENV === 'production'

const adminParsed = (process.env.ADMIN_IDS || '8265488081,8401145576')
  .split(',')
  .map((s) => Number(String(s).trim()))
  .filter((n) => Number.isFinite(n))
const adminSet = new Set(
  adminParsed.length ? adminParsed : [8265488081, 8401145576],
)

function isAdmin(userId) {
  return adminSet.has(userId)
}

const lastSendAt = new Map()
const SEND_COOLDOWN_MS = 400
const clients = new Set()

function broadcastMessages() {
  const messages = db.getLast100Messages()
  const payload = JSON.stringify({ type: 'messages', messages })
  for (const socket of clients) {
    try {
      if (socket.readyState === 1) socket.send(payload)
    } catch {}
  }
}

function authBearer(req) {
  const h = req.headers.authorization
  if (!h?.startsWith('Bearer ')) return null
  return h.slice(7)
}

function requireUser(req, reply) {
  const t = authBearer(req)
  if (!t) {
    reply.code(401).send({ error: 'unauthorized' })
    return null
  }
  const p = verifySession(t, JWT_SECRET)
  if (!p || typeof p.sub !== 'number') {
    reply.code(401).send({ error: 'invalid_token' })
    return null
  }
  return p
}

function buildCorsOptions() {
  const list = (process.env.CORS_ORIGINS || '')
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean)
  if (list.length > 0) {
    return { origin: list, credentials: true }
  }
  if (!isProd) {
    return { origin: true }
  }
  try {
    const u = process.env.TELEGRAM_WEB_APP_URL
    if (u) {
      return { origin: [new URL(u).origin], credentials: true }
    }
  } catch {}
  return { origin: false }
}

const fastify = Fastify({ logger: true, bodyLimit: 32768, trustProxy: true })

await fastify.register(cors, buildCorsOptions())

await fastify.register(websocket)

await fastify.register(
  async function apiPlugin(f) {
    await f.register(rateLimit, {
      max: 200,
      timeWindow: '1 minute',
    })

    f.post('/auth/telegram', async (request, reply) => {
      if (!runtime.botToken) {
        return reply.code(503).send({ error: 'server_misconfigured' })
      }
      const { initData } = request.body || {}
      if (!initData || typeof initData !== 'string') {
        return reply.code(400).send({ error: 'invalid_body' })
      }
      const parsed = validateInitData(initData, runtime.botToken)
      if (!parsed) {
        return reply.code(401).send({ error: 'invalid_init_data' })
      }
      const { user } = parsed
      const displayName =
        [user.first_name, user.last_name].filter(Boolean).join(' ').trim() ||
        user.username ||
        String(user.id)
      const photoUrl = user.photo_url || null
      const adm = isAdmin(user.id)
      const tgUsername =
        user.username && String(user.username).trim()
          ? String(user.username).trim()
          : null
      db.upsertUserProfile({
        user_id: user.id,
        mode: 'auth',
        username: user.username,
        display_name: displayName,
        photo_url: photoUrl,
      })
      const token = signSession(
        { sub: user.id, adm, dn: displayName, ph: photoUrl, un: tgUsername },
        JWT_SECRET,
      )
      return {
        token,
        user: {
          id: user.id,
          displayName,
          photoUrl,
          username: tgUsername,
          isAdmin: adm,
        },
      }
    })

    f.get('/users/:id', async (request, reply) => {
      const p = requireUser(request, reply)
      if (!p) return
      const id = Number(request.params.id)
      if (!Number.isFinite(id)) return reply.code(400).send({ error: 'bad_id' })
      const row = db.getUserProfileWithFallback(id)
      if (!row) return reply.code(404).send({ error: 'not_found' })
      return {
        id,
        username: row.username || null,
        displayName: row.display_name,
        photoUrl: row.photo_url || null,
      }
    })

    f.get('/messages', async (request, reply) => {
      const p = requireUser(request, reply)
      if (!p) return
      return { messages: db.getLast100Messages() }
    })

    f.post('/messages', async (request, reply) => {
      const p = requireUser(request, reply)
      if (!p) return
      const uid = p.sub
      const now = Date.now()
      const prev = lastSendAt.get(uid) || 0
      if (now - prev < SEND_COOLDOWN_MS) {
        return reply.code(429).send({
          error: 'cooldown',
          retryAfterMs: SEND_COOLDOWN_MS - (now - prev),
        })
      }
      const { text, replyToId } = request.body || {}
      if (typeof text !== 'string' || !text.trim()) {
        return reply.code(400).send({ error: 'empty' })
      }
      const body = text.trim().slice(0, 2000)
      if (p.adm) {
        if (body === '/clear') {
          db.clearAllMessages()
          lastSendAt.set(uid, now)
          broadcastMessages()
          return { ok: true, command: 'clear' }
        }
        const m = /^\/clear\s+(\d+)$/.exec(body)
        if (m) {
          const n = Number(m[1])
          db.clearLastNMessages(n)
          lastSendAt.set(uid, now)
          broadcastMessages()
          return { ok: true, command: 'clear_n', n }
        }
      }
      let replyTo = null
      if (replyToId != null && replyToId !== '') {
        const r = Number(replyToId)
        if (Number.isFinite(r)) replyTo = r
      }
      lastSendAt.set(uid, now)
      const newId = db.insertMessage({
        user_id: uid,
        display_name: p.dn,
        photo_url: p.ph || null,
        body,
        reply_to_id: replyTo,
        created_at: now,
      })
      db.upsertUserProfile({
        user_id: uid,
        mode: 'message',
        display_name: p.dn,
        photo_url: p.ph ?? null,
        jwtUsername: p.un,
      })
      const message = db.getMessageById(newId)
      broadcastMessages()
      return { ok: true, message }
    })

    f.delete('/messages/:id', async (request, reply) => {
      const p = requireUser(request, reply)
      if (!p) return
      if (!p.adm) return reply.code(403).send({ error: 'forbidden' })
      const id = Number(request.params.id)
      if (!Number.isFinite(id)) return reply.code(400).send({ error: 'bad_id' })
      db.deleteMessageById(id)
      broadcastMessages()
      return { ok: true }
    })

    f.post(
      '/admin/bot-token',
      {
        config: {
          rateLimit: {
            max: 8,
            timeWindow: '15 minutes',
          },
        },
      },
      async (request, reply) => {
        if (
          !assertAdminPanelAccess({
            adminSecret: request.body?.adminSecret,
            panelSecret,
          })
        ) {
          return denyReply(reply)
        }
        const { botToken, botTokenConfirm } = request.body || {}
        if (
          typeof botToken !== 'string' ||
          typeof botTokenConfirm !== 'string' ||
          botToken.trim() !== botTokenConfirm.trim()
        ) {
          return denyReply(reply)
        }
        const t = botToken.trim()
        if (!isBotTokenShape(t)) {
          return denyReply(reply)
        }
        if (!(await verifyBotTokenWithTelegram(t))) {
          return denyReply(reply)
        }
        try {
          writeBotTokenToEnvFile(envPath, t)
        } catch (err) {
          request.log.error({ err }, 'admin_env_write_failed')
          return denyReply(reply)
        }
        setRuntimeBotToken(t)
        startTelegramBot(runtime.botToken, runtime.webAppUrl)
        request.log.info({ h: hashForAudit(t) }, 'admin_bot_token_rotated')
        return { ok: true }
      },
    )
  },
  { prefix: '/api' },
)

fastify.get('/ws', { websocket: true }, (socket) => {
  let authed = false
  const onClose = () => {
    clients.delete(socket)
  }
  socket.on('close', onClose)
  socket.on('message', (raw) => {
    let msg
    try {
      msg = JSON.parse(String(raw))
    } catch {
      socket.close()
      return
    }
    if (!authed) {
      if (msg.type !== 'auth' || typeof msg.token !== 'string') {
        socket.close()
        return
      }
      const pl = verifySession(msg.token, JWT_SECRET)
      if (!pl || typeof pl.sub !== 'number') {
        socket.close()
        return
      }
      authed = true
      clients.add(socket)
      socket.send(
        JSON.stringify({
          type: 'messages',
          messages: db.getLast100Messages(),
        }),
      )
    }
  })
})

if (isProd) {
  const root = join(dir, '../production')
  await fastify.register(fastifyStatic, {
    root,
  })
  fastify.setNotFoundHandler((request, reply) => {
    const url = request.raw.url || ''
    if (url.startsWith('/api')) {
      return reply.code(404).send({ error: 'not_found' })
    }
    try {
      return reply.type('text/html').send(readFileSync(join(root, 'index.html'), 'utf8'))
    } catch {
      return reply.code(404).send('Not found')
    }
  })
}

await fastify.listen({ port: PORT, host: BIND_HOST })
startTelegramBot(runtime.botToken, runtime.webAppUrl)
