import jwt from 'jsonwebtoken'

export function signSession(payload, secret, expiresIn = '24h') {
  return jwt.sign(payload, secret, { expiresIn })
}

export function verifySession(token, secret) {
  try {
    return jwt.verify(token, secret)
  } catch {
    return null
  }
}
