import { createHmac, timingSafeEqual } from 'node:crypto'

function parseTgInitData(initData) {
  const m = new Map()
  if (!initData || typeof initData !== 'string') return m
  for (const segment of initData.split('&')) {
    if (!segment.length) continue
    const eq = segment.indexOf('=')
    if (eq <= 0) continue
    const k = segment.slice(0, eq)
    const raw = segment.slice(eq + 1)
    let v
    try {
      v = decodeURIComponent(raw.replace(/\+/g, ' '))
    } catch {
      v = raw
    }
    m.set(k, v)
  }
  return m
}

function pairsToCheckString(pairs) {
  const copy = [...pairs]
  copy.sort((a, b) => (a[0] === b[0] ? 0 : a[0] < b[0] ? -1 : 1))
  return copy.map(([k, v]) => `${k}=${v}`).join('\n')
}

function hmacDataMatches(secretKey, dataCheckString, expectedHex) {
  if (!/^[0-9a-fA-F]{64}$/.test(expectedHex)) return false
  const expected = Buffer.from(expectedHex, 'hex')
  const actual = createHmac('sha256', secretKey)
    .update(dataCheckString)
    .digest()
  return (
    expected.length === actual.length && timingSafeEqual(expected, actual)
  )
}

export function validateInitData(initData, botToken, maxAgeSec = 86400) {
  const token = typeof botToken === 'string' ? botToken.trim() : ''
  if (!initData || !token) return null
  const map = parseTgInitData(initData)
  const hash = map.get('hash')
  if (!hash || !/^[0-9a-fA-F]{64}$/.test(hash)) return null
  const authDate = Number(map.get('auth_date'))
  if (!Number.isFinite(authDate)) return null
  if (Date.now() / 1000 - authDate > maxAgeSec) return null

  const all = [...map.entries()].filter(([k]) => k !== 'hash')
  const withoutSig = all.filter(([k]) => k !== 'signature')
  const secretKey = createHmac('sha256', 'WebAppData').update(token).digest()

  let ok = hmacDataMatches(
    secretKey,
    pairsToCheckString(withoutSig),
    hash,
  )
  if (
    !ok &&
    map.has('signature') &&
    withoutSig.length !== all.length
  ) {
    ok = hmacDataMatches(secretKey, pairsToCheckString(all), hash)
  }
  if (!ok) return null

  const userRaw = map.get('user')
  if (!userRaw) return null
  try {
    const user = JSON.parse(userRaw)
    if (!user) return null
    let id = user.id
    if (typeof id === 'string' && /^\d+$/.test(id)) id = Number(id)
    if (typeof id !== 'number' || !Number.isFinite(id)) return null
    return { user: { ...user, id }, authDate }
  } catch {
    return null
  }
}
