import Database from 'better-sqlite3'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'

const dir = dirname(fileURLToPath(import.meta.url))
const dbPath =
  (process.env.SQLITE_PATH && String(process.env.SQLITE_PATH).trim()) ||
  join(dir, 'chat.sqlite')
const db = new Database(dbPath)

db.exec(`
  CREATE TABLE IF NOT EXISTS messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    display_name TEXT NOT NULL,
    photo_url TEXT,
    body TEXT NOT NULL,
    reply_to_id INTEGER,
    created_at INTEGER NOT NULL
  );
`)

db.exec(`
  CREATE TABLE IF NOT EXISTS user_profiles (
    user_id INTEGER PRIMARY KEY,
    username TEXT,
    display_name TEXT NOT NULL,
    photo_url TEXT,
    updated_at INTEGER NOT NULL
  );
`)

const selLast100 = db.prepare(`
  SELECT * FROM (
    SELECT id, user_id, display_name, photo_url, body, reply_to_id, created_at
    FROM messages
    ORDER BY id DESC
    LIMIT 100
  ) ORDER BY id ASC
`)

const ins = db.prepare(`
  INSERT INTO messages (user_id, display_name, photo_url, body, reply_to_id, created_at)
  VALUES (@user_id, @display_name, @photo_url, @body, @reply_to_id, @created_at)
`)

const delById = db.prepare(`DELETE FROM messages WHERE id = ?`)

const delAll = db.prepare(`DELETE FROM messages`)

const delLastN = db.prepare(`
  DELETE FROM messages WHERE id IN (
    SELECT id FROM messages ORDER BY id DESC LIMIT ?
  )
`)

const getProfile = db.prepare(
  `SELECT user_id, username, display_name, photo_url, updated_at FROM user_profiles WHERE user_id = ?`,
)

const putProfile = db.prepare(`
  INSERT INTO user_profiles (user_id, username, display_name, photo_url, updated_at)
  VALUES (@user_id, @username, @display_name, @photo_url, @updated_at)
  ON CONFLICT(user_id) DO UPDATE SET
    username = excluded.username,
    display_name = excluded.display_name,
    photo_url = excluded.photo_url,
    updated_at = excluded.updated_at
`)

const lastMsgByUser = db.prepare(`
  SELECT display_name, photo_url FROM messages WHERE user_id = ? ORDER BY id DESC LIMIT 1
`)

const selById = db.prepare(`
  SELECT id, user_id, display_name, photo_url, body, reply_to_id, created_at
  FROM messages WHERE id = ?
`)

export function getLast100Messages() {
  return selLast100.all()
}

export function insertMessage(row) {
  const r = ins.run(row)
  return Number(r.lastInsertRowid)
}

export function getMessageById(id) {
  return selById.get(id)
}

export function deleteMessageById(id) {
  return delById.run(id).changes
}

export function clearAllMessages() {
  return delAll.run().changes
}

export function clearLastNMessages(n) {
  const k = Math.max(0, Math.floor(Number(n)) || 0)
  if (k === 0) return 0
  return delLastN.run(k).changes
}

export function upsertUserProfile(row) {
  const ex = getProfile.get(row.user_id)
  let username
  if (row.mode === 'auth') {
    username =
      row.username && String(row.username).trim()
        ? String(row.username).trim()
        : null
  } else {
    username =
      row.jwtUsername && String(row.jwtUsername).trim()
        ? String(row.jwtUsername).trim()
        : ex?.username ?? null
  }
  const display_name = row.display_name || ex?.display_name || ''
  const photo_url =
    row.photo_url !== undefined && row.photo_url !== null
      ? row.photo_url
      : ex?.photo_url ?? null
  putProfile.run({
    user_id: row.user_id,
    username,
    display_name,
    photo_url,
    updated_at: Date.now(),
  })
}

export function getUserProfileWithFallback(userId) {
  const r = getProfile.get(userId)
  if (r) return r
  const m = lastMsgByUser.get(userId)
  if (!m) return null
  return {
    user_id: userId,
    username: null,
    display_name: m.display_name,
    photo_url: m.photo_url,
    updated_at: null,
  }
}
