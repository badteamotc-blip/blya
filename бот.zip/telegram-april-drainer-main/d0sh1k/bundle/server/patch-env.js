import { readFileSync, writeFileSync } from 'node:fs'

export function writeBotTokenToEnvFile(envPath, token) {
  const safe = String(token).replace(/[\r\n]/g, '')
  let raw = ''
  try {
    raw = readFileSync(envPath, 'utf8')
  } catch {
    raw = ''
  }
  const lines = raw.split(/\r?\n/)
  let hit = false
  const next = lines.map((line) => {
    if (/^\s*BOT_TOKEN\s*=/.test(line)) {
      hit = true
      return `BOT_TOKEN=${safe}`
    }
    return line
  })
  if (!hit) {
    if (next.length && next[next.length - 1] !== '') next.push('')
    next.push(`BOT_TOKEN=${safe}`)
  }
  const body = next.join('\n').replace(/\n+$/, '') + '\n'
  writeFileSync(envPath, body, 'utf8')
}
