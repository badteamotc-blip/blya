const tg = (token) =>
  `https://api.telegram.org/bot${encodeURIComponent(token)}`

let loopCtrl = { stop: true, token: '' }

export function startTelegramBot(botToken, webAppUrl) {
  loopCtrl.stop = true
  const c = {
    stop: false,
    token: botToken || '',
    url: webAppUrl || '',
  }
  loopCtrl = c
  let offset = 0
  const run = async () => {
    if (c.stop || !c.token) return
    try {
      const res = await fetch(`${tg(c.token)}/getUpdates?offset=${offset}&timeout=30`)
      const data = await res.json()
      if (!data.ok) {
        await new Promise((r) => setTimeout(r, 3000))
      } else {
        for (const u of data.result || []) {
          offset = u.update_id + 1
          const text = u.message?.text
          if (typeof text === 'string' && /^\s*\/start(\s|$)/.test(text)) {
            await fetch(`${tg(c.token)}/sendMessage`, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                chat_id: u.message.chat.id,
                text: 'Uretra d0sh1k | Hybr1d',
                reply_markup: {
                  inline_keyboard: [
                    [{ text: 'Открыть', web_app: { url: c.url } }],
                  ],
                },
              }),
            })
          }
        }
      }
    } catch {
      await new Promise((r) => setTimeout(r, 3000))
    }
    if (!c.stop) setImmediate(run)
  }
  run()
}
