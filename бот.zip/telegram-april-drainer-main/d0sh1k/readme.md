перезапуск (systemd):

```bash
sudo systemctl restart opt-d0sh1k.service
```

полный стек:

```bash
sudo systemctl restart opt-code-stack opt-autocraft-api opt-autocraft-bot opt-d0sh1k opt-server-monitor
```

без systemd, через nohup (после `sudo deploy/install-render-exec.sh /path/to/opt`):

```bash
sudo /path/to/opt/deploy/scripts/stack-nohup-stop.sh /path/to/opt
sudo /path/to/opt/deploy/scripts/stack-nohup-start.sh /path/to/opt
```

логи unit:

```bash
journalctl -u opt-d0sh1k.service -f --no-pager -n 50
```
